﻿Public Class Configuration
    Private Sub TxtFireACDbox_TextChanged(sender As Object, e As EventArgs) Handles txtFireACDbox.TextChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub BtnFireACDsave_Click(sender As Object, e As EventArgs) Handles btnFireACDsave.Click
        lblIndSaveStat.ForeColor = Color.Black
        lblIndSaveStat.Text = "Changes saved."
        My.Settings.FireAlarmInitDelay = txtFireACDbox.Text
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnSysModelNumberSave.Click
        lblIndSaveStat.ForeColor = Color.Black
        lblIndSaveStat.Text = "Changes saved."
        My.Settings.SystemModel = cbbSysModelNumber.SelectedItem
    End Sub

    Private Sub CbbSysModelNumber_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbbSysModelNumber.SelectedIndexChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub BtnSettingsReset_Click(sender As Object, e As EventArgs) Handles btnSettingsReset.Click
        My.Settings.Reset()
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Formatting appication settings..."
        MessageBox.Show("Your system's configuration has been erased. You will need to reconfigure the system immediately. Defaults have been set.", "Debug Items", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        Me.Close()
    End Sub

    Private Sub BtnSetDefaultConfigs_Click(sender As Object, e As EventArgs) Handles btnSetDefaultConfigs.Click
        ' lblIndSaveStat.ForeColor = Color.Black
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Defaults couldn't be set because they haven't been programmed yet."
        'lblIndSaveStat.Text = "Defaults set. You may want to look through settings and see if anything needs to be changed."
    End Sub

    Private Sub BtnDebugShowSettings_Click(sender As Object, e As EventArgs) Handles btnDebugShowSettings.Click
        debugPanel.Visible = True
        btnDebugShowSettings.Enabled = False
    End Sub

    Private Sub BtnDone_Click(sender As Object, e As EventArgs) Handles btnDone.Click
        Me.Close()
    End Sub

    Private Sub TxtSysName_TextChanged(sender As Object, e As EventArgs) Handles txtSysName.TextChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub BtnSysNameSave_Click(sender As Object, e As EventArgs) Handles btnSysNameSave.Click
        lblIndSaveStat.ForeColor = Color.Black
        lblIndSaveStat.Text = "Changes saved."
        My.Settings.SystemName = txtSysName.Text
    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles txtFireAutoSilDelay.TextChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles btnFASSave.Click
        My.Settings.AutoSilenceDelay = txtFireAutoSilDelay.Text
        lblIndSaveStat.ForeColor = Color.Black
        lblIndSaveStat.Text = "Changes saved."
    End Sub

    Private Sub TxtZone11Name_TextChanged(sender As Object, e As EventArgs) Handles txtZone11Name.TextChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub TxtZone12Name_TextChanged(sender As Object, e As EventArgs) Handles txtZone12Name.TextChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub TxtZone13Name_TextChanged(sender As Object, e As EventArgs) Handles txtZone13Name.TextChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub TxtZone14Name_TextChanged(sender As Object, e As EventArgs) Handles txtZone14Name.TextChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub TxtHZone11Name_TextChanged(sender As Object, e As EventArgs) Handles txtHZone11Name.TextChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub TxtHZone12Name_TextChanged(sender As Object, e As EventArgs) Handles txtHZone12Name.TextChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub BtnZone1xSave_Click(sender As Object, e As EventArgs) Handles btnZone1xSave.Click
        lblIndSaveStat.ForeColor = Color.Black
        lblIndSaveStat.Text = "Changes saved."

        My.Settings.SEzone11 = txtZone11Name.Text
        My.Settings.SEzone12 = txtZone12Name.Text
        My.Settings.SEzone13 = txtZone13Name.Text
        My.Settings.SEzone14 = txtZone14Name.Text
        My.Settings.SEHZone11 = txtHZone11Name.Text
        My.Settings.SEHzone12 = txtHZone12Name.Text
        If SEzone11bypass.Checked = True Then
            My.Settings.SEzone11bypass = True
        Else
            My.Settings.SEzone11bypass = False
        End If
        If SEzone12bypass.Checked = True Then
            My.Settings.SEzone12bypass = True
        Else
            My.Settings.SEzone12bypass = False
        End If
        If SEzone13bypass.Checked = True Then
            My.Settings.SEzone13bypass = True
        Else
            My.Settings.SEzone13bypass = False
        End If
        If SEzone14bypass.Checked = True Then
            My.Settings.SEzone14bypass = True
        Else
            My.Settings.SEzone14bypass = False
        End If
    End Sub

    Private Sub TextBox6_TextChanged(sender As Object, e As EventArgs) Handles txtZone21Name.TextChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub TextBox5_TextChanged(sender As Object, e As EventArgs) Handles txtZone22Name.TextChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub TextBox4_TextChanged(sender As Object, e As EventArgs) Handles txtZone23Name.TextChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub TextBox3_TextChanged(sender As Object, e As EventArgs) Handles txtZone24Name.TextChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles txtHZone21Name.TextChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub TextBox1_TextChanged_1(sender As Object, e As EventArgs) Handles txtHZone22Name.TextChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub Button1_Click_2(sender As Object, e As EventArgs) Handles Button1.Click
        lblIndSaveStat.ForeColor = Color.Black
        lblIndSaveStat.Text = "Changes saved."

        My.Settings.SEzone21 = txtZone21Name.Text
        My.Settings.SEzone22 = txtZone22Name.Text
        My.Settings.SEzone23 = txtZone23Name.Text
        My.Settings.SEzone24 = txtZone24Name.Text
        My.Settings.SEHzone21 = txtHZone21Name.Text
        My.Settings.SEHzone22 = txtHZone22Name.Text
        If SEzone21bypass.Checked = True Then
            My.Settings.SEzone21bypass = True
        Else
            My.Settings.SEzone21bypass = False
        End If
        If SEzone22bypass.Checked = True Then
            My.Settings.SEzone22bypass = True
        Else
            My.Settings.SEzone22bypass = False
        End If
        If SEzone23bypass.Checked = True Then
            My.Settings.SEzone23bypass = True
        Else
            My.Settings.SEzone23bypass = False
        End If
        If SEzone24bypass.Checked = True Then
            My.Settings.SEzone24bypass = True
        Else
            My.Settings.SEzone24bypass = False
        End If
    End Sub

    Private Sub RdoSysExtEnabled_CheckedChanged(sender As Object, e As EventArgs) Handles rdoSysExtEnabled.CheckedChanged
        If rdoSysExtEnabled.Checked = True Then
            My.Settings.SEenabled = True
        End If
    End Sub

    Private Sub RdoSysExtDisabled_CheckedChanged(sender As Object, e As EventArgs) Handles rdoSysExtDisabled.CheckedChanged
        If rdoSysExtDisabled.Checked = True Then
            My.Settings.SEenabled = False
        End If
    End Sub

    Private Sub Configuration_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        MessageBox.Show("This window cannot currently validate entries for boxes which are supposed to take only numbers (like an amount of time in seconds). Ensure you carefully set these with only valid entries to prevent crashing PowerCommander X. Valid entries: 1, 10, 15, 57, etc. Invalid entries: 1.2, 43.6, .76, abc, Any non-integer character.", "Important", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        ConfigLoading.Show()

        txtFirstName.Text = My.Settings.adminFirstName
        txtLastName.Text = My.Settings.adminLastName
        txtEmail.Text = My.Settings.adminEmail
        txtPhone1.Text = My.Settings.adminPhone1
        txtPhone2.Text = My.Settings.adminPhone2
        txtDiscord.Text = My.Settings.adminDiscord
        txtNotes.Text = My.Settings.adminNotes

        ColorSlider.Value = My.Settings.InterfaceColor.ToString()

        If My.Settings.z1a1 = True Then
            z1a1.Checked = True
        End If
        If My.Settings.z1a2 = True Then
            z1a2.Checked = True
        End If
        If My.Settings.z1a3 = True Then
            z1a3.Checked = True
        End If
        If My.Settings.z1a4 = True Then
            z1a4.Checked = True
        End If
        If My.Settings.z2a1 = True Then
            z2a1.Checked = True
        End If
        If My.Settings.z2a2 = True Then
            z2a2.Checked = True
        End If
        If My.Settings.z2a3 = True Then
            z2a3.Checked = True
        End If
        If My.Settings.z2a4 = True Then
            z2a4.Checked = True
        End If
        If My.Settings.z3a1 = True Then
            z3a1.Checked = True
        End If
        If My.Settings.z3a2 = True Then
            z3a2.Checked = True
        End If
        If My.Settings.z3a3 = True Then
            z3a3.Checked = True
        End If
        If My.Settings.z3a4 = True Then
            z3a4.Checked = True
        End If
        If My.Settings.z4a1 = True Then
            z4a1.Checked = True
        End If
        If My.Settings.z4a2 = True Then
            z4a2.Checked = True
        End If
        If My.Settings.z4a3 = True Then
            z4a3.Checked = True
        End If
        If My.Settings.z4a4 = True Then
            z4a4.Checked = True
        End If
        If My.Settings.z5a1 = True Then
            z5a1.Checked = True
        End If
        If My.Settings.z5a2 = True Then
            z5a2.Checked = True
        End If
        If My.Settings.z5a2 = True Then
            z5a2.Checked = True
        End If
        If My.Settings.z5a3 = True Then
            z5a3.Checked = True
        End If
        If My.Settings.z5a4 = True Then
            z5a4.Checked = True
        End If
        If My.Settings.z6a1 = True Then
            z6a1.Checked = True
        End If
        If My.Settings.z6a2 = True Then
            z6a2.Checked = True
        End If
        If My.Settings.z6a3 = True Then
            z6a3.Checked = True
        End If
        If My.Settings.z6a4 = True Then
            z6a4.Checked = True
        End If
        If My.Settings.z7a1 = True Then
            z7a1.Checked = True
        End If
        If My.Settings.z7a2 = True Then
            z7a2.Checked = True
        End If
        If My.Settings.z7a3 = True Then
            z7a3.Checked = True
        End If
        If My.Settings.z7a4 = True Then
            z7a4.Checked = True
        End If
        If My.Settings.z8a1 = True Then
            z8a1.Checked = True
        End If
        If My.Settings.z8a2 = True Then
            z8a2.Checked = True
        End If
        If My.Settings.z8a3 = True Then
            z8a3.Checked = True
        End If
        If My.Settings.z8a4 = True Then
            z8a4.Checked = True
        End If
        If My.Settings.z9a1 = True Then
            z9a1.Checked = True
        End If
        If My.Settings.z9a2 = True Then
            z9a2.Checked = True
        End If
        If My.Settings.z9a3 = True Then
            z9a3.Checked = True
        End If
        If My.Settings.z9a4 = True Then
            z9a4.Checked = True
        End If
        If My.Settings.z10a1 = True Then
            z10a1.Checked = True
        End If
        If My.Settings.z10a2 = True Then
            z10a2.Checked = True
        End If
        If My.Settings.z10a3 = True Then
            z10a3.Checked = True
        End If
        If My.Settings.z10a4 = True Then
            z10a4.Checked = True
        End If

        If My.Settings.z11a1 = True Then
            z11a1.Checked = True
        End If
        If My.Settings.z11a2 = True Then
            z11a2.Checked = True
        End If
        If My.Settings.z11a3 = True Then
            z11a3.Checked = True
        End If
        If My.Settings.z11a4 = True Then
            z11a4.Checked = True
        End If
        If My.Settings.z12a1 = True Then
            z12a1.Checked = True
        End If
        If My.Settings.z12a2 = True Then
            z12a2.Checked = True
        End If
        If My.Settings.z12a3 = True Then
            z12a3.Checked = True
        End If
        If My.Settings.z12a4 = True Then
            z12a4.Checked = True
        End If
        If My.Settings.z13a1 = True Then
            z13a1.Checked = True
        End If
        If My.Settings.z13a2 = True Then
            z13a2.Checked = True
        End If
        If My.Settings.z13a3 = True Then
            z13a3.Checked = True
        End If
        If My.Settings.z13a4 = True Then
            z13a4.Checked = True
        End If
        If My.Settings.z14a1 = True Then
            z14a1.Checked = True
        End If
        If My.Settings.z14a2 = True Then
            z14a2.Checked = True
        End If
        If My.Settings.z14a3 = True Then
            z14a3.Checked = True
        End If
        If My.Settings.z14a4 = True Then
            z14a4.Checked = True
        End If

        If My.Settings.z21a1 = True Then
            z21a1.Checked = True
        End If
        If My.Settings.z21a2 = True Then
            z21a2.Checked = True
        End If
        If My.Settings.z21a3 = True Then
            z21a3.Checked = True
        End If
        If My.Settings.z21a4 = True Then
            z21a4.Checked = True
        End If
        If My.Settings.z22a1 = True Then
            z22a1.Checked = True
        End If
        If My.Settings.z22a2 = True Then
            z22a2.Checked = True
        End If
        If My.Settings.z22a3 = True Then
            z22a3.Checked = True
        End If
        If My.Settings.z22a4 = True Then
            z22a4.Checked = True
        End If
        If My.Settings.z23a1 = True Then
            z23a1.Checked = True
        End If
        If My.Settings.z23a2 = True Then
            z23a2.Checked = True
        End If
        If My.Settings.z23a3 = True Then
            z23a3.Checked = True
        End If
        If My.Settings.z23a4 = True Then
            z23a4.Checked = True
        End If
        If My.Settings.z24a1 = True Then
            z24a1.Checked = True
        End If
        If My.Settings.z24a2 = True Then
            z24a2.Checked = True
        End If
        If My.Settings.z24a3 = True Then
            z24a3.Checked = True
        End If
        If My.Settings.z24a4 = True Then
            z24a4.Checked = True
        End If

        txtZone11Name.Text = My.Settings.SEzone11
        txtZone12Name.Text = My.Settings.SEzone12
        txtZone13Name.Text = My.Settings.SEzone13
        txtZone14Name.Text = My.Settings.SEzone14

        txtHZone11Name.Text = My.Settings.SEHZone11
        txtHZone12Name.Text = My.Settings.SEHzone12

        txtZone21Name.Text = My.Settings.SEzone21
        txtZone22Name.Text = My.Settings.SEzone22
        txtZone23Name.Text = My.Settings.SEzone23
        txtZone24Name.Text = My.Settings.SEzone24

        txtHZone21Name.Text = My.Settings.SEHzone21
        txtHZone22Name.Text = My.Settings.SEHzone22

        If My.Settings.SEzone11bypass = True Then
            SEzone11bypass.Checked = True
        End If
        If My.Settings.SEzone12bypass = True Then
            SEzone12bypass.Checked = True
        End If
        If My.Settings.SEzone13bypass = True Then
            SEzone13bypass.Checked = True
        End If
        If My.Settings.SEzone14bypass = True Then
            SEzone14bypass.Checked = True
        End If
        If My.Settings.SEzone21bypass = True Then
            SEzone21bypass.Checked = True
        End If
        If My.Settings.SEzone22bypass = True Then
            SEzone22bypass.Checked = True
        End If
        If My.Settings.SEzone23bypass = True Then
            SEzone23bypass.Checked = True
        End If
        If My.Settings.SEzone24bypass = True Then
            SEzone24bypass.Checked = True
        End If

        If My.Settings.ControlPreventQuit = True Then
            rdoQuitDisabled.Checked = True
        Else
            rdoQuitEnabled.Checked = True
        End If

        If My.Settings.SEenabled = True Then
            rdoSysExtEnabled.Checked = True
        Else
            rdoSysExtDisabled.Checked = True
        End If

        cbbSysModelNumber.SelectedItem = My.Settings.SystemModel

        txtAgentDelay.Text = My.Settings.AgentDelay
        txtAgentCountdown.Text = My.Settings.AgentCountdown

        If My.Settings.AgentAbortSwitchEnabled = True Then
            rdoAbortEnabled.Checked = True
        Else
            rdoAbortDisabled.Checked = True
        End If

        If My.Settings.HazAutoStop = True Then
            rdoHazASenabled.Checked = True
        Else
            rdoHazASdisabled.Checked = True
        End If

        txtHazAutoStopDelay.Text = My.Settings.HazAutoStopDelay

        txthaz1name.Text = My.Settings.Haz1name
        txthaz2name.Text = My.Settings.Haz2name
        txthaz3name.Text = My.Settings.Haz3name
        txthaz4name.Text = My.Settings.Haz4name

        txtF1name.Text = My.Settings.Fzone1
        txtF2name.Text = My.Settings.Fzone2
        txtF3name.Text = My.Settings.Fzone3
        txtF4name.Text = My.Settings.Fzone4
        txtF5name.Text = My.Settings.Fzone5
        txtF6name.Text = My.Settings.Fzone6
        txtF7name.Text = My.Settings.Fzone7
        txtF8name.Text = My.Settings.Fzone8
        txtF9name.Text = My.Settings.Fzone9
        txtF10name.Text = My.Settings.Fzone10

        If My.Settings.F1bypass = True Then
            chkF1bypass.Checked = True
        End If
        If My.Settings.F2bypass = True Then
            chkF2bypass.Checked = True
        End If
        If My.Settings.F3bypass = True Then
            chkF3bypass.Checked = True
        End If
        If My.Settings.F4bypass = True Then
            chkF4bypass.Checked = True
        End If
        If My.Settings.F5bypass = True Then
            chkF5bypass.Checked = True
        End If
        If My.Settings.F6bypass = True Then
            chkF6bypass.Checked = True
        End If
        If My.Settings.F7bypass = True Then
            chkF7bypass.Checked = True
        End If
        If My.Settings.F8bypass = True Then
            chkF8bypass.Checked = True
        End If
        If My.Settings.F9bypass = True Then
            chkF9bypass.Checked = True
        End If
        If My.Settings.F10bypass = True Then
            chkF10bypass.Checked = True
        End If

        If My.Settings.S1audible = True Then
            chkS1audible.Checked = True
        End If
        If My.Settings.S2audible = True Then
            chkS2audible.Checked = True
        End If
        If My.Settings.S1visible = True Then
            chkS1visual.Checked = True
        End If
        If My.Settings.S2visible = True Then
            chkS2visual.Checked = True
        End If
        If My.Settings.S1buzzer = True Then
            chkS1buzzer.Checked = True
        End If
        If My.Settings.S2buzzer = True Then
            chkS2buzzer.Checked = True
        End If
        If My.Settings.S1notifier = True Then
            chkS1notifier.Checked = True
        End If
        If My.Settings.S2notifier = True Then
            chkS2notifier.Checked = True
        End If

        txtS1delay.Text = My.Settings.S1duration
        txtSysName.Text = My.Settings.SystemName
        txtFireACDbox.Text = My.Settings.FireAlarmInitDelay
        If My.Settings.PanelSilenceEnabled Then
            rdoSilenceEnable.Checked = True
        Else
            rdoSilenceDisable.Checked = True
        End If
        If My.Settings.PanelUnsilenceEnabled = True Then
            rdoUnsilenceEnable.Checked = True
        Else
            rdoUnsilenceDisable.Checked = True
        End If
        If My.Settings.AutoSilenceEnabled = True Then
            rdoAutoSilEnabled.Checked = True
        Else
            rdoAutoSilDisabled.Checked = True
        End If
        txtFireAutoSilDelay.Text = My.Settings.AutoSilenceDelay
        If My.Settings.S2enabled = True Then
            rdo2Senabled.Checked = True
        Else
            rdo2Senabled.Checked = True
        End If

        notepad.Text = My.Settings.NotepadContents

        If My.Settings.AgentEnabled = True Then
            lblIndAgent.Text = "  ENABLED  "
            lblIndAgent.BackColor = Color.Red
            lblIndAgent.ForeColor = Color.White
            btnAgentEnable.Enabled = False
            btnAgentDisable.Enabled = False
            btnAgentTestMode.Enabled = True
        Else
            lblIndAgent.Text = "  DISABLED  "
            lblIndAgent.ForeColor = Color.Black
            lblIndAgent.BackColor = Color.Transparent
            btnAgentDisable.Enabled = False
            btnAgentEnable.Enabled = True
            btnAgentTestMode.Enabled = False
        End If
        If My.Settings.AgentTesting = True Then
            lblIndAgent.Text = "  TESTING  "
            lblIndAgent.BackColor = Color.Yellow
            lblIndAgent.ForeColor = Color.Black
            btnAgentTestMode.Enabled = False
            btnAgentEnable.Enabled = True
            btnAgentDisable.Enabled = True
        End If
        lblIndSaveStat.ForeColor = Color.Black
        lblIndSaveStat.Text = "Changes saved."

        ConfigLoading.SyncTimer.Start()
    End Sub

    Private Sub RdoSilenceEnable_CheckedChanged(sender As Object, e As EventArgs) Handles rdoSilenceEnable.CheckedChanged
        If rdoSilenceEnable.Checked = True Then
            My.Settings.PanelSilenceEnabled = True
        End If
    End Sub

    Private Sub RdoSilenceDisable_CheckedChanged(sender As Object, e As EventArgs) Handles rdoSilenceDisable.CheckedChanged
        If rdoSilenceDisable.Checked = True Then
            My.Settings.PanelSilenceEnabled = False
        End If
    End Sub

    Private Sub RdoUnsilenceEnable_CheckedChanged(sender As Object, e As EventArgs) Handles rdoUnsilenceEnable.CheckedChanged
        If rdoUnsilenceEnable.Checked = True Then
            My.Settings.PanelUnsilenceEnabled = True
        End If
    End Sub

    Private Sub RdoUnsilenceDisable_CheckedChanged(sender As Object, e As EventArgs) Handles rdoUnsilenceDisable.CheckedChanged
        If rdoUnsilenceDisable.Checked = True Then
            My.Settings.PanelUnsilenceEnabled = False
        End If
    End Sub

    Private Sub RadioButton2_CheckedChanged(sender As Object, e As EventArgs) Handles rdoAutoSilEnabled.CheckedChanged
        If rdoAutoSilEnabled.Checked = True Then
            My.Settings.AutoSilenceEnabled = True
        End If
    End Sub

    Private Sub RdoAutoSilDisabled_CheckedChanged(sender As Object, e As EventArgs) Handles rdoAutoSilDisabled.CheckedChanged
        If rdoAutoSilDisabled.Checked = True Then
            My.Settings.AutoSilenceEnabled = False
        End If
    End Sub

    Private Sub ChkF1bypass_CheckedChanged(sender As Object, e As EventArgs) Handles chkF1bypass.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub TxtF2name_TextChanged(sender As Object, e As EventArgs) Handles txtF2name.TextChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub TxtF3name_TextChanged(sender As Object, e As EventArgs) Handles txtF3name.TextChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub TxtF4name_TextChanged(sender As Object, e As EventArgs) Handles txtF4name.TextChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub TxtF5name_TextChanged(sender As Object, e As EventArgs) Handles txtF5name.TextChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub TxtF6name_TextChanged(sender As Object, e As EventArgs) Handles txtF6name.TextChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub TxtF7name_TextChanged(sender As Object, e As EventArgs) Handles txtF7name.TextChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub TxtF8name_TextChanged(sender As Object, e As EventArgs) Handles txtF8name.TextChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub TxtF9name_TextChanged(sender As Object, e As EventArgs) Handles txtF9name.TextChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub TxtF10name_TextChanged(sender As Object, e As EventArgs) Handles txtF10name.TextChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub ChkF10bypass_CheckedChanged(sender As Object, e As EventArgs) Handles chkF10bypass.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub ChkF9bypass_CheckedChanged(sender As Object, e As EventArgs) Handles chkF9bypass.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub ChkF8bypass_CheckedChanged(sender As Object, e As EventArgs) Handles chkF8bypass.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub ChkF7bypass_CheckedChanged(sender As Object, e As EventArgs) Handles chkF7bypass.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub ChkF6bypass_CheckedChanged(sender As Object, e As EventArgs) Handles chkF6bypass.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub ChkF5bypass_CheckedChanged(sender As Object, e As EventArgs) Handles chkF5bypass.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub ChkF4bypass_CheckedChanged(sender As Object, e As EventArgs) Handles chkF4bypass.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub ChkF3bypass_CheckedChanged(sender As Object, e As EventArgs) Handles chkF3bypass.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub ChkF2bypass_CheckedChanged(sender As Object, e As EventArgs) Handles chkF2bypass.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub TxtF1name_TextChanged(sender As Object, e As EventArgs) Handles txtF1name.TextChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub SEzone21bypass_CheckedChanged(sender As Object, e As EventArgs) Handles SEzone21bypass.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub SEzone23bypass_CheckedChanged(sender As Object, e As EventArgs) Handles SEzone23bypass.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub SEzone22bypass_CheckedChanged(sender As Object, e As EventArgs) Handles SEzone22bypass.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub SEzone24bypass_CheckedChanged(sender As Object, e As EventArgs) Handles SEzone24bypass.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub SEzone11bypass_CheckedChanged(sender As Object, e As EventArgs) Handles SEzone11bypass.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub SEzone13bypass_CheckedChanged(sender As Object, e As EventArgs) Handles SEzone13bypass.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub SEzone12bypass_CheckedChanged(sender As Object, e As EventArgs) Handles SEzone12bypass.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub SEzone14bypass_CheckedChanged(sender As Object, e As EventArgs) Handles SEzone14bypass.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub BtnSaveZones_Click(sender As Object, e As EventArgs) Handles btnSaveZones.Click
        lblIndSaveStat.ForeColor = Color.Black
        lblIndSaveStat.Text = "Changes saved."

        My.Settings.Fzone1 = txtF1name.Text
        My.Settings.Fzone2 = txtF2name.Text
        My.Settings.Fzone3 = txtF3name.Text
        My.Settings.Fzone4 = txtF4name.Text
        My.Settings.Fzone5 = txtF5name.Text
        My.Settings.Fzone6 = txtF6name.Text
        My.Settings.Fzone7 = txtF7name.Text
        My.Settings.Fzone8 = txtF8name.Text
        My.Settings.Fzone9 = txtF9name.Text
        My.Settings.Fzone10 = txtF10name.Text

        If chkF1bypass.Checked = True Then
            My.Settings.F1bypass = True
        Else
            My.Settings.F1bypass = False
        End If
        If chkF2bypass.Checked = True Then
            My.Settings.F2bypass = True
        Else
            My.Settings.F2bypass = False
        End If
        If chkF3bypass.Checked = True Then
            My.Settings.F3bypass = True
        Else
            My.Settings.F3bypass = False
        End If
        If chkF4bypass.Checked = True Then
            My.Settings.F4bypass = True
        Else
            My.Settings.F4bypass = False
        End If
        If chkF5bypass.Checked = True Then
            My.Settings.F5bypass = True
        Else
            My.Settings.F5bypass = False
        End If
        If chkF6bypass.Checked = True Then
            My.Settings.F6bypass = True
        Else
            My.Settings.F6bypass = False
        End If
        If chkF7bypass.Checked = True Then
            My.Settings.F7bypass = True
        Else
            My.Settings.F7bypass = False
        End If
        If chkF8bypass.Checked = True Then
            My.Settings.F8bypass = True
        Else
            My.Settings.F8bypass = False
        End If
        If chkF9bypass.Checked = True Then
            My.Settings.F9bypass = True
        Else
            My.Settings.F9bypass = False
        End If
        If chkF10bypass.Checked = True Then
            My.Settings.F10bypass = True
        Else
            My.Settings.F10bypass = False
        End If
    End Sub

    Private Sub TextBox1_TextChanged_2(sender As Object, e As EventArgs) Handles txtS1delay.TextChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub ChkS1audible_CheckedChanged(sender As Object, e As EventArgs) Handles chkS1audible.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub ChkS1visual_CheckedChanged(sender As Object, e As EventArgs) Handles chkS1visual.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub ChkS1notifier_CheckedChanged(sender As Object, e As EventArgs) Handles chkS1notifier.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub ChkS1buzzer_CheckedChanged(sender As Object, e As EventArgs) Handles chkS1buzzer.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub ChkS2buzzer_CheckedChanged(sender As Object, e As EventArgs) Handles chkS2buzzer.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub ChkS2notifier_CheckedChanged(sender As Object, e As EventArgs) Handles chkS2notifier.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub ChkS2visual_CheckedChanged(sender As Object, e As EventArgs) Handles chkS2visual.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub ChkS2audible_CheckedChanged(sender As Object, e As EventArgs) Handles chkS2audible.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub Btn2Ssave_Click(sender As Object, e As EventArgs) Handles btn2Ssave.Click
        lblIndSaveStat.ForeColor = Color.Black
        lblIndSaveStat.Text = "Changes saved."

        My.Settings.S1duration = txtS1delay.Text

        If chkS1audible.Checked = True Then
            My.Settings.S1audible = True
        Else
            My.Settings.S1audible = False
        End If
        If chkS2audible.Checked = True Then
            My.Settings.S2audible = True
        Else
            My.Settings.S2audible = False
        End If
        If chkS1visual.Checked = True Then
            My.Settings.S1visible = True
        Else
            My.Settings.S1visible = False
        End If
        If chkS2visual.Checked = True Then
            My.Settings.S2visible = True
        Else
            My.Settings.S2visible = False
        End If
        If chkS1notifier.Checked = True Then
            My.Settings.S1notifier = True
        Else
            My.Settings.S1notifier = False
        End If
        If chkS2notifier.Checked = True Then
            My.Settings.S2notifier = True
        Else
            My.Settings.S2notifier = False
        End If
        If chkS1buzzer.Checked = True Then
            My.Settings.S1buzzer = True
        Else
            My.Settings.S1buzzer = False
        End If
        If chkS2buzzer.Checked = True Then
            My.Settings.S2buzzer = True
        Else
            My.Settings.S2buzzer = False
        End If
    End Sub

    Private Sub BtnNotepadSave_Click(sender As Object, e As EventArgs) Handles btnNotepadSave.Click
        lblIndSaveStat.ForeColor = Color.DarkGreen
        lblIndSaveStat.Text = "Saving..."

        My.Settings.NotepadContents = notepad.Text.ToString

        lblIndSaveStat.ForeColor = Color.Black
        lblIndSaveStat.Text = "Changes saved."
    End Sub

    Private Sub TextBox1_TextChanged_3(sender As Object, e As EventArgs) Handles notepad.TextChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub TextBox1_TextChanged_4(sender As Object, e As EventArgs) Handles txtHazAutoStopDelay.TextChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub BtnHazAutoStopSave_Click(sender As Object, e As EventArgs) Handles btnHazAutoStopSave.Click
        My.Settings.HazAutoStopDelay = txtHazAutoStopDelay.Text
        lblIndSaveStat.ForeColor = Color.Black
        lblIndSaveStat.Text = "Changes saved."
    End Sub

    Private Sub RadioButton2_CheckedChanged_1(sender As Object, e As EventArgs) Handles rdoHazASenabled.CheckedChanged
        If rdoHazASenabled.Checked = True Then
            My.Settings.HazAutoStop = True
        End If
    End Sub

    Private Sub RdoHazASdisabled_CheckedChanged(sender As Object, e As EventArgs) Handles rdoHazASdisabled.CheckedChanged
        If rdoHazASdisabled.Checked = True Then
            My.Settings.HazAutoStop = False
        End If
    End Sub

    Private Sub TabPage35_Click(sender As Object, e As EventArgs) Handles TabPage35.Click

    End Sub

    Private Sub TextBox4_TextChanged_1(sender As Object, e As EventArgs) Handles txthaz1name.TextChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub TextBox3_TextChanged_1(sender As Object, e As EventArgs) Handles txthaz2name.TextChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub TextBox2_TextChanged_1(sender As Object, e As EventArgs) Handles txthaz3name.TextChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub TextBox1_TextChanged_5(sender As Object, e As EventArgs) Handles txthaz4name.TextChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub BtnHazSave_Click(sender As Object, e As EventArgs) Handles btnHazSave.Click
        lblIndSaveStat.ForeColor = Color.Black
        lblIndSaveStat.Text = "Changes saved."

        My.Settings.Haz1name = txthaz1name.Text
        My.Settings.Haz2name = txthaz2name.Text
        My.Settings.Haz3name = txthaz3name.Text
        My.Settings.Haz4name = txthaz4name.Text
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles btnAgentTestMode.Click
        My.Settings.AgentTesting = True
        lblIndAgent.Text = "  TESTING  "
            lblIndAgent.BackColor = Color.Yellow
        lblIndAgent.ForeColor = Color.Black
        btnAgentTestMode.Enabled = False
        btnAgentEnable.Enabled = True
        btnAgentDisable.Enabled = True
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles btnAgentDisable.Click
        My.Settings.AgentEnabled = False
        My.Settings.AgentTesting = False
        lblIndAgent.Text = "  DISABLED  "
            lblIndAgent.ForeColor = Color.Black
        lblIndAgent.BackColor = Color.Transparent
        btnAgentDisable.Enabled = False
        btnAgentEnable.Enabled = True
        btnAgentTestMode.Enabled = False
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btnAgentEnable.Click
        My.Settings.AgentEnabled = True
        My.Settings.AgentTesting = False
        lblIndAgent.Text = "  ENABLED  "
            lblIndAgent.BackColor = Color.Red
        lblIndAgent.ForeColor = Color.White
        btnAgentEnable.Enabled = False
        btnAgentDisable.Enabled = False
        btnAgentTestMode.Enabled = True
    End Sub

    Private Sub Z2a2_CheckedChanged(sender As Object, e As EventArgs) Handles z2a2.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub Z1a1_CheckedChanged(sender As Object, e As EventArgs) Handles z1a1.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub Z1a2_CheckedChanged(sender As Object, e As EventArgs) Handles z1a2.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub Z1a3_CheckedChanged(sender As Object, e As EventArgs) Handles z1a3.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub Z1a4_CheckedChanged(sender As Object, e As EventArgs) Handles z1a4.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub Z2a4_CheckedChanged(sender As Object, e As EventArgs) Handles z2a4.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub Z3a4_CheckedChanged(sender As Object, e As EventArgs) Handles z3a4.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub Z4a4_CheckedChanged(sender As Object, e As EventArgs) Handles z4a4.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub Z4a3_CheckedChanged(sender As Object, e As EventArgs) Handles z4a3.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub Z3a3_CheckedChanged(sender As Object, e As EventArgs) Handles z3a3.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub Z2a3_CheckedChanged(sender As Object, e As EventArgs) Handles z2a3.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub Z2a1_CheckedChanged(sender As Object, e As EventArgs) Handles z2a1.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub Z3a1_CheckedChanged(sender As Object, e As EventArgs) Handles z3a1.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub Z3a2_CheckedChanged(sender As Object, e As EventArgs) Handles z3a2.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub Z4a2_CheckedChanged(sender As Object, e As EventArgs) Handles z4a2.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub Z4a1_CheckedChanged(sender As Object, e As EventArgs) Handles z4a1.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub Z5a1_CheckedChanged(sender As Object, e As EventArgs) Handles z5a1.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub Z5a2_CheckedChanged(sender As Object, e As EventArgs) Handles z5a2.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub Z5a3_CheckedChanged(sender As Object, e As EventArgs) Handles z5a3.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub Z5a4_CheckedChanged(sender As Object, e As EventArgs) Handles z5a4.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub Z6a4_CheckedChanged(sender As Object, e As EventArgs) Handles z6a4.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub Z6a3_CheckedChanged(sender As Object, e As EventArgs) Handles z6a3.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub Z6a2_CheckedChanged(sender As Object, e As EventArgs) Handles z6a2.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub Z6a1_CheckedChanged(sender As Object, e As EventArgs) Handles z6a1.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub Z7a1_CheckedChanged(sender As Object, e As EventArgs) Handles z7a1.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub Z8a1_CheckedChanged(sender As Object, e As EventArgs) Handles z8a1.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub CheckBox8_CheckedChanged(sender As Object, e As EventArgs) Handles z9a1.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub CheckBox4_CheckedChanged(sender As Object, e As EventArgs) Handles z10a1.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub CheckBox3_CheckedChanged(sender As Object, e As EventArgs) Handles z10a2.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub CheckBox7_CheckedChanged(sender As Object, e As EventArgs) Handles z9a2.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub Z8a2_CheckedChanged(sender As Object, e As EventArgs) Handles z8a2.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub Z7a2_CheckedChanged(sender As Object, e As EventArgs) Handles z7a2.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub Z7a3_CheckedChanged(sender As Object, e As EventArgs) Handles z7a3.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub Z7a4_CheckedChanged(sender As Object, e As EventArgs) Handles z7a4.CheckedChanged

    End Sub

    Private Sub Z8a4_CheckedChanged(sender As Object, e As EventArgs) Handles z8a4.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub Z8a3_CheckedChanged(sender As Object, e As EventArgs) Handles z8a3.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub CheckBox6_CheckedChanged(sender As Object, e As EventArgs) Handles z9a3.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub CheckBox5_CheckedChanged(sender As Object, e As EventArgs) Handles z9a4.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles z10a4.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub CheckBox2_CheckedChanged(sender As Object, e As EventArgs) Handles z10a3.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub Z23a4_CheckedChanged(sender As Object, e As EventArgs) Handles z23a4.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub Z24a4_CheckedChanged(sender As Object, e As EventArgs) Handles z24a4.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub Z21a4_CheckedChanged(sender As Object, e As EventArgs) Handles z21a4.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub Z21a3_CheckedChanged(sender As Object, e As EventArgs) Handles z21a3.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub Z21a2_CheckedChanged(sender As Object, e As EventArgs) Handles z21a2.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub Z21a1_CheckedChanged(sender As Object, e As EventArgs) Handles z21a1.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub Z22a1_CheckedChanged(sender As Object, e As EventArgs) Handles z22a1.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub Z22a2_CheckedChanged(sender As Object, e As EventArgs) Handles z22a2.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub Z22a3_CheckedChanged(sender As Object, e As EventArgs) Handles z22a3.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub Z23a3_CheckedChanged(sender As Object, e As EventArgs) Handles z23a3.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub Z23a2_CheckedChanged(sender As Object, e As EventArgs) Handles z23a2.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub Z23a1_CheckedChanged(sender As Object, e As EventArgs) Handles z23a1.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub Z24a1_CheckedChanged(sender As Object, e As EventArgs) Handles z24a1.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub Z24a2_CheckedChanged(sender As Object, e As EventArgs) Handles z24a2.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub Z24a3_CheckedChanged(sender As Object, e As EventArgs) Handles z24a3.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub Z23_CheckedChanged(sender As Object, e As EventArgs) Handles z22a4.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub Z11a4_CheckedChanged(sender As Object, e As EventArgs) Handles z11a4.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub Z11a3_CheckedChanged(sender As Object, e As EventArgs) Handles z11a3.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub Z11a2_CheckedChanged(sender As Object, e As EventArgs) Handles z11a2.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub Z11a1_CheckedChanged(sender As Object, e As EventArgs) Handles z11a1.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub Z12a1_CheckedChanged(sender As Object, e As EventArgs) Handles z12a1.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub Z12a2_CheckedChanged(sender As Object, e As EventArgs) Handles z12a2.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub Z12a3_CheckedChanged(sender As Object, e As EventArgs) Handles z12a3.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub Z12a4_CheckedChanged(sender As Object, e As EventArgs) Handles z12a4.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub Z13a4_CheckedChanged(sender As Object, e As EventArgs) Handles z13a4.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub Z13a3_CheckedChanged(sender As Object, e As EventArgs) Handles z13a3.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub Z13a2_CheckedChanged(sender As Object, e As EventArgs) Handles z13a2.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub Z13a1_CheckedChanged(sender As Object, e As EventArgs) Handles z13a1.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub Z14a1_CheckedChanged(sender As Object, e As EventArgs) Handles z14a1.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub Z14a2_CheckedChanged(sender As Object, e As EventArgs) Handles z14a2.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub Z14a3_CheckedChanged(sender As Object, e As EventArgs) Handles z14a3.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub Z14a4_CheckedChanged(sender As Object, e As EventArgs) Handles z14a4.CheckedChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub BtnAgentBehavSave_Click(sender As Object, e As EventArgs) Handles btnAgentBehavSave.Click
        'indicate save operation which may be lengthy on lower end hardware
        lblIndSaveStat.ForeColor = Color.DarkGreen
        lblIndSaveStat.Text = "Saving..."

        'save internal zones configs
        If z1a1.Checked = True Then
            My.Settings.z1a1 = True
        Else
            My.Settings.z1a1 = False
        End If
        If z1a2.Checked = True Then
            My.Settings.z1a2 = True
        Else
            My.Settings.z1a2 = False
        End If
        If z1a3.Checked = True Then
            My.Settings.z1a3 = True
        Else
            My.Settings.z1a3 = False
        End If
        If z1a4.Checked = True Then
            My.Settings.z1a4 = True
        Else
            My.Settings.z1a4 = False
        End If
        If z2a1.Checked = True Then
            My.Settings.z2a1 = True
        Else
            My.Settings.z2a1 = False
        End If
        If z2a2.Checked = True Then
            My.Settings.z2a2 = True
        Else
            My.Settings.z2a2 = False
        End If
        If z2a3.Checked = True Then
            My.Settings.z2a3 = True
        Else
            My.Settings.z2a3 = False
        End If
        If z2a4.Checked = True Then
            My.Settings.z2a4 = True
        Else
            My.Settings.z2a4 = False
        End If
        If z3a1.Checked = True Then
            My.Settings.z3a1 = True
        Else
            My.Settings.z3a1 = False
        End If
        If z3a2.Checked = True Then
            My.Settings.z3a2 = True
        Else
            My.Settings.z3a2 = False
        End If
        If z3a3.Checked = True Then
            My.Settings.z3a3 = True
        Else
            My.Settings.z3a3 = False
        End If
        If z3a4.Checked = True Then
            My.Settings.z3a4 = True
        Else
            My.Settings.z3a4 = False
        End If
        If z4a1.Checked = True Then
            My.Settings.z4a1 = True
        Else
            My.Settings.z4a1 = False
        End If
        If z4a2.Checked = True Then
            My.Settings.z4a2 = True
        Else
            My.Settings.z4a2 = False
        End If
        If z4a3.Checked = True Then
            My.Settings.z4a3 = True
        Else
            My.Settings.z4a3 = False
        End If
        If z4a4.Checked = True Then
            My.Settings.z4a4 = True
        Else
            My.Settings.z4a4 = False
        End If
        If z5a1.Checked = True Then
            My.Settings.z5a1 = True
        Else
            My.Settings.z5a1 = False
        End If
        If z5a2.Checked = True Then
            My.Settings.z5a2 = True
        Else
            My.Settings.z5a2 = False
        End If
        If z5a3.Checked = True Then
            My.Settings.z5a3 = True
        Else
            My.Settings.z5a3 = False
        End If
        If z5a4.Checked = True Then
            My.Settings.z5a4 = True
        Else
            My.Settings.z5a4 = False
        End If
        If z6a1.Checked = True Then
            My.Settings.z6a1 = True
        Else
            My.Settings.z6a1 = False
        End If
        If z6a2.Checked = True Then
            My.Settings.z6a2 = True
        Else
            My.Settings.z6a2 = False
        End If
        If z6a3.Checked = True Then
            My.Settings.z6a3 = True
        Else
            My.Settings.z6a3 = False
        End If
        If z6a4.Checked = True Then
            My.Settings.z6a4 = True
        Else
            My.Settings.z6a4 = False
        End If
        If z7a1.Checked = True Then
            My.Settings.z7a1 = True
        Else
            My.Settings.z7a1 = False
        End If
        If z7a2.Checked = True Then
            My.Settings.z7a2 = True
        Else
            My.Settings.z7a2 = False
        End If
        If z7a3.Checked = True Then
            My.Settings.z7a3 = True
        Else
            My.Settings.z7a3 = False
        End If
        If z7a4.Checked = True Then
            My.Settings.z7a4 = True
        Else
            My.Settings.z7a4 = False
        End If
        If z8a1.Checked = True Then
            My.Settings.z8a1 = True
        Else
            My.Settings.z8a1 = False
        End If
        If z8a2.Checked = True Then
            My.Settings.z8a2 = True
        Else
            My.Settings.z8a2 = False
        End If
        If z8a3.Checked = True Then
            My.Settings.z8a3 = True
        Else
            My.Settings.z8a3 = False
        End If
        If z8a4.Checked = True Then
            My.Settings.z8a4 = True
        Else
            My.Settings.z8a4 = False
        End If
        If z9a1.checked = True Then
            My.Settings.z9a1 = True
        Else
            My.Settings.z9a1 = False
        End If
        If z9a2.Checked = True Then
            My.Settings.z9a2 = True
        Else
            My.Settings.z9a2 = False
        End If
        If z9a3.Checked = True Then
            My.Settings.z9a3 = True
        Else
            My.Settings.z9a3 = False
        End If
        If z9a4.Checked = True Then
            My.Settings.z9a4 = True
        Else
            My.Settings.z9a4 = False
        End If
        If z10a1.Checked = True Then
            My.Settings.z10a1 = True
        Else
            My.Settings.z10a1 = False
        End If
        If z10a2.Checked = True Then
            My.Settings.z10a2 = True
        Else
            My.Settings.z10a2 = False
        End If
        If z10a3.Checked = True Then
            My.Settings.z10a3 = True
        Else
            My.Settings.z10a3 = False
        End If
        If z10a4.Checked = True Then
            My.Settings.z10a4 = True
        Else
            My.Settings.z10a4 = False
        End If

        'save extender 1 zones configs
        If z11a1.Checked = True Then
            My.Settings.z11a1 = True
        Else
            My.Settings.z11a1 = False
        End If
        If z11a2.Checked = True Then
            My.Settings.z11a2 = True
        Else
            My.Settings.z11a2 = False
        End If
        If z11a3.Checked = True Then
            My.Settings.z11a3 = True
        Else
            My.Settings.z11a3 = False
        End If
        If z11a4.Checked = True Then
            My.Settings.z11a4 = True
        Else
            My.Settings.z11a4 = False
        End If
        If z12a1.Checked = True Then
            My.Settings.z12a1 = True
        Else
            My.Settings.z12a1 = False
        End If
        If z12a2.Checked = True Then
            My.Settings.z12a2 = True
        Else
            My.Settings.z12a2 = False
        End If
        If z12a3.Checked = True Then
            My.Settings.z12a3 = True
        Else
            My.Settings.z12a3 = False
        End If
        If z12a4.Checked = True Then
            My.Settings.z12a4 = True
        Else
            My.Settings.z12a4 = False
        End If
        If z13a1.Checked = True Then
            My.Settings.z13a1 = True
        Else
            My.Settings.z13a1 = False
        End If
        If z13a2.Checked = True Then
            My.Settings.z13a2 = True
        Else
            My.Settings.z13a2 = False
        End If
        If z13a3.Checked = True Then
            My.Settings.z13a3 = True
        Else
            My.Settings.z13a3 = False
        End If
        If z13a4.Checked = True Then
            My.Settings.z13a4 = True
        Else
            My.Settings.z13a4 = False
        End If
        If z14a1.Checked = True Then
            My.Settings.z14a1 = True
        Else
            My.Settings.z14a1 = False
        End If
        If z14a2.Checked = True Then
            My.Settings.z14a2 = True
        Else
            My.Settings.z14a2 = False
        End If
        If z14a3.Checked = True Then
            My.Settings.z14a3 = True
        Else
            My.Settings.z14a3 = False
        End If
        If z14a4.Checked = True Then
            My.Settings.z14a4 = True
        Else
            My.Settings.z14a4 = False
        End If

        'save extender 2 zones configs
        If z21a1.Checked = True Then
            My.Settings.z21a1 = True
        Else
            My.Settings.z21a1 = False
        End If
        If z21a2.Checked = True Then
            My.Settings.z21a2 = True
        Else
            My.Settings.z21a2 = False
        End If
        If z21a3.Checked = True Then
            My.Settings.z21a3 = True
        Else
            My.Settings.z21a3 = False
        End If
        If z21a4.Checked = True Then
            My.Settings.z21a4 = True
        Else
            My.Settings.z21a4 = False
        End If
        If z22a1.Checked = True Then
            My.Settings.z22a1 = True
        Else
            My.Settings.z22a1 = False
        End If
        If z22a2.Checked = True Then
            My.Settings.z22a2 = True
        Else
            My.Settings.z22a2 = False
        End If
        If z22a3.Checked = True Then
            My.Settings.z22a3 = True
        Else
            My.Settings.z22a3 = False
        End If
        If z22a4.Checked = True Then
            My.Settings.z22a4 = True
        Else
            My.Settings.z22a4 = False
        End If
        If z23a1.Checked = True Then
            My.Settings.z23a1 = True
        Else
            My.Settings.z23a1 = False
        End If
        If z23a2.Checked = True Then
            My.Settings.z23a2 = True
        Else
            My.Settings.z23a2 = False
        End If
        If z23a3.Checked = True Then
            My.Settings.z23a3 = True
        Else
            My.Settings.z23a3 = False
        End If
        If z23a4.Checked = True Then
            My.Settings.z23a4 = True
        Else
            My.Settings.z23a4 = False
        End If
        If z24a1.Checked = True Then
            My.Settings.z24a1 = True
        Else
            My.Settings.z24a1 = False
        End If
        If z24a2.Checked = True Then
            My.Settings.z24a2 = True
        Else
            My.Settings.z24a2 = False
        End If
        If z24a3.Checked = True Then
            My.Settings.z24a3 = True
        Else
            My.Settings.z24a3 = False
        End If
        If z24a4.Checked = True Then
            My.Settings.z24a4 = True
        Else
            My.Settings.z24a4 = False
        End If
        'I hated every moment of this
        'my hands hurt

        lblIndSaveStat.ForeColor = Color.Black
        lblIndSaveStat.Text = "Changes saved."

        My.Settings.AgentDelay = txtAgentDelay.Text
        My.Settings.AgentCountdown = txtAgentCountdown.Text
    End Sub

    Private Sub TxtAgentDelay_TextChanged(sender As Object, e As EventArgs) Handles txtAgentDelay.TextChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub TxtAgentCountdown_TextChanged(sender As Object, e As EventArgs) Handles txtAgentCountdown.TextChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub BtnPWsave_Click(sender As Object, e As EventArgs) Handles btnPWsave.Click
        If txtPWset1.Text = txtPWset2.Text And txtPWset1 IsNot Nothing Then
            My.Settings.ControlLockCode = txtPWset2.Text
            MessageBox.Show("Your new lock code has been set successfully.", "Security", MessageBoxButtons.OK, MessageBoxIcon.Information)
            My.Settings.ControlLockSet = True
        Else
            MessageBox.Show("The lock codes you entered didn't match or were empty. The lock code was not changed.", "Security", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub

    Private Sub RdoQuitEnabled_CheckedChanged(sender As Object, e As EventArgs) Handles rdoQuitEnabled.CheckedChanged
        If rdoQuitEnabled.Checked = True Then
            My.Settings.ControlPreventQuit = False
        End If
    End Sub

    Private Sub RdoQuitDisabled_CheckedChanged(sender As Object, e As EventArgs) Handles rdoQuitDisabled.CheckedChanged
        If rdoQuitDisabled.Checked = True Then
            My.Settings.ControlPreventQuit = True
        End If
    End Sub

    Private Sub BtnForceQuitDone_Click(sender As Object, e As EventArgs) Handles btnForceQuitDone.Click
        If txtForceQuitBox.Text = My.Settings.ControlLockCode Then
            Quit.Show()
        Else
            MessageBox.Show("Your lock code did not match the one on record. You cannot force quit PowerCommander without your lock code.", "Security", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub

    Private Sub BtnForceQuit_Click(sender As Object, e As EventArgs) Handles btnForceQuit.Click
        fqLbl.Visible = True
        txtForceQuitBox.Visible = True
        btnForceQuitDone.Visible = True
    End Sub

    Private Sub BtnLockCodeRemoved_Click(sender As Object, e As EventArgs) Handles btnLockCodeRemoved.Click
        My.Settings.ControlLockCode = Nothing
        My.Settings.ControlLockSet = False
        MessageBox.Show("Your lock code has been removed. You won't be able to lock the control panel until you set a new lock code. If you are asked for a lock code at any point, simply press OK without entering one.", "Security", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub

    Private Sub Rdo2Sdisabled_CheckedChanged(sender As Object, e As EventArgs) Handles rdo2Sdisabled.CheckedChanged
        If rdo2Sdisabled.Checked = True Then
            My.Settings.S2enabled = False
        End If
    End Sub

    Private Sub Rdo2Senabled_CheckedChanged(sender As Object, e As EventArgs) Handles rdo2Senabled.CheckedChanged
        If rdo2Senabled.Checked = True Then
            My.Settings.S2enabled = True
        End If
    End Sub

    Private Sub TrackBar1_Scroll(sender As Object, e As EventArgs) Handles ColorSlider.Scroll
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub BtnColorSave_Click(sender As Object, e As EventArgs) Handles btnColorSave.Click
        My.Settings.InterfaceColor = ColorSlider.Value.ToString()
        lblIndSaveStat.ForeColor = Color.Black
        lblIndSaveStat.Text = "Changes saved."
    End Sub

    Private Sub BtnSailorMode_Click(sender As Object, e As EventArgs) Handles btnSailorMode.Click   'a girl thought this would be funny so I'm doing it
        MainWin.lblOF1.Visible = True
        MainWin.GroupBox1.Text = "OH SHIT THE"
        MainWin.GroupBox2.Text = "PLACES THAT SHIT CAN GO WRONG"
        MainWin.lblTbl.Text = "OH SHIT"
        MainWin.lblTblAck.Text = "I GET IT"
        MainWin.lblAlm.Text = "OH FUCK"
        MainWin.lblSil.Text = "SHUT UP"
        MainWin.lblHaz.Text = "OH DAMN"
        MainWin.lblHazAck.Text = "STFU"
        MainWin.lblAbort.Text = "DELETUS"
        MainWin.lblAbort.Text = "THE FETUS"

        MainWin.ft1.Text = "OH SHIT"
        MainWin.ft2.Text = "OH SHIT"
        MainWin.ft3.Text = "OH SHIT"
        MainWin.ft4.Text = "OH SHIT"
        MainWin.ft5.Text = "OH SHIT"
        MainWin.ft6.Text = "OH SHIT"
        MainWin.ft7.Text = "OH SHIT"
        MainWin.ft8.Text = "OH SHIT"
        MainWin.ft9.Text = "OH SHIT"
        MainWin.ft10.Text = "OH SHIT"

        MainWin.fa1.Text = "OH FUCK"
        MainWin.fa2.Text = "OH FUCK"
        MainWin.fa3.Text = "OH FUCK"
        MainWin.fa4.Text = "OH FUCK"
        MainWin.fa5.Text = "OH FUCK"
        MainWin.fa6.Text = "OH FUCK"
        MainWin.fa7.Text = "OH FUCK"
        MainWin.fa8.Text = "OH FUCK"
        MainWin.fa9.Text = "OH FUCK"
        MainWin.fa10.Text = "OH FUCK"
    End Sub

    Private Sub BtnLampTest_Click(sender As Object, e As EventArgs) Handles btnLampTest.Click
        MainWin.LCD.Text = "Lamp test completed. Restart PowerCommander to resynchronize the display."

        MainWin.LEDpower.Visible = True
        MainWin.LEDtrouble.Visible = True
        MainWin.LEDfire.Visible = True
        MainWin.LEDfireSil.Visible = True
        MainWin.LEDhazard.Visible = True
        MainWin.LEDtblAck.Visible = True
        MainWin.LEDhazAck.Visible = True
        MainWin.LEDhush.Visible = True
        MainWin.LEDagent.Visible = True
        MainWin.LEDabort.Visible = True

        MainWin.btnCtlReset.Enabled = True
        MainWin.btnCtlSil.Enabled = True
        MainWin.btnCtlTblAck.Enabled = True
        MainWin.btnCtlHazAck.Enabled = True
        MainWin.btnCtlHush.Enabled = True
        MainWin.btnCtlAgentAbort.Enabled = True

        MainWin.LEDtblNAC.Visible = True
        MainWin.LEDtblIDC.Visible = True
        MainWin.LEDtblComm.Visible = True
        MainWin.LEDtblPower.Visible = True
        MainWin.LEDtblTemp.Visible = True
        MainWin.LEDtblExtender.Visible = True

        MainWin.LEDz1TBL.Visible = True
        MainWin.LEDz2TBL.Visible = True
        MainWin.LEDz3TBL.Visible = True
        MainWin.LEDz4TBL.Visible = True
        MainWin.LEDz5TBL.Visible = True
        MainWin.LEDz6TBL.Visible = True
        MainWin.LEDz7TBL.Visible = True
        MainWin.LEDz8TBL.Visible = True
        MainWin.LEDz9TBL.Visible = True
        MainWin.LEDz10TBL.Visible = True

        MainWin.LEDz1ALM.Visible = True
        MainWin.LEDz2ALM.Visible = True
        MainWin.LEDz3ALM.Visible = True
        MainWin.LEDz4ALM.Visible = True
        MainWin.LEDz5ALM.Visible = True
        MainWin.LEDz6ALM.Visible = True
        MainWin.LEDz7ALM.Visible = True
        MainWin.LEDz8ALM.Visible = True
        MainWin.LEDz9ALM.Visible = True
        MainWin.LEDz10ALM.Visible = True
    End Sub

    Private Sub BtnSaveInfo_Click(sender As Object, e As EventArgs) Handles btnSaveInfo.Click
        lblIndSaveStat.ForeColor = Color.Black
        lblIndSaveStat.Text = "Changes saved."

        My.Settings.adminFirstName = txtFirstName.Text
        My.Settings.adminLastName = txtLastName.Text
        My.Settings.adminEmail = txtEmail.Text
        My.Settings.adminPhone1 = txtPhone1.Text
        My.Settings.adminPhone2 = txtPhone2.Text
        My.Settings.adminDiscord = txtDiscord.Text
        My.Settings.adminNotes = txtNotes.Text
    End Sub

    Private Sub TxtFirstName_TextChanged(sender As Object, e As EventArgs) Handles txtFirstName.TextChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub TxtLastName_TextChanged(sender As Object, e As EventArgs) Handles txtLastName.TextChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub TxtPhone_TextChanged(sender As Object, e As EventArgs) Handles txtEmail.TextChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub Tx_TextChanged(sender As Object, e As EventArgs) Handles txtPhone1.TextChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub TxtPhone2_TextChanged(sender As Object, e As EventArgs) Handles txtPhone2.TextChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub TxtDiscord_TextChanged(sender As Object, e As EventArgs) Handles txtDiscord.TextChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub TxtNotes_TextChanged(sender As Object, e As EventArgs) Handles txtNotes.TextChanged
        lblIndSaveStat.ForeColor = Color.Red
        lblIndSaveStat.Text = "Changes unsaved."
    End Sub

    Private Sub BtnInfoRemove_Click(sender As Object, e As EventArgs) Handles btnInfoRemove.Click
        My.Settings.adminFirstName = Nothing
        My.Settings.adminLastName = Nothing
        My.Settings.adminEmail = Nothing
        My.Settings.adminPhone1 = Nothing
        My.Settings.adminPhone2 = Nothing
        My.Settings.adminDiscord = Nothing
        My.Settings.adminNotes = Nothing

        txtFirstName.Text = My.Settings.adminFirstName
        txtLastName.Text = My.Settings.adminLastName
        txtEmail.Text = My.Settings.adminEmail
        txtPhone1.Text = My.Settings.adminPhone1
        txtPhone2.Text = My.Settings.adminPhone2
        txtDiscord.Text = My.Settings.adminDiscord
        txtNotes.Text = My.Settings.adminNotes

        lblIndSaveStat.ForeColor = Color.Black
        lblIndSaveStat.Text = "Changes saved."
    End Sub
End Class