﻿Public Class PortSelector
    Private Sub BtnCancel_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub PortSelector_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If My.Settings.PortIsSelected = False Then
            Me.ControlBox = False
            btnDisconnect.Enabled = False
            btnClose.Enabled = False
        ElseIf My.Settings.PortIsSelected = True Then
            btnConnect.Enabled = False
        End If

        For Each AvailableSerialPorts As String In MainWin.serial.GetPortNames()

            cbbPorts.Items.Add(AvailableSerialPorts)
            MainWin.serial.ReadTimeout = 2000

            cbbPorts.Text = AvailableSerialPorts
        Next


    End Sub

    Private Sub BtnConnect_Click(sender As Object, e As EventArgs) Handles btnConnect.Click
        MainWin.serial.BaudRate = "9600"

        MainWin.serial.PortName = cbbPorts.SelectedItem

        If MainWin.serial.IsOpen = False Then
            MainWin.serial.Open()
        End If
        btnDisconnect.Enabled = True
        btnConnect.Enabled = False
        btnClose.Enabled = True

        My.Settings.PortIsSelected = True

        cbbPorts.Enabled = False
    End Sub

    Private Sub BtnDisconnect_Click(sender As Object, e As EventArgs) Handles btnDisconnect.Click
        If MainWin.serial.IsOpen = True Then
            MainWin.serial.Close()
        End If

        btnDisconnect.Enabled = False
        btnClose.Enabled = True

        My.Settings.PortIsSelected = False

        cbbPorts.Enabled = True
        btnConnect.Enabled = True
    End Sub
End Class