﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Configuration
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Configuration))
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btnDone = New System.Windows.Forms.Button()
        Me.lblIndSaveStat = New System.Windows.Forms.Label()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.TabControl2 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.btnSysNameSave = New System.Windows.Forms.Button()
        Me.txtSysName = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.Label149 = New System.Windows.Forms.Label()
        Me.btnColorSave = New System.Windows.Forms.Button()
        Me.Label148 = New System.Windows.Forms.Label()
        Me.Label147 = New System.Windows.Forms.Label()
        Me.Label146 = New System.Windows.Forms.Label()
        Me.Label145 = New System.Windows.Forms.Label()
        Me.Label144 = New System.Windows.Forms.Label()
        Me.Label143 = New System.Windows.Forms.Label()
        Me.Label142 = New System.Windows.Forms.Label()
        Me.Label141 = New System.Windows.Forms.Label()
        Me.Label140 = New System.Windows.Forms.Label()
        Me.ColorSlider = New System.Windows.Forms.TrackBar()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.TabControl4 = New System.Windows.Forms.TabControl()
        Me.TabPage10 = New System.Windows.Forms.TabPage()
        Me.TabControl6 = New System.Windows.Forms.TabControl()
        Me.TabPage24 = New System.Windows.Forms.TabPage()
        Me.TabPage23 = New System.Windows.Forms.TabPage()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.TabPage22 = New System.Windows.Forms.TabPage()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.TabPage27 = New System.Windows.Forms.TabPage()
        Me.btnNotepadSave = New System.Windows.Forms.Button()
        Me.notepad = New System.Windows.Forms.TextBox()
        Me.TabPage11 = New System.Windows.Forms.TabPage()
        Me.TabControl5 = New System.Windows.Forms.TabControl()
        Me.TabPage16 = New System.Windows.Forms.TabPage()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.btnFireACDsave = New System.Windows.Forms.Button()
        Me.txtFireACDbox = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TabPage17 = New System.Windows.Forms.TabPage()
        Me.grbUnsilence = New System.Windows.Forms.GroupBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.rdoUnsilenceDisable = New System.Windows.Forms.RadioButton()
        Me.rdoUnsilenceEnable = New System.Windows.Forms.RadioButton()
        Me.grbSilence = New System.Windows.Forms.GroupBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.rdoSilenceDisable = New System.Windows.Forms.RadioButton()
        Me.rdoSilenceEnable = New System.Windows.Forms.RadioButton()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.TabPage21 = New System.Windows.Forms.TabPage()
        Me.Label54 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.btnFASSave = New System.Windows.Forms.Button()
        Me.txtFireAutoSilDelay = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.rdoAutoSilDisabled = New System.Windows.Forms.RadioButton()
        Me.rdoAutoSilEnabled = New System.Windows.Forms.RadioButton()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.TabPage18 = New System.Windows.Forms.TabPage()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.TabPage19 = New System.Windows.Forms.TabPage()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.chkS2buzzer = New System.Windows.Forms.CheckBox()
        Me.chkS2notifier = New System.Windows.Forms.CheckBox()
        Me.chkS2visual = New System.Windows.Forms.CheckBox()
        Me.Label53 = New System.Windows.Forms.Label()
        Me.chkS2audible = New System.Windows.Forms.CheckBox()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.chkS1buzzer = New System.Windows.Forms.CheckBox()
        Me.chkS1notifier = New System.Windows.Forms.CheckBox()
        Me.chkS1visual = New System.Windows.Forms.CheckBox()
        Me.chkS1audible = New System.Windows.Forms.CheckBox()
        Me.btn2Ssave = New System.Windows.Forms.Button()
        Me.txtS1delay = New System.Windows.Forms.TextBox()
        Me.Label52 = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.rdo2Senabled = New System.Windows.Forms.RadioButton()
        Me.rdo2Sdisabled = New System.Windows.Forms.RadioButton()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.TabPage20 = New System.Windows.Forms.TabPage()
        Me.btnSaveZones = New System.Windows.Forms.Button()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.chkF10bypass = New System.Windows.Forms.CheckBox()
        Me.chkF9bypass = New System.Windows.Forms.CheckBox()
        Me.txtF10name = New System.Windows.Forms.TextBox()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.txtF9name = New System.Windows.Forms.TextBox()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.chkF8bypass = New System.Windows.Forms.CheckBox()
        Me.chkF7bypass = New System.Windows.Forms.CheckBox()
        Me.chkF6bypass = New System.Windows.Forms.CheckBox()
        Me.chkF5bypass = New System.Windows.Forms.CheckBox()
        Me.txtF8name = New System.Windows.Forms.TextBox()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.txtF7name = New System.Windows.Forms.TextBox()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.txtF6name = New System.Windows.Forms.TextBox()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.txtF5name = New System.Windows.Forms.TextBox()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.chkF4bypass = New System.Windows.Forms.CheckBox()
        Me.chkF3bypass = New System.Windows.Forms.CheckBox()
        Me.chkF2bypass = New System.Windows.Forms.CheckBox()
        Me.chkF1bypass = New System.Windows.Forms.CheckBox()
        Me.txtF4name = New System.Windows.Forms.TextBox()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.txtF3name = New System.Windows.Forms.TextBox()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.txtF2name = New System.Windows.Forms.TextBox()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.txtF1name = New System.Windows.Forms.TextBox()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.TabPage12 = New System.Windows.Forms.TabPage()
        Me.TabControl8 = New System.Windows.Forms.TabControl()
        Me.TabPage34 = New System.Windows.Forms.TabPage()
        Me.Label56 = New System.Windows.Forms.Label()
        Me.btnHazAutoStopSave = New System.Windows.Forms.Button()
        Me.txtHazAutoStopDelay = New System.Windows.Forms.TextBox()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.rdoHazASdisabled = New System.Windows.Forms.RadioButton()
        Me.rdoHazASenabled = New System.Windows.Forms.RadioButton()
        Me.Label55 = New System.Windows.Forms.Label()
        Me.TabPage26 = New System.Windows.Forms.TabPage()
        Me.Label57 = New System.Windows.Forms.Label()
        Me.TabPage35 = New System.Windows.Forms.TabPage()
        Me.btnHazSave = New System.Windows.Forms.Button()
        Me.txthaz4name = New System.Windows.Forms.TextBox()
        Me.Label58 = New System.Windows.Forms.Label()
        Me.txthaz3name = New System.Windows.Forms.TextBox()
        Me.Label59 = New System.Windows.Forms.Label()
        Me.txthaz2name = New System.Windows.Forms.TextBox()
        Me.Label60 = New System.Windows.Forms.Label()
        Me.txthaz1name = New System.Windows.Forms.TextBox()
        Me.Label61 = New System.Windows.Forms.Label()
        Me.Label62 = New System.Windows.Forms.Label()
        Me.TabPage13 = New System.Windows.Forms.TabPage()
        Me.TabControl9 = New System.Windows.Forms.TabControl()
        Me.TabPage38 = New System.Windows.Forms.TabPage()
        Me.RichTextBox2 = New System.Windows.Forms.RichTextBox()
        Me.Label63 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.TabPage39 = New System.Windows.Forms.TabPage()
        Me.Label65 = New System.Windows.Forms.Label()
        Me.btnAgentTestMode = New System.Windows.Forms.Button()
        Me.btnAgentDisable = New System.Windows.Forms.Button()
        Me.btnAgentEnable = New System.Windows.Forms.Button()
        Me.lblIndAgent = New System.Windows.Forms.Label()
        Me.Label64 = New System.Windows.Forms.Label()
        Me.TabPage40 = New System.Windows.Forms.TabPage()
        Me.GroupBox12 = New System.Windows.Forms.GroupBox()
        Me.Label128 = New System.Windows.Forms.Label()
        Me.GroupBox10 = New System.Windows.Forms.GroupBox()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Label126 = New System.Windows.Forms.Label()
        Me.CheckBox25 = New System.Windows.Forms.CheckBox()
        Me.CheckBox26 = New System.Windows.Forms.CheckBox()
        Me.CheckBox27 = New System.Windows.Forms.CheckBox()
        Me.CheckBox28 = New System.Windows.Forms.CheckBox()
        Me.CheckBox29 = New System.Windows.Forms.CheckBox()
        Me.CheckBox30 = New System.Windows.Forms.CheckBox()
        Me.CheckBox31 = New System.Windows.Forms.CheckBox()
        Me.CheckBox32 = New System.Windows.Forms.CheckBox()
        Me.CheckBox49 = New System.Windows.Forms.CheckBox()
        Me.CheckBox50 = New System.Windows.Forms.CheckBox()
        Me.CheckBox51 = New System.Windows.Forms.CheckBox()
        Me.CheckBox52 = New System.Windows.Forms.CheckBox()
        Me.CheckBox53 = New System.Windows.Forms.CheckBox()
        Me.CheckBox54 = New System.Windows.Forms.CheckBox()
        Me.CheckBox55 = New System.Windows.Forms.CheckBox()
        Me.Label105 = New System.Windows.Forms.Label()
        Me.Label106 = New System.Windows.Forms.Label()
        Me.CheckBox56 = New System.Windows.Forms.CheckBox()
        Me.Label107 = New System.Windows.Forms.Label()
        Me.Label108 = New System.Windows.Forms.Label()
        Me.Label109 = New System.Windows.Forms.Label()
        Me.Label110 = New System.Windows.Forms.Label()
        Me.Label111 = New System.Windows.Forms.Label()
        Me.Label112 = New System.Windows.Forms.Label()
        Me.Label113 = New System.Windows.Forms.Label()
        Me.Label114 = New System.Windows.Forms.Label()
        Me.GroupBox9 = New System.Windows.Forms.GroupBox()
        Me.z24a4 = New System.Windows.Forms.CheckBox()
        Me.z24a3 = New System.Windows.Forms.CheckBox()
        Me.z24a2 = New System.Windows.Forms.CheckBox()
        Me.z24a1 = New System.Windows.Forms.CheckBox()
        Me.z23a4 = New System.Windows.Forms.CheckBox()
        Me.z23a3 = New System.Windows.Forms.CheckBox()
        Me.z23a2 = New System.Windows.Forms.CheckBox()
        Me.z23a1 = New System.Windows.Forms.CheckBox()
        Me.z22a4 = New System.Windows.Forms.CheckBox()
        Me.z22a3 = New System.Windows.Forms.CheckBox()
        Me.z22a2 = New System.Windows.Forms.CheckBox()
        Me.z22a1 = New System.Windows.Forms.CheckBox()
        Me.z21a4 = New System.Windows.Forms.CheckBox()
        Me.z21a3 = New System.Windows.Forms.CheckBox()
        Me.z21a2 = New System.Windows.Forms.CheckBox()
        Me.Label91 = New System.Windows.Forms.Label()
        Me.Label92 = New System.Windows.Forms.Label()
        Me.z21a1 = New System.Windows.Forms.CheckBox()
        Me.Label93 = New System.Windows.Forms.Label()
        Me.Label94 = New System.Windows.Forms.Label()
        Me.Label95 = New System.Windows.Forms.Label()
        Me.Label96 = New System.Windows.Forms.Label()
        Me.Label101 = New System.Windows.Forms.Label()
        Me.Label102 = New System.Windows.Forms.Label()
        Me.Label103 = New System.Windows.Forms.Label()
        Me.Label104 = New System.Windows.Forms.Label()
        Me.GroupBox11 = New System.Windows.Forms.GroupBox()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Label125 = New System.Windows.Forms.Label()
        Me.CheckBox57 = New System.Windows.Forms.CheckBox()
        Me.CheckBox58 = New System.Windows.Forms.CheckBox()
        Me.CheckBox59 = New System.Windows.Forms.CheckBox()
        Me.CheckBox60 = New System.Windows.Forms.CheckBox()
        Me.CheckBox61 = New System.Windows.Forms.CheckBox()
        Me.CheckBox62 = New System.Windows.Forms.CheckBox()
        Me.CheckBox63 = New System.Windows.Forms.CheckBox()
        Me.CheckBox64 = New System.Windows.Forms.CheckBox()
        Me.CheckBox65 = New System.Windows.Forms.CheckBox()
        Me.CheckBox66 = New System.Windows.Forms.CheckBox()
        Me.CheckBox67 = New System.Windows.Forms.CheckBox()
        Me.CheckBox68 = New System.Windows.Forms.CheckBox()
        Me.CheckBox69 = New System.Windows.Forms.CheckBox()
        Me.CheckBox70 = New System.Windows.Forms.CheckBox()
        Me.CheckBox71 = New System.Windows.Forms.CheckBox()
        Me.Label115 = New System.Windows.Forms.Label()
        Me.Label116 = New System.Windows.Forms.Label()
        Me.CheckBox72 = New System.Windows.Forms.CheckBox()
        Me.Label117 = New System.Windows.Forms.Label()
        Me.Label118 = New System.Windows.Forms.Label()
        Me.Label119 = New System.Windows.Forms.Label()
        Me.Label120 = New System.Windows.Forms.Label()
        Me.Label121 = New System.Windows.Forms.Label()
        Me.Label122 = New System.Windows.Forms.Label()
        Me.Label123 = New System.Windows.Forms.Label()
        Me.Label124 = New System.Windows.Forms.Label()
        Me.GroupBox8 = New System.Windows.Forms.GroupBox()
        Me.z14a4 = New System.Windows.Forms.CheckBox()
        Me.z14a3 = New System.Windows.Forms.CheckBox()
        Me.z14a2 = New System.Windows.Forms.CheckBox()
        Me.z14a1 = New System.Windows.Forms.CheckBox()
        Me.z13a4 = New System.Windows.Forms.CheckBox()
        Me.z13a3 = New System.Windows.Forms.CheckBox()
        Me.z13a2 = New System.Windows.Forms.CheckBox()
        Me.z13a1 = New System.Windows.Forms.CheckBox()
        Me.z12a4 = New System.Windows.Forms.CheckBox()
        Me.z12a3 = New System.Windows.Forms.CheckBox()
        Me.z12a2 = New System.Windows.Forms.CheckBox()
        Me.z12a1 = New System.Windows.Forms.CheckBox()
        Me.z11a4 = New System.Windows.Forms.CheckBox()
        Me.z11a3 = New System.Windows.Forms.CheckBox()
        Me.z11a2 = New System.Windows.Forms.CheckBox()
        Me.Label85 = New System.Windows.Forms.Label()
        Me.Label86 = New System.Windows.Forms.Label()
        Me.z11a1 = New System.Windows.Forms.CheckBox()
        Me.Label87 = New System.Windows.Forms.Label()
        Me.Label88 = New System.Windows.Forms.Label()
        Me.Label89 = New System.Windows.Forms.Label()
        Me.Label90 = New System.Windows.Forms.Label()
        Me.Label97 = New System.Windows.Forms.Label()
        Me.Label98 = New System.Windows.Forms.Label()
        Me.Label99 = New System.Windows.Forms.Label()
        Me.Label100 = New System.Windows.Forms.Label()
        Me.Label68 = New System.Windows.Forms.Label()
        Me.GroupBox7 = New System.Windows.Forms.GroupBox()
        Me.z10a4 = New System.Windows.Forms.CheckBox()
        Me.z10a3 = New System.Windows.Forms.CheckBox()
        Me.z10a2 = New System.Windows.Forms.CheckBox()
        Me.z10a1 = New System.Windows.Forms.CheckBox()
        Me.z9a4 = New System.Windows.Forms.CheckBox()
        Me.z9a3 = New System.Windows.Forms.CheckBox()
        Me.z9a2 = New System.Windows.Forms.CheckBox()
        Me.z9a1 = New System.Windows.Forms.CheckBox()
        Me.z8a4 = New System.Windows.Forms.CheckBox()
        Me.z8a3 = New System.Windows.Forms.CheckBox()
        Me.z8a2 = New System.Windows.Forms.CheckBox()
        Me.z8a1 = New System.Windows.Forms.CheckBox()
        Me.z7a4 = New System.Windows.Forms.CheckBox()
        Me.z7a3 = New System.Windows.Forms.CheckBox()
        Me.z7a2 = New System.Windows.Forms.CheckBox()
        Me.z7a1 = New System.Windows.Forms.CheckBox()
        Me.z6a4 = New System.Windows.Forms.CheckBox()
        Me.z6a3 = New System.Windows.Forms.CheckBox()
        Me.z6a2 = New System.Windows.Forms.CheckBox()
        Me.z6a1 = New System.Windows.Forms.CheckBox()
        Me.z5a4 = New System.Windows.Forms.CheckBox()
        Me.z5a3 = New System.Windows.Forms.CheckBox()
        Me.z5a2 = New System.Windows.Forms.CheckBox()
        Me.z5a1 = New System.Windows.Forms.CheckBox()
        Me.z4a4 = New System.Windows.Forms.CheckBox()
        Me.z4a3 = New System.Windows.Forms.CheckBox()
        Me.z4a2 = New System.Windows.Forms.CheckBox()
        Me.z4a1 = New System.Windows.Forms.CheckBox()
        Me.z3a4 = New System.Windows.Forms.CheckBox()
        Me.z3a3 = New System.Windows.Forms.CheckBox()
        Me.z3a2 = New System.Windows.Forms.CheckBox()
        Me.z3a1 = New System.Windows.Forms.CheckBox()
        Me.z2a4 = New System.Windows.Forms.CheckBox()
        Me.z2a3 = New System.Windows.Forms.CheckBox()
        Me.z2a2 = New System.Windows.Forms.CheckBox()
        Me.z2a1 = New System.Windows.Forms.CheckBox()
        Me.z1a4 = New System.Windows.Forms.CheckBox()
        Me.z1a3 = New System.Windows.Forms.CheckBox()
        Me.z1a2 = New System.Windows.Forms.CheckBox()
        Me.Label84 = New System.Windows.Forms.Label()
        Me.Label83 = New System.Windows.Forms.Label()
        Me.z1a1 = New System.Windows.Forms.CheckBox()
        Me.Label81 = New System.Windows.Forms.Label()
        Me.Label82 = New System.Windows.Forms.Label()
        Me.Label80 = New System.Windows.Forms.Label()
        Me.Label79 = New System.Windows.Forms.Label()
        Me.Label77 = New System.Windows.Forms.Label()
        Me.Label78 = New System.Windows.Forms.Label()
        Me.Label73 = New System.Windows.Forms.Label()
        Me.Label74 = New System.Windows.Forms.Label()
        Me.Label75 = New System.Windows.Forms.Label()
        Me.Label76 = New System.Windows.Forms.Label()
        Me.Label72 = New System.Windows.Forms.Label()
        Me.Label71 = New System.Windows.Forms.Label()
        Me.Label70 = New System.Windows.Forms.Label()
        Me.Label69 = New System.Windows.Forms.Label()
        Me.txtAgentCountdown = New System.Windows.Forms.TextBox()
        Me.Label67 = New System.Windows.Forms.Label()
        Me.btnAgentBehavSave = New System.Windows.Forms.Button()
        Me.txtAgentDelay = New System.Windows.Forms.TextBox()
        Me.Label66 = New System.Windows.Forms.Label()
        Me.TabPage41 = New System.Windows.Forms.TabPage()
        Me.Label127 = New System.Windows.Forms.Label()
        Me.GroupBox13 = New System.Windows.Forms.GroupBox()
        Me.Label129 = New System.Windows.Forms.Label()
        Me.rdoAbortDisabled = New System.Windows.Forms.RadioButton()
        Me.rdoAbortEnabled = New System.Windows.Forms.RadioButton()
        Me.TabPage14 = New System.Windows.Forms.TabPage()
        Me.btnSysModelNumberSave = New System.Windows.Forms.Button()
        Me.cbbSysModelNumber = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TabPage25 = New System.Windows.Forms.TabPage()
        Me.TabControl7 = New System.Windows.Forms.TabControl()
        Me.TabPage28 = New System.Windows.Forms.TabPage()
        Me.RichTextBox1 = New System.Windows.Forms.RichTextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.TabPage29 = New System.Windows.Forms.TabPage()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.rdoSysExtEnabled = New System.Windows.Forms.RadioButton()
        Me.rdoSysExtDisabled = New System.Windows.Forms.RadioButton()
        Me.TabPage30 = New System.Windows.Forms.TabPage()
        Me.SEzone14bypass = New System.Windows.Forms.CheckBox()
        Me.SEzone13bypass = New System.Windows.Forms.CheckBox()
        Me.SEzone12bypass = New System.Windows.Forms.CheckBox()
        Me.SEzone11bypass = New System.Windows.Forms.CheckBox()
        Me.txtHZone12Name = New System.Windows.Forms.TextBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.txtHZone11Name = New System.Windows.Forms.TextBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.btnZone1xSave = New System.Windows.Forms.Button()
        Me.txtZone14Name = New System.Windows.Forms.TextBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.txtZone13Name = New System.Windows.Forms.TextBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.txtZone12Name = New System.Windows.Forms.TextBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.txtZone11Name = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.TabPage31 = New System.Windows.Forms.TabPage()
        Me.SEzone24bypass = New System.Windows.Forms.CheckBox()
        Me.SEzone23bypass = New System.Windows.Forms.CheckBox()
        Me.SEzone22bypass = New System.Windows.Forms.CheckBox()
        Me.SEzone21bypass = New System.Windows.Forms.CheckBox()
        Me.txtHZone22Name = New System.Windows.Forms.TextBox()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.txtHZone21Name = New System.Windows.Forms.TextBox()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.txtZone24Name = New System.Windows.Forms.TextBox()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.txtZone23Name = New System.Windows.Forms.TextBox()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.txtZone22Name = New System.Windows.Forms.TextBox()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.txtZone21Name = New System.Windows.Forms.TextBox()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.TabPage32 = New System.Windows.Forms.TabPage()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.TabPage33 = New System.Windows.Forms.TabPage()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.TabControl3 = New System.Windows.Forms.TabControl()
        Me.TabPage7 = New System.Windows.Forms.TabPage()
        Me.btnLockCodeRemoved = New System.Windows.Forms.Button()
        Me.btnPWsave = New System.Windows.Forms.Button()
        Me.Label132 = New System.Windows.Forms.Label()
        Me.Label131 = New System.Windows.Forms.Label()
        Me.txtPWset2 = New System.Windows.Forms.TextBox()
        Me.Label130 = New System.Windows.Forms.Label()
        Me.txtPWset1 = New System.Windows.Forms.TextBox()
        Me.TabPage8 = New System.Windows.Forms.TabPage()
        Me.Label133 = New System.Windows.Forms.Label()
        Me.TabPage9 = New System.Windows.Forms.TabPage()
        Me.Label135 = New System.Windows.Forms.Label()
        Me.GroupBox14 = New System.Windows.Forms.GroupBox()
        Me.Label136 = New System.Windows.Forms.Label()
        Me.rdoQuitDisabled = New System.Windows.Forms.RadioButton()
        Me.rdoQuitEnabled = New System.Windows.Forms.RadioButton()
        Me.Label134 = New System.Windows.Forms.Label()
        Me.TabPage6 = New System.Windows.Forms.TabPage()
        Me.GroupBox15 = New System.Windows.Forms.GroupBox()
        Me.Label138 = New System.Windows.Forms.Label()
        Me.RadioButton1 = New System.Windows.Forms.RadioButton()
        Me.RadioButton2 = New System.Windows.Forms.RadioButton()
        Me.TabPage36 = New System.Windows.Forms.TabPage()
        Me.btnSaveInfo = New System.Windows.Forms.Button()
        Me.txtNotes = New System.Windows.Forms.TextBox()
        Me.Label161 = New System.Windows.Forms.Label()
        Me.txtDiscord = New System.Windows.Forms.TextBox()
        Me.Label159 = New System.Windows.Forms.Label()
        Me.txtPhone2 = New System.Windows.Forms.TextBox()
        Me.Label160 = New System.Windows.Forms.Label()
        Me.txtPhone1 = New System.Windows.Forms.TextBox()
        Me.Label158 = New System.Windows.Forms.Label()
        Me.txtEmail = New System.Windows.Forms.TextBox()
        Me.Label157 = New System.Windows.Forms.Label()
        Me.txtLastName = New System.Windows.Forms.TextBox()
        Me.Label156 = New System.Windows.Forms.Label()
        Me.txtFirstName = New System.Windows.Forms.TextBox()
        Me.Label155 = New System.Windows.Forms.Label()
        Me.Label154 = New System.Windows.Forms.Label()
        Me.TabPage15 = New System.Windows.Forms.TabPage()
        Me.debugPanel = New System.Windows.Forms.Panel()
        Me.Label152 = New System.Windows.Forms.Label()
        Me.btnLampTest = New System.Windows.Forms.Button()
        Me.Label153 = New System.Windows.Forms.Label()
        Me.Label151 = New System.Windows.Forms.Label()
        Me.btnSailorMode = New System.Windows.Forms.Button()
        Me.Label150 = New System.Windows.Forms.Label()
        Me.Label139 = New System.Windows.Forms.Label()
        Me.fqLbl = New System.Windows.Forms.Label()
        Me.btnForceQuitDone = New System.Windows.Forms.Button()
        Me.txtForceQuitBox = New System.Windows.Forms.TextBox()
        Me.btnForceQuit = New System.Windows.Forms.Button()
        Me.Label137 = New System.Windows.Forms.Label()
        Me.btnSetDefaultConfigs = New System.Windows.Forms.Button()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.btnSettingsReset = New System.Windows.Forms.Button()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.btnDebugShowSettings = New System.Windows.Forms.Button()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.btnInfoRemove = New System.Windows.Forms.Button()
        Me.Panel1.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.TabControl2.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        CType(Me.ColorSlider, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage4.SuspendLayout()
        Me.TabControl4.SuspendLayout()
        Me.TabPage10.SuspendLayout()
        Me.TabControl6.SuspendLayout()
        Me.TabPage23.SuspendLayout()
        Me.TabPage22.SuspendLayout()
        Me.TabPage27.SuspendLayout()
        Me.TabPage11.SuspendLayout()
        Me.TabControl5.SuspendLayout()
        Me.TabPage16.SuspendLayout()
        Me.TabPage17.SuspendLayout()
        Me.grbUnsilence.SuspendLayout()
        Me.grbSilence.SuspendLayout()
        Me.TabPage21.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.TabPage18.SuspendLayout()
        Me.TabPage19.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.TabPage20.SuspendLayout()
        Me.TabPage12.SuspendLayout()
        Me.TabControl8.SuspendLayout()
        Me.TabPage34.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        Me.TabPage26.SuspendLayout()
        Me.TabPage35.SuspendLayout()
        Me.TabPage13.SuspendLayout()
        Me.TabControl9.SuspendLayout()
        Me.TabPage38.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage39.SuspendLayout()
        Me.TabPage40.SuspendLayout()
        Me.GroupBox12.SuspendLayout()
        Me.GroupBox10.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.GroupBox9.SuspendLayout()
        Me.GroupBox11.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.GroupBox8.SuspendLayout()
        Me.GroupBox7.SuspendLayout()
        Me.TabPage41.SuspendLayout()
        Me.GroupBox13.SuspendLayout()
        Me.TabPage14.SuspendLayout()
        Me.TabPage25.SuspendLayout()
        Me.TabControl7.SuspendLayout()
        Me.TabPage28.SuspendLayout()
        Me.TabPage29.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.TabPage30.SuspendLayout()
        Me.TabPage31.SuspendLayout()
        Me.TabPage32.SuspendLayout()
        Me.TabPage33.SuspendLayout()
        Me.TabPage5.SuspendLayout()
        Me.TabControl3.SuspendLayout()
        Me.TabPage7.SuspendLayout()
        Me.TabPage8.SuspendLayout()
        Me.TabPage9.SuspendLayout()
        Me.GroupBox14.SuspendLayout()
        Me.TabPage6.SuspendLayout()
        Me.GroupBox15.SuspendLayout()
        Me.TabPage36.SuspendLayout()
        Me.TabPage15.SuspendLayout()
        Me.debugPanel.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.btnDone)
        Me.Panel1.Controls.Add(Me.lblIndSaveStat)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel1.Location = New System.Drawing.Point(0, 489)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(901, 50)
        Me.Panel1.TabIndex = 0
        '
        'btnDone
        '
        Me.btnDone.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnDone.Location = New System.Drawing.Point(814, 13)
        Me.btnDone.Name = "btnDone"
        Me.btnDone.Size = New System.Drawing.Size(75, 23)
        Me.btnDone.TabIndex = 1
        Me.btnDone.Text = "Done"
        Me.btnDone.UseVisualStyleBackColor = True
        '
        'lblIndSaveStat
        '
        Me.lblIndSaveStat.AutoSize = True
        Me.lblIndSaveStat.Location = New System.Drawing.Point(12, 18)
        Me.lblIndSaveStat.Name = "lblIndSaveStat"
        Me.lblIndSaveStat.Size = New System.Drawing.Size(84, 13)
        Me.lblIndSaveStat.TabIndex = 0
        Me.lblIndSaveStat.Text = "Changes saved."
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Controls.Add(Me.TabPage4)
        Me.TabControl1.Controls.Add(Me.TabPage25)
        Me.TabControl1.Controls.Add(Me.TabPage5)
        Me.TabControl1.Controls.Add(Me.TabPage15)
        Me.TabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl1.Location = New System.Drawing.Point(0, 0)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(901, 489)
        Me.TabControl1.TabIndex = 1
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.TabControl2)
        Me.TabPage3.Location = New System.Drawing.Point(4, 22)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Size = New System.Drawing.Size(893, 463)
        Me.TabPage3.TabIndex = 0
        Me.TabPage3.Text = "Preferences"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'TabControl2
        '
        Me.TabControl2.Controls.Add(Me.TabPage1)
        Me.TabControl2.Controls.Add(Me.TabPage2)
        Me.TabControl2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl2.Location = New System.Drawing.Point(0, 0)
        Me.TabControl2.Name = "TabControl2"
        Me.TabControl2.SelectedIndex = 0
        Me.TabControl2.Size = New System.Drawing.Size(893, 463)
        Me.TabControl2.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.Label8)
        Me.TabPage1.Controls.Add(Me.btnSysNameSave)
        Me.TabPage1.Controls.Add(Me.txtSysName)
        Me.TabPage1.Controls.Add(Me.Label2)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(885, 437)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "System Name"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(7, 53)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(763, 13)
        Me.Label8.TabIndex = 3
        Me.Label8.Text = "Theoretically, this can be whatever, but I'd recommend setting it to something 20" &
    " characters or less and without fancy characters, to avoid compatibility problem" &
    "s."
        '
        'btnSysNameSave
        '
        Me.btnSysNameSave.Location = New System.Drawing.Point(196, 25)
        Me.btnSysNameSave.Name = "btnSysNameSave"
        Me.btnSysNameSave.Size = New System.Drawing.Size(75, 20)
        Me.btnSysNameSave.TabIndex = 2
        Me.btnSysNameSave.Text = "Save"
        Me.btnSysNameSave.UseVisualStyleBackColor = True
        '
        'txtSysName
        '
        Me.txtSysName.Location = New System.Drawing.Point(10, 25)
        Me.txtSysName.Name = "txtSysName"
        Me.txtSysName.Size = New System.Drawing.Size(180, 20)
        Me.txtSysName.TabIndex = 1
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(7, 7)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(407, 13)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "Set the name for this fire alarm system. This will appear on the control panel in" &
    "terface."
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.Label149)
        Me.TabPage2.Controls.Add(Me.btnColorSave)
        Me.TabPage2.Controls.Add(Me.Label148)
        Me.TabPage2.Controls.Add(Me.Label147)
        Me.TabPage2.Controls.Add(Me.Label146)
        Me.TabPage2.Controls.Add(Me.Label145)
        Me.TabPage2.Controls.Add(Me.Label144)
        Me.TabPage2.Controls.Add(Me.Label143)
        Me.TabPage2.Controls.Add(Me.Label142)
        Me.TabPage2.Controls.Add(Me.Label141)
        Me.TabPage2.Controls.Add(Me.Label140)
        Me.TabPage2.Controls.Add(Me.ColorSlider)
        Me.TabPage2.Controls.Add(Me.Label9)
        Me.TabPage2.Controls.Add(Me.Panel4)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Size = New System.Drawing.Size(885, 437)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Interface Color"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'Label149
        '
        Me.Label149.AutoSize = True
        Me.Label149.Location = New System.Drawing.Point(95, 405)
        Me.Label149.Name = "Label149"
        Me.Label149.Size = New System.Drawing.Size(264, 13)
        Me.Label149.TabIndex = 12
        Me.Label149.Text = "Changes will be reflected on PowerCommander restart."
        '
        'btnColorSave
        '
        Me.btnColorSave.Location = New System.Drawing.Point(14, 400)
        Me.btnColorSave.Name = "btnColorSave"
        Me.btnColorSave.Size = New System.Drawing.Size(75, 23)
        Me.btnColorSave.TabIndex = 11
        Me.btnColorSave.Text = "Save"
        Me.btnColorSave.UseVisualStyleBackColor = True
        '
        'Label148
        '
        Me.Label148.AutoSize = True
        Me.Label148.BackColor = System.Drawing.Color.White
        Me.Label148.Location = New System.Drawing.Point(793, 75)
        Me.Label148.Name = "Label148"
        Me.Label148.Size = New System.Drawing.Size(64, 13)
        Me.Label148.TabIndex = 10
        Me.Label148.Text = "Accessibility"
        Me.Label148.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label147
        '
        Me.Label147.AutoSize = True
        Me.Label147.BackColor = System.Drawing.Color.White
        Me.Label147.Location = New System.Drawing.Point(134, 75)
        Me.Label147.Name = "Label147"
        Me.Label147.Size = New System.Drawing.Size(38, 13)
        Me.Label147.TabIndex = 9
        Me.Label147.Text = "Yellow"
        Me.Label147.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label146
        '
        Me.Label146.AutoSize = True
        Me.Label146.BackColor = System.Drawing.Color.White
        Me.Label146.Location = New System.Drawing.Point(523, 75)
        Me.Label146.Name = "Label146"
        Me.Label146.Size = New System.Drawing.Size(28, 13)
        Me.Label146.TabIndex = 8
        Me.Label146.Text = "Pink"
        Me.Label146.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label145
        '
        Me.Label145.AutoSize = True
        Me.Label145.BackColor = System.Drawing.Color.White
        Me.Label145.Location = New System.Drawing.Point(709, 75)
        Me.Label145.Name = "Label145"
        Me.Label145.Size = New System.Drawing.Size(42, 13)
        Me.Label145.TabIndex = 7
        Me.Label145.Text = "Orange"
        Me.Label145.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label144
        '
        Me.Label144.AutoSize = True
        Me.Label144.BackColor = System.Drawing.Color.White
        Me.Label144.Location = New System.Drawing.Point(619, 75)
        Me.Label144.Name = "Label144"
        Me.Label144.Size = New System.Drawing.Size(27, 13)
        Me.Label144.TabIndex = 6
        Me.Label144.Text = "Red"
        Me.Label144.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label143
        '
        Me.Label143.AutoSize = True
        Me.Label143.BackColor = System.Drawing.Color.White
        Me.Label143.Location = New System.Drawing.Point(423, 75)
        Me.Label143.Name = "Label143"
        Me.Label143.Size = New System.Drawing.Size(37, 13)
        Me.Label143.TabIndex = 5
        Me.Label143.Text = "Purple"
        Me.Label143.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label142
        '
        Me.Label142.AutoSize = True
        Me.Label142.BackColor = System.Drawing.Color.White
        Me.Label142.Location = New System.Drawing.Point(330, 75)
        Me.Label142.Name = "Label142"
        Me.Label142.Size = New System.Drawing.Size(28, 13)
        Me.Label142.TabIndex = 4
        Me.Label142.Text = "Blue"
        Me.Label142.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label141
        '
        Me.Label141.AutoSize = True
        Me.Label141.BackColor = System.Drawing.Color.White
        Me.Label141.Location = New System.Drawing.Point(231, 75)
        Me.Label141.Name = "Label141"
        Me.Label141.Size = New System.Drawing.Size(36, 13)
        Me.Label141.TabIndex = 3
        Me.Label141.Text = "Green"
        Me.Label141.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label140
        '
        Me.Label140.AutoSize = True
        Me.Label140.BackColor = System.Drawing.Color.White
        Me.Label140.Location = New System.Drawing.Point(39, 75)
        Me.Label140.Name = "Label140"
        Me.Label140.Size = New System.Drawing.Size(35, 13)
        Me.Label140.TabIndex = 2
        Me.Label140.Text = "White"
        Me.Label140.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'ColorSlider
        '
        Me.ColorSlider.BackColor = System.Drawing.Color.White
        Me.ColorSlider.Location = New System.Drawing.Point(43, 36)
        Me.ColorSlider.Maximum = 8
        Me.ColorSlider.Name = "ColorSlider"
        Me.ColorSlider.Size = New System.Drawing.Size(795, 42)
        Me.ColorSlider.TabIndex = 1
        Me.ColorSlider.TickStyle = System.Windows.Forms.TickStyle.Both
        Me.ColorSlider.Value = 2
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(40, 11)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(134, 13)
        Me.Label9.TabIndex = 0
        Me.Label9.Text = "Set the panel display color."
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.White
        Me.Panel4.Location = New System.Drawing.Point(25, 27)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(839, 71)
        Me.Panel4.TabIndex = 13
        '
        'TabPage4
        '
        Me.TabPage4.Controls.Add(Me.TabControl4)
        Me.TabPage4.Location = New System.Drawing.Point(4, 22)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Size = New System.Drawing.Size(893, 463)
        Me.TabPage4.TabIndex = 1
        Me.TabPage4.Text = "System Configuration"
        Me.TabPage4.UseVisualStyleBackColor = True
        '
        'TabControl4
        '
        Me.TabControl4.Controls.Add(Me.TabPage10)
        Me.TabControl4.Controls.Add(Me.TabPage11)
        Me.TabControl4.Controls.Add(Me.TabPage12)
        Me.TabControl4.Controls.Add(Me.TabPage13)
        Me.TabControl4.Controls.Add(Me.TabPage14)
        Me.TabControl4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl4.Location = New System.Drawing.Point(0, 0)
        Me.TabControl4.Name = "TabControl4"
        Me.TabControl4.SelectedIndex = 0
        Me.TabControl4.Size = New System.Drawing.Size(893, 463)
        Me.TabControl4.TabIndex = 0
        '
        'TabPage10
        '
        Me.TabPage10.Controls.Add(Me.TabControl6)
        Me.TabPage10.Location = New System.Drawing.Point(4, 22)
        Me.TabPage10.Name = "TabPage10"
        Me.TabPage10.Size = New System.Drawing.Size(885, 437)
        Me.TabPage10.TabIndex = 0
        Me.TabPage10.Text = "General"
        Me.TabPage10.UseVisualStyleBackColor = True
        '
        'TabControl6
        '
        Me.TabControl6.Controls.Add(Me.TabPage24)
        Me.TabControl6.Controls.Add(Me.TabPage23)
        Me.TabControl6.Controls.Add(Me.TabPage22)
        Me.TabControl6.Controls.Add(Me.TabPage27)
        Me.TabControl6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl6.Location = New System.Drawing.Point(0, 0)
        Me.TabControl6.Name = "TabControl6"
        Me.TabControl6.SelectedIndex = 0
        Me.TabControl6.Size = New System.Drawing.Size(885, 437)
        Me.TabControl6.TabIndex = 0
        '
        'TabPage24
        '
        Me.TabPage24.Location = New System.Drawing.Point(4, 22)
        Me.TabPage24.Name = "TabPage24"
        Me.TabPage24.Size = New System.Drawing.Size(877, 411)
        Me.TabPage24.TabIndex = 3
        Me.TabPage24.Text = "General Settings"
        Me.TabPage24.UseVisualStyleBackColor = True
        '
        'TabPage23
        '
        Me.TabPage23.Controls.Add(Me.Label15)
        Me.TabPage23.Location = New System.Drawing.Point(4, 22)
        Me.TabPage23.Name = "TabPage23"
        Me.TabPage23.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage23.Size = New System.Drawing.Size(877, 411)
        Me.TabPage23.TabIndex = 1
        Me.TabPage23.Text = "NAC Information"
        Me.TabPage23.UseVisualStyleBackColor = True
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(8, 8)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(164, 104)
        Me.Label15.TabIndex = 0
        Me.Label15.Text = resources.GetString("Label15.Text")
        '
        'TabPage22
        '
        Me.TabPage22.Controls.Add(Me.Label36)
        Me.TabPage22.Location = New System.Drawing.Point(4, 22)
        Me.TabPage22.Name = "TabPage22"
        Me.TabPage22.Size = New System.Drawing.Size(877, 411)
        Me.TabPage22.TabIndex = 2
        Me.TabPage22.Text = "Zone Information"
        Me.TabPage22.UseVisualStyleBackColor = True
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Location = New System.Drawing.Point(8, 8)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(227, 52)
        Me.Label36.TabIndex = 1
        Me.Label36.Text = "Zone 1 through Zone 10 - Fire Alarm IDC Zone" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Zone 11 through 14 - Hazard Alarm I" &
    "DC Zone" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Zone 15 - AGENT RELEASE IDC" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Zone 16 - AGENT ABORT IDC"
        '
        'TabPage27
        '
        Me.TabPage27.Controls.Add(Me.btnNotepadSave)
        Me.TabPage27.Controls.Add(Me.notepad)
        Me.TabPage27.Location = New System.Drawing.Point(4, 22)
        Me.TabPage27.Name = "TabPage27"
        Me.TabPage27.Size = New System.Drawing.Size(877, 411)
        Me.TabPage27.TabIndex = 4
        Me.TabPage27.Text = "Notepad"
        Me.TabPage27.UseVisualStyleBackColor = True
        '
        'btnNotepadSave
        '
        Me.btnNotepadSave.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnNotepadSave.Location = New System.Drawing.Point(794, 379)
        Me.btnNotepadSave.Name = "btnNotepadSave"
        Me.btnNotepadSave.Size = New System.Drawing.Size(75, 23)
        Me.btnNotepadSave.TabIndex = 2
        Me.btnNotepadSave.Text = "Save"
        Me.btnNotepadSave.UseVisualStyleBackColor = True
        '
        'notepad
        '
        Me.notepad.Location = New System.Drawing.Point(8, 8)
        Me.notepad.Multiline = True
        Me.notepad.Name = "notepad"
        Me.notepad.Size = New System.Drawing.Size(861, 365)
        Me.notepad.TabIndex = 0
        '
        'TabPage11
        '
        Me.TabPage11.Controls.Add(Me.TabControl5)
        Me.TabPage11.Location = New System.Drawing.Point(4, 22)
        Me.TabPage11.Name = "TabPage11"
        Me.TabPage11.Size = New System.Drawing.Size(885, 437)
        Me.TabPage11.TabIndex = 1
        Me.TabPage11.Text = "Fire Alarm System"
        Me.TabPage11.UseVisualStyleBackColor = True
        '
        'TabControl5
        '
        Me.TabControl5.Controls.Add(Me.TabPage16)
        Me.TabControl5.Controls.Add(Me.TabPage17)
        Me.TabControl5.Controls.Add(Me.TabPage21)
        Me.TabControl5.Controls.Add(Me.TabPage18)
        Me.TabControl5.Controls.Add(Me.TabPage19)
        Me.TabControl5.Controls.Add(Me.TabPage20)
        Me.TabControl5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl5.Location = New System.Drawing.Point(0, 0)
        Me.TabControl5.Name = "TabControl5"
        Me.TabControl5.SelectedIndex = 0
        Me.TabControl5.Size = New System.Drawing.Size(885, 437)
        Me.TabControl5.TabIndex = 0
        '
        'TabPage16
        '
        Me.TabPage16.Controls.Add(Me.Label4)
        Me.TabPage16.Controls.Add(Me.btnFireACDsave)
        Me.TabPage16.Controls.Add(Me.txtFireACDbox)
        Me.TabPage16.Controls.Add(Me.Label3)
        Me.TabPage16.Location = New System.Drawing.Point(4, 22)
        Me.TabPage16.Name = "TabPage16"
        Me.TabPage16.Size = New System.Drawing.Size(877, 411)
        Me.TabPage16.TabIndex = 0
        Me.TabPage16.Text = "Alarm Condition Delay"
        Me.TabPage16.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(6, 80)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(528, 182)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = resources.GetString("Label4.Text")
        '
        'btnFireACDsave
        '
        Me.btnFireACDsave.Location = New System.Drawing.Point(130, 47)
        Me.btnFireACDsave.Name = "btnFireACDsave"
        Me.btnFireACDsave.Size = New System.Drawing.Size(75, 20)
        Me.btnFireACDsave.TabIndex = 2
        Me.btnFireACDsave.Text = "Save"
        Me.btnFireACDsave.UseVisualStyleBackColor = True
        '
        'txtFireACDbox
        '
        Me.txtFireACDbox.Location = New System.Drawing.Point(9, 47)
        Me.txtFireACDbox.Name = "txtFireACDbox"
        Me.txtFireACDbox.Size = New System.Drawing.Size(115, 20)
        Me.txtFireACDbox.TabIndex = 1
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(6, 6)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(310, 26)
        Me.Label3.TabIndex = 0
        Me.Label3.Text = "Delay between alarm condition and alarm sounding (in seconds)." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "(This does not cu" &
    "rrently support verification and is only a delay.)"
        '
        'TabPage17
        '
        Me.TabPage17.Controls.Add(Me.grbUnsilence)
        Me.TabPage17.Controls.Add(Me.grbSilence)
        Me.TabPage17.Controls.Add(Me.Label10)
        Me.TabPage17.Location = New System.Drawing.Point(4, 22)
        Me.TabPage17.Name = "TabPage17"
        Me.TabPage17.Size = New System.Drawing.Size(877, 411)
        Me.TabPage17.TabIndex = 1
        Me.TabPage17.Text = "Silence"
        Me.TabPage17.UseVisualStyleBackColor = True
        '
        'grbUnsilence
        '
        Me.grbUnsilence.Controls.Add(Me.Label12)
        Me.grbUnsilence.Controls.Add(Me.rdoUnsilenceDisable)
        Me.grbUnsilence.Controls.Add(Me.rdoUnsilenceEnable)
        Me.grbUnsilence.Location = New System.Drawing.Point(286, 33)
        Me.grbUnsilence.Name = "grbUnsilence"
        Me.grbUnsilence.Size = New System.Drawing.Size(269, 64)
        Me.grbUnsilence.TabIndex = 2
        Me.grbUnsilence.TabStop = False
        Me.grbUnsilence.Text = "Enable Unsilence"
        '
        'Label12
        '
        Me.Label12.Location = New System.Drawing.Point(154, 16)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(110, 45)
        Me.Label12.TabIndex = 3
        Me.Label12.Text = "The ability to unsilence a silenced alarm"
        '
        'rdoUnsilenceDisable
        '
        Me.rdoUnsilenceDisable.AutoSize = True
        Me.rdoUnsilenceDisable.Location = New System.Drawing.Point(79, 28)
        Me.rdoUnsilenceDisable.Name = "rdoUnsilenceDisable"
        Me.rdoUnsilenceDisable.Size = New System.Drawing.Size(66, 17)
        Me.rdoUnsilenceDisable.TabIndex = 3
        Me.rdoUnsilenceDisable.TabStop = True
        Me.rdoUnsilenceDisable.Text = "Disabled"
        Me.rdoUnsilenceDisable.UseVisualStyleBackColor = True
        '
        'rdoUnsilenceEnable
        '
        Me.rdoUnsilenceEnable.AutoSize = True
        Me.rdoUnsilenceEnable.Location = New System.Drawing.Point(9, 28)
        Me.rdoUnsilenceEnable.Name = "rdoUnsilenceEnable"
        Me.rdoUnsilenceEnable.Size = New System.Drawing.Size(64, 17)
        Me.rdoUnsilenceEnable.TabIndex = 2
        Me.rdoUnsilenceEnable.TabStop = True
        Me.rdoUnsilenceEnable.Text = "Enabled"
        Me.rdoUnsilenceEnable.UseVisualStyleBackColor = True
        '
        'grbSilence
        '
        Me.grbSilence.Controls.Add(Me.Label11)
        Me.grbSilence.Controls.Add(Me.rdoSilenceDisable)
        Me.grbSilence.Controls.Add(Me.rdoSilenceEnable)
        Me.grbSilence.Location = New System.Drawing.Point(11, 33)
        Me.grbSilence.Name = "grbSilence"
        Me.grbSilence.Size = New System.Drawing.Size(269, 64)
        Me.grbSilence.TabIndex = 1
        Me.grbSilence.TabStop = False
        Me.grbSilence.Text = "Enable Silence"
        '
        'Label11
        '
        Me.Label11.Location = New System.Drawing.Point(154, 16)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(110, 45)
        Me.Label11.TabIndex = 2
        Me.Label11.Text = "The ability to silence audible alarms without a reset"
        '
        'rdoSilenceDisable
        '
        Me.rdoSilenceDisable.AutoSize = True
        Me.rdoSilenceDisable.Location = New System.Drawing.Point(80, 28)
        Me.rdoSilenceDisable.Name = "rdoSilenceDisable"
        Me.rdoSilenceDisable.Size = New System.Drawing.Size(66, 17)
        Me.rdoSilenceDisable.TabIndex = 1
        Me.rdoSilenceDisable.TabStop = True
        Me.rdoSilenceDisable.Text = "Disabled"
        Me.rdoSilenceDisable.UseVisualStyleBackColor = True
        '
        'rdoSilenceEnable
        '
        Me.rdoSilenceEnable.AutoSize = True
        Me.rdoSilenceEnable.Location = New System.Drawing.Point(10, 28)
        Me.rdoSilenceEnable.Name = "rdoSilenceEnable"
        Me.rdoSilenceEnable.Size = New System.Drawing.Size(64, 17)
        Me.rdoSilenceEnable.TabIndex = 0
        Me.rdoSilenceEnable.TabStop = True
        Me.rdoSilenceEnable.Text = "Enabled"
        Me.rdoSilenceEnable.UseVisualStyleBackColor = True
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(8, 8)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(140, 13)
        Me.Label10.TabIndex = 0
        Me.Label10.Text = "Alarm Silence configurations"
        '
        'TabPage21
        '
        Me.TabPage21.Controls.Add(Me.Label54)
        Me.TabPage21.Controls.Add(Me.Label13)
        Me.TabPage21.Controls.Add(Me.btnFASSave)
        Me.TabPage21.Controls.Add(Me.txtFireAutoSilDelay)
        Me.TabPage21.Controls.Add(Me.GroupBox1)
        Me.TabPage21.Controls.Add(Me.Label14)
        Me.TabPage21.Location = New System.Drawing.Point(4, 22)
        Me.TabPage21.Name = "TabPage21"
        Me.TabPage21.Size = New System.Drawing.Size(877, 411)
        Me.TabPage21.TabIndex = 5
        Me.TabPage21.Text = "Automatic Silence"
        Me.TabPage21.UseVisualStyleBackColor = True
        '
        'Label54
        '
        Me.Label54.AutoSize = True
        Me.Label54.Location = New System.Drawing.Point(8, 165)
        Me.Label54.Name = "Label54"
        Me.Label54.Size = New System.Drawing.Size(365, 13)
        Me.Label54.TabIndex = 7
        Me.Label54.Text = "If you have Second Stage enabled, this countdown will start during Stage 2."
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(8, 109)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(327, 13)
        Me.Label13.TabIndex = 6
        Me.Label13.Text = "Automatically silence audible signals after a preset delay in seconds:"
        '
        'btnFASSave
        '
        Me.btnFASSave.Location = New System.Drawing.Point(132, 130)
        Me.btnFASSave.Name = "btnFASSave"
        Me.btnFASSave.Size = New System.Drawing.Size(75, 20)
        Me.btnFASSave.TabIndex = 5
        Me.btnFASSave.Text = "Save"
        Me.btnFASSave.UseVisualStyleBackColor = True
        '
        'txtFireAutoSilDelay
        '
        Me.txtFireAutoSilDelay.Location = New System.Drawing.Point(11, 130)
        Me.txtFireAutoSilDelay.Name = "txtFireAutoSilDelay"
        Me.txtFireAutoSilDelay.Size = New System.Drawing.Size(115, 20)
        Me.txtFireAutoSilDelay.TabIndex = 4
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.rdoAutoSilDisabled)
        Me.GroupBox1.Controls.Add(Me.rdoAutoSilEnabled)
        Me.GroupBox1.Location = New System.Drawing.Point(11, 33)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(152, 64)
        Me.GroupBox1.TabIndex = 3
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Enable Auto Silence"
        '
        'rdoAutoSilDisabled
        '
        Me.rdoAutoSilDisabled.AutoSize = True
        Me.rdoAutoSilDisabled.Location = New System.Drawing.Point(80, 28)
        Me.rdoAutoSilDisabled.Name = "rdoAutoSilDisabled"
        Me.rdoAutoSilDisabled.Size = New System.Drawing.Size(66, 17)
        Me.rdoAutoSilDisabled.TabIndex = 1
        Me.rdoAutoSilDisabled.TabStop = True
        Me.rdoAutoSilDisabled.Text = "Disabled"
        Me.rdoAutoSilDisabled.UseVisualStyleBackColor = True
        '
        'rdoAutoSilEnabled
        '
        Me.rdoAutoSilEnabled.AutoSize = True
        Me.rdoAutoSilEnabled.Location = New System.Drawing.Point(10, 28)
        Me.rdoAutoSilEnabled.Name = "rdoAutoSilEnabled"
        Me.rdoAutoSilEnabled.Size = New System.Drawing.Size(64, 17)
        Me.rdoAutoSilEnabled.TabIndex = 0
        Me.rdoAutoSilEnabled.TabStop = True
        Me.rdoAutoSilEnabled.Text = "Enabled"
        Me.rdoAutoSilEnabled.UseVisualStyleBackColor = True
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(8, 8)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(270, 13)
        Me.Label14.TabIndex = 2
        Me.Label14.Text = "Automatically silence audible signals after a preset delay"
        '
        'TabPage18
        '
        Me.TabPage18.Controls.Add(Me.Label37)
        Me.TabPage18.Location = New System.Drawing.Point(4, 22)
        Me.TabPage18.Name = "TabPage18"
        Me.TabPage18.Size = New System.Drawing.Size(877, 411)
        Me.TabPage18.TabIndex = 2
        Me.TabPage18.Text = "Code Option"
        Me.TabPage18.UseVisualStyleBackColor = True
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Location = New System.Drawing.Point(8, 8)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(841, 13)
        Me.Label37.TabIndex = 0
        Me.Label37.Text = "The PowerMarshall PM-10, PM-10RT units have an integrated tone card which needs t" &
    "o be flashed independently of this system. The PM-9 series does not support code" &
    " control."
        '
        'TabPage19
        '
        Me.TabPage19.Controls.Add(Me.GroupBox5)
        Me.TabPage19.Controls.Add(Me.GroupBox4)
        Me.TabPage19.Controls.Add(Me.btn2Ssave)
        Me.TabPage19.Controls.Add(Me.txtS1delay)
        Me.TabPage19.Controls.Add(Me.Label52)
        Me.TabPage19.Controls.Add(Me.GroupBox3)
        Me.TabPage19.Controls.Add(Me.Label50)
        Me.TabPage19.Location = New System.Drawing.Point(4, 22)
        Me.TabPage19.Name = "TabPage19"
        Me.TabPage19.Size = New System.Drawing.Size(877, 411)
        Me.TabPage19.TabIndex = 3
        Me.TabPage19.Text = "Second Stage Alarm"
        Me.TabPage19.UseVisualStyleBackColor = True
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.chkS2buzzer)
        Me.GroupBox5.Controls.Add(Me.chkS2notifier)
        Me.GroupBox5.Controls.Add(Me.chkS2visual)
        Me.GroupBox5.Controls.Add(Me.Label53)
        Me.GroupBox5.Controls.Add(Me.chkS2audible)
        Me.GroupBox5.Location = New System.Drawing.Point(440, 119)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(424, 239)
        Me.GroupBox5.TabIndex = 6
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Stage 2"
        '
        'chkS2buzzer
        '
        Me.chkS2buzzer.AutoSize = True
        Me.chkS2buzzer.Location = New System.Drawing.Point(10, 88)
        Me.chkS2buzzer.Name = "chkS2buzzer"
        Me.chkS2buzzer.Size = New System.Drawing.Size(216, 17)
        Me.chkS2buzzer.TabIndex = 4
        Me.chkS2buzzer.Text = "Sound control unit buzzer during stage 1"
        Me.chkS2buzzer.UseVisualStyleBackColor = True
        '
        'chkS2notifier
        '
        Me.chkS2notifier.AutoSize = True
        Me.chkS2notifier.Enabled = False
        Me.chkS2notifier.Location = New System.Drawing.Point(10, 65)
        Me.chkS2notifier.Name = "chkS2notifier"
        Me.chkS2notifier.Size = New System.Drawing.Size(209, 17)
        Me.chkS2notifier.TabIndex = 3
        Me.chkS2notifier.Text = "Turn on alarm indicators during stage 1"
        Me.chkS2notifier.UseVisualStyleBackColor = True
        '
        'chkS2visual
        '
        Me.chkS2visual.AutoSize = True
        Me.chkS2visual.Enabled = False
        Me.chkS2visual.Location = New System.Drawing.Point(10, 42)
        Me.chkS2visual.Name = "chkS2visual"
        Me.chkS2visual.Size = New System.Drawing.Size(200, 17)
        Me.chkS2visual.TabIndex = 2
        Me.chkS2visual.Text = "Activate visual signals during stage 1"
        Me.chkS2visual.UseVisualStyleBackColor = True
        '
        'Label53
        '
        Me.Label53.Location = New System.Drawing.Point(6, 220)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(411, 16)
        Me.Label53.TabIndex = 2
        Me.Label53.Text = "You can silence the system automatically with the auto silence function."
        '
        'chkS2audible
        '
        Me.chkS2audible.AutoSize = True
        Me.chkS2audible.Enabled = False
        Me.chkS2audible.Location = New System.Drawing.Point(10, 19)
        Me.chkS2audible.Name = "chkS2audible"
        Me.chkS2audible.Size = New System.Drawing.Size(199, 17)
        Me.chkS2audible.TabIndex = 1
        Me.chkS2audible.Text = "Sound audible signals during stage 2"
        Me.chkS2audible.UseVisualStyleBackColor = True
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.chkS1buzzer)
        Me.GroupBox4.Controls.Add(Me.chkS1notifier)
        Me.GroupBox4.Controls.Add(Me.chkS1visual)
        Me.GroupBox4.Controls.Add(Me.chkS1audible)
        Me.GroupBox4.Location = New System.Drawing.Point(15, 119)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(419, 239)
        Me.GroupBox4.TabIndex = 5
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Stage 1"
        '
        'chkS1buzzer
        '
        Me.chkS1buzzer.AutoSize = True
        Me.chkS1buzzer.Location = New System.Drawing.Point(10, 88)
        Me.chkS1buzzer.Name = "chkS1buzzer"
        Me.chkS1buzzer.Size = New System.Drawing.Size(216, 17)
        Me.chkS1buzzer.TabIndex = 3
        Me.chkS1buzzer.Text = "Sound control unit buzzer during stage 1"
        Me.chkS1buzzer.UseVisualStyleBackColor = True
        '
        'chkS1notifier
        '
        Me.chkS1notifier.AutoSize = True
        Me.chkS1notifier.Location = New System.Drawing.Point(10, 65)
        Me.chkS1notifier.Name = "chkS1notifier"
        Me.chkS1notifier.Size = New System.Drawing.Size(209, 17)
        Me.chkS1notifier.TabIndex = 2
        Me.chkS1notifier.Text = "Turn on alarm indicators during stage 1"
        Me.chkS1notifier.UseVisualStyleBackColor = True
        '
        'chkS1visual
        '
        Me.chkS1visual.AutoSize = True
        Me.chkS1visual.Location = New System.Drawing.Point(10, 42)
        Me.chkS1visual.Name = "chkS1visual"
        Me.chkS1visual.Size = New System.Drawing.Size(200, 17)
        Me.chkS1visual.TabIndex = 1
        Me.chkS1visual.Text = "Activate visual signals during stage 1"
        Me.chkS1visual.UseVisualStyleBackColor = True
        '
        'chkS1audible
        '
        Me.chkS1audible.AutoSize = True
        Me.chkS1audible.Location = New System.Drawing.Point(10, 19)
        Me.chkS1audible.Name = "chkS1audible"
        Me.chkS1audible.Size = New System.Drawing.Size(199, 17)
        Me.chkS1audible.TabIndex = 0
        Me.chkS1audible.Text = "Sound audible signals during stage 1"
        Me.chkS1audible.UseVisualStyleBackColor = True
        '
        'btn2Ssave
        '
        Me.btn2Ssave.Location = New System.Drawing.Point(788, 373)
        Me.btn2Ssave.Name = "btn2Ssave"
        Me.btn2Ssave.Size = New System.Drawing.Size(75, 23)
        Me.btn2Ssave.TabIndex = 4
        Me.btn2Ssave.Text = "Save"
        Me.btn2Ssave.UseVisualStyleBackColor = True
        '
        'txtS1delay
        '
        Me.txtS1delay.Location = New System.Drawing.Point(160, 93)
        Me.txtS1delay.Name = "txtS1delay"
        Me.txtS1delay.Size = New System.Drawing.Size(143, 20)
        Me.txtS1delay.TabIndex = 3
        '
        'Label52
        '
        Me.Label52.AutoSize = True
        Me.Label52.Location = New System.Drawing.Point(12, 96)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(142, 13)
        Me.Label52.TabIndex = 2
        Me.Label52.Text = "Stage 1 duration in seconds:"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.Label51)
        Me.GroupBox3.Controls.Add(Me.rdo2Senabled)
        Me.GroupBox3.Controls.Add(Me.rdo2Sdisabled)
        Me.GroupBox3.Location = New System.Drawing.Point(15, 32)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(849, 52)
        Me.GroupBox3.TabIndex = 1
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Enable Second Stage Mode"
        '
        'Label51
        '
        Me.Label51.Location = New System.Drawing.Point(153, 16)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(691, 32)
        Me.Label51.TabIndex = 2
        Me.Label51.Text = resources.GetString("Label51.Text")
        '
        'rdo2Senabled
        '
        Me.rdo2Senabled.AutoSize = True
        Me.rdo2Senabled.Location = New System.Drawing.Point(82, 21)
        Me.rdo2Senabled.Name = "rdo2Senabled"
        Me.rdo2Senabled.Size = New System.Drawing.Size(64, 17)
        Me.rdo2Senabled.TabIndex = 1
        Me.rdo2Senabled.TabStop = True
        Me.rdo2Senabled.Text = "Enabled"
        Me.rdo2Senabled.UseVisualStyleBackColor = True
        '
        'rdo2Sdisabled
        '
        Me.rdo2Sdisabled.AutoSize = True
        Me.rdo2Sdisabled.Location = New System.Drawing.Point(10, 21)
        Me.rdo2Sdisabled.Name = "rdo2Sdisabled"
        Me.rdo2Sdisabled.Size = New System.Drawing.Size(66, 17)
        Me.rdo2Sdisabled.TabIndex = 0
        Me.rdo2Sdisabled.TabStop = True
        Me.rdo2Sdisabled.Text = "Disabled"
        Me.rdo2Sdisabled.UseVisualStyleBackColor = True
        '
        'Label50
        '
        Me.Label50.AutoSize = True
        Me.Label50.Location = New System.Drawing.Point(12, 11)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(220, 13)
        Me.Label50.TabIndex = 0
        Me.Label50.Text = "Second Stage will enable a two-stage mode. "
        '
        'TabPage20
        '
        Me.TabPage20.Controls.Add(Me.btnSaveZones)
        Me.TabPage20.Controls.Add(Me.Label49)
        Me.TabPage20.Controls.Add(Me.chkF10bypass)
        Me.TabPage20.Controls.Add(Me.chkF9bypass)
        Me.TabPage20.Controls.Add(Me.txtF10name)
        Me.TabPage20.Controls.Add(Me.Label47)
        Me.TabPage20.Controls.Add(Me.txtF9name)
        Me.TabPage20.Controls.Add(Me.Label48)
        Me.TabPage20.Controls.Add(Me.chkF8bypass)
        Me.TabPage20.Controls.Add(Me.chkF7bypass)
        Me.TabPage20.Controls.Add(Me.chkF6bypass)
        Me.TabPage20.Controls.Add(Me.chkF5bypass)
        Me.TabPage20.Controls.Add(Me.txtF8name)
        Me.TabPage20.Controls.Add(Me.Label43)
        Me.TabPage20.Controls.Add(Me.txtF7name)
        Me.TabPage20.Controls.Add(Me.Label44)
        Me.TabPage20.Controls.Add(Me.txtF6name)
        Me.TabPage20.Controls.Add(Me.Label45)
        Me.TabPage20.Controls.Add(Me.txtF5name)
        Me.TabPage20.Controls.Add(Me.Label46)
        Me.TabPage20.Controls.Add(Me.chkF4bypass)
        Me.TabPage20.Controls.Add(Me.chkF3bypass)
        Me.TabPage20.Controls.Add(Me.chkF2bypass)
        Me.TabPage20.Controls.Add(Me.chkF1bypass)
        Me.TabPage20.Controls.Add(Me.txtF4name)
        Me.TabPage20.Controls.Add(Me.Label38)
        Me.TabPage20.Controls.Add(Me.txtF3name)
        Me.TabPage20.Controls.Add(Me.Label39)
        Me.TabPage20.Controls.Add(Me.txtF2name)
        Me.TabPage20.Controls.Add(Me.Label40)
        Me.TabPage20.Controls.Add(Me.txtF1name)
        Me.TabPage20.Controls.Add(Me.Label41)
        Me.TabPage20.Controls.Add(Me.Label42)
        Me.TabPage20.Location = New System.Drawing.Point(4, 22)
        Me.TabPage20.Name = "TabPage20"
        Me.TabPage20.Size = New System.Drawing.Size(877, 411)
        Me.TabPage20.TabIndex = 4
        Me.TabPage20.Text = "Zone Configurations"
        Me.TabPage20.UseVisualStyleBackColor = True
        '
        'btnSaveZones
        '
        Me.btnSaveZones.Location = New System.Drawing.Point(265, 292)
        Me.btnSaveZones.Name = "btnSaveZones"
        Me.btnSaveZones.Size = New System.Drawing.Size(75, 23)
        Me.btnSaveZones.TabIndex = 51
        Me.btnSaveZones.Text = "Save"
        Me.btnSaveZones.UseVisualStyleBackColor = True
        '
        'Label49
        '
        Me.Label49.Location = New System.Drawing.Point(13, 321)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(861, 79)
        Me.Label49.TabIndex = 50
        Me.Label49.Text = resources.GetString("Label49.Text")
        '
        'chkF10bypass
        '
        Me.chkF10bypass.AutoSize = True
        Me.chkF10bypass.Location = New System.Drawing.Point(346, 269)
        Me.chkF10bypass.Name = "chkF10bypass"
        Me.chkF10bypass.Size = New System.Drawing.Size(100, 17)
        Me.chkF10bypass.TabIndex = 49
        Me.chkF10bypass.Text = "Bypass Stage 1"
        Me.chkF10bypass.UseVisualStyleBackColor = True
        '
        'chkF9bypass
        '
        Me.chkF9bypass.AutoSize = True
        Me.chkF9bypass.Location = New System.Drawing.Point(346, 243)
        Me.chkF9bypass.Name = "chkF9bypass"
        Me.chkF9bypass.Size = New System.Drawing.Size(100, 17)
        Me.chkF9bypass.TabIndex = 48
        Me.chkF9bypass.Text = "Bypass Stage 1"
        Me.chkF9bypass.UseVisualStyleBackColor = True
        '
        'txtF10name
        '
        Me.txtF10name.Location = New System.Drawing.Point(69, 266)
        Me.txtF10name.Name = "txtF10name"
        Me.txtF10name.Size = New System.Drawing.Size(271, 20)
        Me.txtF10name.TabIndex = 47
        '
        'Label47
        '
        Me.Label47.AutoSize = True
        Me.Label47.Location = New System.Drawing.Point(13, 269)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(47, 13)
        Me.Label47.TabIndex = 46
        Me.Label47.Text = "Zone 10"
        '
        'txtF9name
        '
        Me.txtF9name.Location = New System.Drawing.Point(69, 240)
        Me.txtF9name.Name = "txtF9name"
        Me.txtF9name.Size = New System.Drawing.Size(271, 20)
        Me.txtF9name.TabIndex = 45
        '
        'Label48
        '
        Me.Label48.AutoSize = True
        Me.Label48.Location = New System.Drawing.Point(13, 243)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(41, 13)
        Me.Label48.TabIndex = 44
        Me.Label48.Text = "Zone 9"
        '
        'chkF8bypass
        '
        Me.chkF8bypass.AutoSize = True
        Me.chkF8bypass.Location = New System.Drawing.Point(346, 216)
        Me.chkF8bypass.Name = "chkF8bypass"
        Me.chkF8bypass.Size = New System.Drawing.Size(100, 17)
        Me.chkF8bypass.TabIndex = 43
        Me.chkF8bypass.Text = "Bypass Stage 1"
        Me.chkF8bypass.UseVisualStyleBackColor = True
        '
        'chkF7bypass
        '
        Me.chkF7bypass.AutoSize = True
        Me.chkF7bypass.Location = New System.Drawing.Point(346, 190)
        Me.chkF7bypass.Name = "chkF7bypass"
        Me.chkF7bypass.Size = New System.Drawing.Size(100, 17)
        Me.chkF7bypass.TabIndex = 42
        Me.chkF7bypass.Text = "Bypass Stage 1"
        Me.chkF7bypass.UseVisualStyleBackColor = True
        '
        'chkF6bypass
        '
        Me.chkF6bypass.AutoSize = True
        Me.chkF6bypass.Location = New System.Drawing.Point(346, 164)
        Me.chkF6bypass.Name = "chkF6bypass"
        Me.chkF6bypass.Size = New System.Drawing.Size(100, 17)
        Me.chkF6bypass.TabIndex = 41
        Me.chkF6bypass.Text = "Bypass Stage 1"
        Me.chkF6bypass.UseVisualStyleBackColor = True
        '
        'chkF5bypass
        '
        Me.chkF5bypass.AutoSize = True
        Me.chkF5bypass.Location = New System.Drawing.Point(346, 138)
        Me.chkF5bypass.Name = "chkF5bypass"
        Me.chkF5bypass.Size = New System.Drawing.Size(100, 17)
        Me.chkF5bypass.TabIndex = 40
        Me.chkF5bypass.Text = "Bypass Stage 1"
        Me.chkF5bypass.UseVisualStyleBackColor = True
        '
        'txtF8name
        '
        Me.txtF8name.Location = New System.Drawing.Point(69, 213)
        Me.txtF8name.Name = "txtF8name"
        Me.txtF8name.Size = New System.Drawing.Size(271, 20)
        Me.txtF8name.TabIndex = 39
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.Location = New System.Drawing.Point(13, 216)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(41, 13)
        Me.Label43.TabIndex = 38
        Me.Label43.Text = "Zone 8"
        '
        'txtF7name
        '
        Me.txtF7name.Location = New System.Drawing.Point(69, 187)
        Me.txtF7name.Name = "txtF7name"
        Me.txtF7name.Size = New System.Drawing.Size(271, 20)
        Me.txtF7name.TabIndex = 37
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.Location = New System.Drawing.Point(13, 190)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(41, 13)
        Me.Label44.TabIndex = 36
        Me.Label44.Text = "Zone 7"
        '
        'txtF6name
        '
        Me.txtF6name.Location = New System.Drawing.Point(69, 161)
        Me.txtF6name.Name = "txtF6name"
        Me.txtF6name.Size = New System.Drawing.Size(271, 20)
        Me.txtF6name.TabIndex = 35
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.Location = New System.Drawing.Point(13, 164)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(41, 13)
        Me.Label45.TabIndex = 34
        Me.Label45.Text = "Zone 6"
        '
        'txtF5name
        '
        Me.txtF5name.Location = New System.Drawing.Point(69, 135)
        Me.txtF5name.Name = "txtF5name"
        Me.txtF5name.Size = New System.Drawing.Size(271, 20)
        Me.txtF5name.TabIndex = 33
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.Location = New System.Drawing.Point(13, 138)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(41, 13)
        Me.Label46.TabIndex = 32
        Me.Label46.Text = "Zone 5"
        '
        'chkF4bypass
        '
        Me.chkF4bypass.AutoSize = True
        Me.chkF4bypass.Location = New System.Drawing.Point(346, 112)
        Me.chkF4bypass.Name = "chkF4bypass"
        Me.chkF4bypass.Size = New System.Drawing.Size(100, 17)
        Me.chkF4bypass.TabIndex = 31
        Me.chkF4bypass.Text = "Bypass Stage 1"
        Me.chkF4bypass.UseVisualStyleBackColor = True
        '
        'chkF3bypass
        '
        Me.chkF3bypass.AutoSize = True
        Me.chkF3bypass.Location = New System.Drawing.Point(346, 86)
        Me.chkF3bypass.Name = "chkF3bypass"
        Me.chkF3bypass.Size = New System.Drawing.Size(100, 17)
        Me.chkF3bypass.TabIndex = 30
        Me.chkF3bypass.Text = "Bypass Stage 1"
        Me.chkF3bypass.UseVisualStyleBackColor = True
        '
        'chkF2bypass
        '
        Me.chkF2bypass.AutoSize = True
        Me.chkF2bypass.Location = New System.Drawing.Point(346, 60)
        Me.chkF2bypass.Name = "chkF2bypass"
        Me.chkF2bypass.Size = New System.Drawing.Size(100, 17)
        Me.chkF2bypass.TabIndex = 29
        Me.chkF2bypass.Text = "Bypass Stage 1"
        Me.chkF2bypass.UseVisualStyleBackColor = True
        '
        'chkF1bypass
        '
        Me.chkF1bypass.AutoSize = True
        Me.chkF1bypass.Location = New System.Drawing.Point(346, 34)
        Me.chkF1bypass.Name = "chkF1bypass"
        Me.chkF1bypass.Size = New System.Drawing.Size(100, 17)
        Me.chkF1bypass.TabIndex = 28
        Me.chkF1bypass.Text = "Bypass Stage 1"
        Me.chkF1bypass.UseVisualStyleBackColor = True
        '
        'txtF4name
        '
        Me.txtF4name.Location = New System.Drawing.Point(69, 109)
        Me.txtF4name.Name = "txtF4name"
        Me.txtF4name.Size = New System.Drawing.Size(271, 20)
        Me.txtF4name.TabIndex = 27
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Location = New System.Drawing.Point(13, 112)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(41, 13)
        Me.Label38.TabIndex = 26
        Me.Label38.Text = "Zone 4"
        '
        'txtF3name
        '
        Me.txtF3name.Location = New System.Drawing.Point(69, 83)
        Me.txtF3name.Name = "txtF3name"
        Me.txtF3name.Size = New System.Drawing.Size(271, 20)
        Me.txtF3name.TabIndex = 25
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Location = New System.Drawing.Point(13, 86)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(41, 13)
        Me.Label39.TabIndex = 24
        Me.Label39.Text = "Zone 3"
        '
        'txtF2name
        '
        Me.txtF2name.Location = New System.Drawing.Point(69, 57)
        Me.txtF2name.Name = "txtF2name"
        Me.txtF2name.Size = New System.Drawing.Size(271, 20)
        Me.txtF2name.TabIndex = 23
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Location = New System.Drawing.Point(13, 60)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(41, 13)
        Me.Label40.TabIndex = 22
        Me.Label40.Text = "Zone 2"
        '
        'txtF1name
        '
        Me.txtF1name.Location = New System.Drawing.Point(69, 31)
        Me.txtF1name.Name = "txtF1name"
        Me.txtF1name.Size = New System.Drawing.Size(271, 20)
        Me.txtF1name.TabIndex = 21
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Location = New System.Drawing.Point(13, 34)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(41, 13)
        Me.Label41.TabIndex = 20
        Me.Label41.Text = "Zone 1"
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.Location = New System.Drawing.Point(13, 12)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(105, 13)
        Me.Label42.TabIndex = 19
        Me.Label42.Text = "Configure Fire Zones"
        '
        'TabPage12
        '
        Me.TabPage12.Controls.Add(Me.TabControl8)
        Me.TabPage12.Location = New System.Drawing.Point(4, 22)
        Me.TabPage12.Name = "TabPage12"
        Me.TabPage12.Size = New System.Drawing.Size(885, 437)
        Me.TabPage12.TabIndex = 2
        Me.TabPage12.Text = "Hazard Alarm System"
        Me.TabPage12.UseVisualStyleBackColor = True
        '
        'TabControl8
        '
        Me.TabControl8.Controls.Add(Me.TabPage34)
        Me.TabControl8.Controls.Add(Me.TabPage26)
        Me.TabControl8.Controls.Add(Me.TabPage35)
        Me.TabControl8.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl8.Location = New System.Drawing.Point(0, 0)
        Me.TabControl8.Name = "TabControl8"
        Me.TabControl8.SelectedIndex = 0
        Me.TabControl8.Size = New System.Drawing.Size(885, 437)
        Me.TabControl8.TabIndex = 0
        '
        'TabPage34
        '
        Me.TabPage34.Controls.Add(Me.Label56)
        Me.TabPage34.Controls.Add(Me.btnHazAutoStopSave)
        Me.TabPage34.Controls.Add(Me.txtHazAutoStopDelay)
        Me.TabPage34.Controls.Add(Me.GroupBox6)
        Me.TabPage34.Controls.Add(Me.Label55)
        Me.TabPage34.Location = New System.Drawing.Point(4, 22)
        Me.TabPage34.Name = "TabPage34"
        Me.TabPage34.Size = New System.Drawing.Size(877, 411)
        Me.TabPage34.TabIndex = 0
        Me.TabPage34.Text = "Automatic Stop"
        Me.TabPage34.UseVisualStyleBackColor = True
        '
        'Label56
        '
        Me.Label56.AutoSize = True
        Me.Label56.Location = New System.Drawing.Point(9, 125)
        Me.Label56.Name = "Label56"
        Me.Label56.Size = New System.Drawing.Size(327, 13)
        Me.Label56.TabIndex = 10
        Me.Label56.Text = "Automatically silence audible signals after a preset delay in seconds:"
        '
        'btnHazAutoStopSave
        '
        Me.btnHazAutoStopSave.Location = New System.Drawing.Point(133, 146)
        Me.btnHazAutoStopSave.Name = "btnHazAutoStopSave"
        Me.btnHazAutoStopSave.Size = New System.Drawing.Size(75, 20)
        Me.btnHazAutoStopSave.TabIndex = 9
        Me.btnHazAutoStopSave.Text = "Save"
        Me.btnHazAutoStopSave.UseVisualStyleBackColor = True
        '
        'txtHazAutoStopDelay
        '
        Me.txtHazAutoStopDelay.Location = New System.Drawing.Point(12, 146)
        Me.txtHazAutoStopDelay.Name = "txtHazAutoStopDelay"
        Me.txtHazAutoStopDelay.Size = New System.Drawing.Size(115, 20)
        Me.txtHazAutoStopDelay.TabIndex = 8
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.rdoHazASdisabled)
        Me.GroupBox6.Controls.Add(Me.rdoHazASenabled)
        Me.GroupBox6.Location = New System.Drawing.Point(12, 49)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(152, 64)
        Me.GroupBox6.TabIndex = 7
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "Enable Auto Stop"
        '
        'rdoHazASdisabled
        '
        Me.rdoHazASdisabled.AutoSize = True
        Me.rdoHazASdisabled.Location = New System.Drawing.Point(80, 28)
        Me.rdoHazASdisabled.Name = "rdoHazASdisabled"
        Me.rdoHazASdisabled.Size = New System.Drawing.Size(66, 17)
        Me.rdoHazASdisabled.TabIndex = 1
        Me.rdoHazASdisabled.TabStop = True
        Me.rdoHazASdisabled.Text = "Disabled"
        Me.rdoHazASdisabled.UseVisualStyleBackColor = True
        '
        'rdoHazASenabled
        '
        Me.rdoHazASenabled.AutoSize = True
        Me.rdoHazASenabled.Location = New System.Drawing.Point(10, 28)
        Me.rdoHazASenabled.Name = "rdoHazASenabled"
        Me.rdoHazASenabled.Size = New System.Drawing.Size(64, 17)
        Me.rdoHazASenabled.TabIndex = 0
        Me.rdoHazASenabled.TabStop = True
        Me.rdoHazASenabled.Text = "Enabled"
        Me.rdoHazASenabled.UseVisualStyleBackColor = True
        '
        'Label55
        '
        Me.Label55.AutoSize = True
        Me.Label55.Location = New System.Drawing.Point(9, 9)
        Me.Label55.Name = "Label55"
        Me.Label55.Size = New System.Drawing.Size(543, 26)
        Me.Label55.TabIndex = 0
        Me.Label55.Text = "Automatically stop hazard alarms after a preset delay in seconds:" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "(Note that thi" &
    "s will both silence audible alarms and stop visual signals. This also has no eff" &
    "ect on fire alarm signals.)"
        '
        'TabPage26
        '
        Me.TabPage26.Controls.Add(Me.Label57)
        Me.TabPage26.Location = New System.Drawing.Point(4, 22)
        Me.TabPage26.Name = "TabPage26"
        Me.TabPage26.Size = New System.Drawing.Size(877, 411)
        Me.TabPage26.TabIndex = 2
        Me.TabPage26.Text = "Code Option"
        Me.TabPage26.UseVisualStyleBackColor = True
        '
        'Label57
        '
        Me.Label57.AutoSize = True
        Me.Label57.Location = New System.Drawing.Point(10, 10)
        Me.Label57.Name = "Label57"
        Me.Label57.Size = New System.Drawing.Size(281, 13)
        Me.Label57.TabIndex = 0
        Me.Label57.Text = "Uses internal tone card. Cannot change code option here."
        '
        'TabPage35
        '
        Me.TabPage35.Controls.Add(Me.btnHazSave)
        Me.TabPage35.Controls.Add(Me.txthaz4name)
        Me.TabPage35.Controls.Add(Me.Label58)
        Me.TabPage35.Controls.Add(Me.txthaz3name)
        Me.TabPage35.Controls.Add(Me.Label59)
        Me.TabPage35.Controls.Add(Me.txthaz2name)
        Me.TabPage35.Controls.Add(Me.Label60)
        Me.TabPage35.Controls.Add(Me.txthaz1name)
        Me.TabPage35.Controls.Add(Me.Label61)
        Me.TabPage35.Controls.Add(Me.Label62)
        Me.TabPage35.Location = New System.Drawing.Point(4, 22)
        Me.TabPage35.Name = "TabPage35"
        Me.TabPage35.Size = New System.Drawing.Size(877, 411)
        Me.TabPage35.TabIndex = 1
        Me.TabPage35.Text = "Zone Configurations"
        Me.TabPage35.UseVisualStyleBackColor = True
        '
        'btnHazSave
        '
        Me.btnHazSave.Location = New System.Drawing.Point(259, 131)
        Me.btnHazSave.Name = "btnHazSave"
        Me.btnHazSave.Size = New System.Drawing.Size(75, 23)
        Me.btnHazSave.TabIndex = 18
        Me.btnHazSave.Text = "Save"
        Me.btnHazSave.UseVisualStyleBackColor = True
        '
        'txthaz4name
        '
        Me.txthaz4name.Location = New System.Drawing.Point(63, 105)
        Me.txthaz4name.Name = "txthaz4name"
        Me.txthaz4name.Size = New System.Drawing.Size(271, 20)
        Me.txthaz4name.TabIndex = 17
        '
        'Label58
        '
        Me.Label58.AutoSize = True
        Me.Label58.Location = New System.Drawing.Point(7, 108)
        Me.Label58.Name = "Label58"
        Me.Label58.Size = New System.Drawing.Size(41, 13)
        Me.Label58.TabIndex = 16
        Me.Label58.Text = "Zone 4"
        '
        'txthaz3name
        '
        Me.txthaz3name.Location = New System.Drawing.Point(63, 79)
        Me.txthaz3name.Name = "txthaz3name"
        Me.txthaz3name.Size = New System.Drawing.Size(271, 20)
        Me.txthaz3name.TabIndex = 15
        '
        'Label59
        '
        Me.Label59.AutoSize = True
        Me.Label59.Location = New System.Drawing.Point(7, 82)
        Me.Label59.Name = "Label59"
        Me.Label59.Size = New System.Drawing.Size(41, 13)
        Me.Label59.TabIndex = 14
        Me.Label59.Text = "Zone 3"
        '
        'txthaz2name
        '
        Me.txthaz2name.Location = New System.Drawing.Point(63, 53)
        Me.txthaz2name.Name = "txthaz2name"
        Me.txthaz2name.Size = New System.Drawing.Size(271, 20)
        Me.txthaz2name.TabIndex = 13
        '
        'Label60
        '
        Me.Label60.AutoSize = True
        Me.Label60.Location = New System.Drawing.Point(7, 56)
        Me.Label60.Name = "Label60"
        Me.Label60.Size = New System.Drawing.Size(41, 13)
        Me.Label60.TabIndex = 12
        Me.Label60.Text = "Zone 2"
        '
        'txthaz1name
        '
        Me.txthaz1name.Location = New System.Drawing.Point(63, 27)
        Me.txthaz1name.Name = "txthaz1name"
        Me.txthaz1name.Size = New System.Drawing.Size(271, 20)
        Me.txthaz1name.TabIndex = 11
        '
        'Label61
        '
        Me.Label61.AutoSize = True
        Me.Label61.Location = New System.Drawing.Point(7, 30)
        Me.Label61.Name = "Label61"
        Me.Label61.Size = New System.Drawing.Size(41, 13)
        Me.Label61.TabIndex = 10
        Me.Label61.Text = "Zone 1"
        '
        'Label62
        '
        Me.Label62.AutoSize = True
        Me.Label62.Location = New System.Drawing.Point(7, 8)
        Me.Label62.Name = "Label62"
        Me.Label62.Size = New System.Drawing.Size(122, 13)
        Me.Label62.TabIndex = 9
        Me.Label62.Text = "Configure Hazard Zones"
        '
        'TabPage13
        '
        Me.TabPage13.Controls.Add(Me.TabControl9)
        Me.TabPage13.Location = New System.Drawing.Point(4, 22)
        Me.TabPage13.Name = "TabPage13"
        Me.TabPage13.Size = New System.Drawing.Size(885, 437)
        Me.TabPage13.TabIndex = 3
        Me.TabPage13.Text = "Agent Release System"
        Me.TabPage13.UseVisualStyleBackColor = True
        '
        'TabControl9
        '
        Me.TabControl9.Controls.Add(Me.TabPage38)
        Me.TabControl9.Controls.Add(Me.TabPage39)
        Me.TabControl9.Controls.Add(Me.TabPage40)
        Me.TabControl9.Controls.Add(Me.TabPage41)
        Me.TabControl9.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl9.Location = New System.Drawing.Point(0, 0)
        Me.TabControl9.Name = "TabControl9"
        Me.TabControl9.SelectedIndex = 0
        Me.TabControl9.Size = New System.Drawing.Size(885, 437)
        Me.TabControl9.TabIndex = 0
        '
        'TabPage38
        '
        Me.TabPage38.Controls.Add(Me.RichTextBox2)
        Me.TabPage38.Controls.Add(Me.Label63)
        Me.TabPage38.Controls.Add(Me.PictureBox1)
        Me.TabPage38.Location = New System.Drawing.Point(4, 22)
        Me.TabPage38.Name = "TabPage38"
        Me.TabPage38.Size = New System.Drawing.Size(877, 411)
        Me.TabPage38.TabIndex = 0
        Me.TabPage38.Text = "About"
        Me.TabPage38.UseVisualStyleBackColor = True
        '
        'RichTextBox2
        '
        Me.RichTextBox2.Location = New System.Drawing.Point(13, 67)
        Me.RichTextBox2.Name = "RichTextBox2"
        Me.RichTextBox2.Size = New System.Drawing.Size(851, 329)
        Me.RichTextBox2.TabIndex = 2
        Me.RichTextBox2.Text = resources.GetString("RichTextBox2.Text")
        '
        'Label63
        '
        Me.Label63.AutoSize = True
        Me.Label63.Font = New System.Drawing.Font("Microsoft Sans Serif", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label63.ForeColor = System.Drawing.Color.Red
        Me.Label63.Location = New System.Drawing.Point(67, 19)
        Me.Label63.Name = "Label63"
        Me.Label63.Size = New System.Drawing.Size(604, 39)
        Me.Label63.TabIndex = 1
        Me.Label63.Text = "Automatic Fire Suppression System"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.System_Commander_X.My.Resources.Resources.fire_extinguisher
        Me.PictureBox1.Location = New System.Drawing.Point(13, 13)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(48, 48)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'TabPage39
        '
        Me.TabPage39.Controls.Add(Me.Label65)
        Me.TabPage39.Controls.Add(Me.btnAgentTestMode)
        Me.TabPage39.Controls.Add(Me.btnAgentDisable)
        Me.TabPage39.Controls.Add(Me.btnAgentEnable)
        Me.TabPage39.Controls.Add(Me.lblIndAgent)
        Me.TabPage39.Controls.Add(Me.Label64)
        Me.TabPage39.Location = New System.Drawing.Point(4, 22)
        Me.TabPage39.Name = "TabPage39"
        Me.TabPage39.Size = New System.Drawing.Size(877, 411)
        Me.TabPage39.TabIndex = 1
        Me.TabPage39.Text = "Setup"
        Me.TabPage39.UseVisualStyleBackColor = True
        '
        'Label65
        '
        Me.Label65.AutoSize = True
        Me.Label65.Location = New System.Drawing.Point(16, 81)
        Me.Label65.Name = "Label65"
        Me.Label65.Size = New System.Drawing.Size(488, 13)
        Me.Label65.TabIndex = 5
        Me.Label65.Text = "To take the agent release system down completely, first put it into testing mode " &
    "and then click Disable."
        '
        'btnAgentTestMode
        '
        Me.btnAgentTestMode.Location = New System.Drawing.Point(181, 44)
        Me.btnAgentTestMode.Name = "btnAgentTestMode"
        Me.btnAgentTestMode.Size = New System.Drawing.Size(175, 23)
        Me.btnAgentTestMode.TabIndex = 4
        Me.btnAgentTestMode.Text = "TAKE DOWN FOR TESTING"
        Me.btnAgentTestMode.UseVisualStyleBackColor = True
        '
        'btnAgentDisable
        '
        Me.btnAgentDisable.Location = New System.Drawing.Point(100, 44)
        Me.btnAgentDisable.Name = "btnAgentDisable"
        Me.btnAgentDisable.Size = New System.Drawing.Size(75, 23)
        Me.btnAgentDisable.TabIndex = 3
        Me.btnAgentDisable.Text = "DISABLE"
        Me.btnAgentDisable.UseVisualStyleBackColor = True
        '
        'btnAgentEnable
        '
        Me.btnAgentEnable.Location = New System.Drawing.Point(19, 44)
        Me.btnAgentEnable.Name = "btnAgentEnable"
        Me.btnAgentEnable.Size = New System.Drawing.Size(75, 23)
        Me.btnAgentEnable.TabIndex = 2
        Me.btnAgentEnable.Text = "ENABLE"
        Me.btnAgentEnable.UseVisualStyleBackColor = True
        '
        'lblIndAgent
        '
        Me.lblIndAgent.AutoSize = True
        Me.lblIndAgent.Location = New System.Drawing.Point(189, 19)
        Me.lblIndAgent.Name = "lblIndAgent"
        Me.lblIndAgent.Size = New System.Drawing.Size(60, 13)
        Me.lblIndAgent.TabIndex = 1
        Me.lblIndAgent.Text = "DISABLED"
        '
        'Label64
        '
        Me.Label64.AutoSize = True
        Me.Label64.Location = New System.Drawing.Point(16, 19)
        Me.Label64.Name = "Label64"
        Me.Label64.Size = New System.Drawing.Size(167, 13)
        Me.Label64.TabIndex = 0
        Me.Label64.Text = "Agent Release System is currently"
        '
        'TabPage40
        '
        Me.TabPage40.Controls.Add(Me.GroupBox12)
        Me.TabPage40.Controls.Add(Me.GroupBox10)
        Me.TabPage40.Controls.Add(Me.GroupBox9)
        Me.TabPage40.Controls.Add(Me.GroupBox11)
        Me.TabPage40.Controls.Add(Me.GroupBox8)
        Me.TabPage40.Controls.Add(Me.Label68)
        Me.TabPage40.Controls.Add(Me.GroupBox7)
        Me.TabPage40.Controls.Add(Me.txtAgentCountdown)
        Me.TabPage40.Controls.Add(Me.Label67)
        Me.TabPage40.Controls.Add(Me.btnAgentBehavSave)
        Me.TabPage40.Controls.Add(Me.txtAgentDelay)
        Me.TabPage40.Controls.Add(Me.Label66)
        Me.TabPage40.Location = New System.Drawing.Point(4, 22)
        Me.TabPage40.Name = "TabPage40"
        Me.TabPage40.Size = New System.Drawing.Size(877, 411)
        Me.TabPage40.TabIndex = 2
        Me.TabPage40.Text = "Agent Release Behavior"
        Me.TabPage40.UseVisualStyleBackColor = True
        '
        'GroupBox12
        '
        Me.GroupBox12.Controls.Add(Me.Label128)
        Me.GroupBox12.Location = New System.Drawing.Point(301, 269)
        Me.GroupBox12.Name = "GroupBox12"
        Me.GroupBox12.Size = New System.Drawing.Size(488, 108)
        Me.GroupBox12.TabIndex = 61
        Me.GroupBox12.TabStop = False
        Me.GroupBox12.Text = "Information"
        '
        'Label128
        '
        Me.Label128.Location = New System.Drawing.Point(6, 16)
        Me.Label128.Name = "Label128"
        Me.Label128.Size = New System.Drawing.Size(476, 84)
        Me.Label128.TabIndex = 0
        Me.Label128.Text = resources.GetString("Label128.Text")
        '
        'GroupBox10
        '
        Me.GroupBox10.Controls.Add(Me.Panel3)
        Me.GroupBox10.Controls.Add(Me.CheckBox25)
        Me.GroupBox10.Controls.Add(Me.CheckBox26)
        Me.GroupBox10.Controls.Add(Me.CheckBox27)
        Me.GroupBox10.Controls.Add(Me.CheckBox28)
        Me.GroupBox10.Controls.Add(Me.CheckBox29)
        Me.GroupBox10.Controls.Add(Me.CheckBox30)
        Me.GroupBox10.Controls.Add(Me.CheckBox31)
        Me.GroupBox10.Controls.Add(Me.CheckBox32)
        Me.GroupBox10.Controls.Add(Me.CheckBox49)
        Me.GroupBox10.Controls.Add(Me.CheckBox50)
        Me.GroupBox10.Controls.Add(Me.CheckBox51)
        Me.GroupBox10.Controls.Add(Me.CheckBox52)
        Me.GroupBox10.Controls.Add(Me.CheckBox53)
        Me.GroupBox10.Controls.Add(Me.CheckBox54)
        Me.GroupBox10.Controls.Add(Me.CheckBox55)
        Me.GroupBox10.Controls.Add(Me.Label105)
        Me.GroupBox10.Controls.Add(Me.Label106)
        Me.GroupBox10.Controls.Add(Me.CheckBox56)
        Me.GroupBox10.Controls.Add(Me.Label107)
        Me.GroupBox10.Controls.Add(Me.Label108)
        Me.GroupBox10.Controls.Add(Me.Label109)
        Me.GroupBox10.Controls.Add(Me.Label110)
        Me.GroupBox10.Controls.Add(Me.Label111)
        Me.GroupBox10.Controls.Add(Me.Label112)
        Me.GroupBox10.Controls.Add(Me.Label113)
        Me.GroupBox10.Controls.Add(Me.Label114)
        Me.GroupBox10.Location = New System.Drawing.Point(639, 130)
        Me.GroupBox10.Name = "GroupBox10"
        Me.GroupBox10.Size = New System.Drawing.Size(150, 136)
        Me.GroupBox10.TabIndex = 59
        Me.GroupBox10.TabStop = False
        Me.GroupBox10.Text = "System Extender 4"
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.Label126)
        Me.Panel3.Location = New System.Drawing.Point(8, 16)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(134, 109)
        Me.Panel3.TabIndex = 33
        '
        'Label126
        '
        Me.Label126.AutoSize = True
        Me.Label126.Location = New System.Drawing.Point(8, 8)
        Me.Label126.Name = "Label126"
        Me.Label126.Size = New System.Drawing.Size(76, 13)
        Me.Label126.TabIndex = 1
        Me.Label126.Text = "Not Supported"
        '
        'CheckBox25
        '
        Me.CheckBox25.AutoSize = True
        Me.CheckBox25.Location = New System.Drawing.Point(127, 112)
        Me.CheckBox25.Name = "CheckBox25"
        Me.CheckBox25.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox25.TabIndex = 31
        Me.CheckBox25.UseVisualStyleBackColor = True
        '
        'CheckBox26
        '
        Me.CheckBox26.AutoSize = True
        Me.CheckBox26.Location = New System.Drawing.Point(106, 112)
        Me.CheckBox26.Name = "CheckBox26"
        Me.CheckBox26.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox26.TabIndex = 30
        Me.CheckBox26.UseVisualStyleBackColor = True
        '
        'CheckBox27
        '
        Me.CheckBox27.AutoSize = True
        Me.CheckBox27.Location = New System.Drawing.Point(85, 112)
        Me.CheckBox27.Name = "CheckBox27"
        Me.CheckBox27.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox27.TabIndex = 29
        Me.CheckBox27.UseVisualStyleBackColor = True
        '
        'CheckBox28
        '
        Me.CheckBox28.AutoSize = True
        Me.CheckBox28.Location = New System.Drawing.Point(64, 112)
        Me.CheckBox28.Name = "CheckBox28"
        Me.CheckBox28.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox28.TabIndex = 28
        Me.CheckBox28.UseVisualStyleBackColor = True
        '
        'CheckBox29
        '
        Me.CheckBox29.AutoSize = True
        Me.CheckBox29.Location = New System.Drawing.Point(127, 93)
        Me.CheckBox29.Name = "CheckBox29"
        Me.CheckBox29.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox29.TabIndex = 27
        Me.CheckBox29.UseVisualStyleBackColor = True
        '
        'CheckBox30
        '
        Me.CheckBox30.AutoSize = True
        Me.CheckBox30.Location = New System.Drawing.Point(106, 93)
        Me.CheckBox30.Name = "CheckBox30"
        Me.CheckBox30.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox30.TabIndex = 26
        Me.CheckBox30.UseVisualStyleBackColor = True
        '
        'CheckBox31
        '
        Me.CheckBox31.AutoSize = True
        Me.CheckBox31.Location = New System.Drawing.Point(85, 93)
        Me.CheckBox31.Name = "CheckBox31"
        Me.CheckBox31.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox31.TabIndex = 25
        Me.CheckBox31.UseVisualStyleBackColor = True
        '
        'CheckBox32
        '
        Me.CheckBox32.AutoSize = True
        Me.CheckBox32.Location = New System.Drawing.Point(64, 93)
        Me.CheckBox32.Name = "CheckBox32"
        Me.CheckBox32.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox32.TabIndex = 24
        Me.CheckBox32.UseVisualStyleBackColor = True
        '
        'CheckBox49
        '
        Me.CheckBox49.AutoSize = True
        Me.CheckBox49.Location = New System.Drawing.Point(127, 74)
        Me.CheckBox49.Name = "CheckBox49"
        Me.CheckBox49.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox49.TabIndex = 23
        Me.CheckBox49.UseVisualStyleBackColor = True
        '
        'CheckBox50
        '
        Me.CheckBox50.AutoSize = True
        Me.CheckBox50.Location = New System.Drawing.Point(106, 74)
        Me.CheckBox50.Name = "CheckBox50"
        Me.CheckBox50.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox50.TabIndex = 22
        Me.CheckBox50.UseVisualStyleBackColor = True
        '
        'CheckBox51
        '
        Me.CheckBox51.AutoSize = True
        Me.CheckBox51.Location = New System.Drawing.Point(85, 74)
        Me.CheckBox51.Name = "CheckBox51"
        Me.CheckBox51.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox51.TabIndex = 21
        Me.CheckBox51.UseVisualStyleBackColor = True
        '
        'CheckBox52
        '
        Me.CheckBox52.AutoSize = True
        Me.CheckBox52.Location = New System.Drawing.Point(64, 74)
        Me.CheckBox52.Name = "CheckBox52"
        Me.CheckBox52.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox52.TabIndex = 20
        Me.CheckBox52.UseVisualStyleBackColor = True
        '
        'CheckBox53
        '
        Me.CheckBox53.AutoSize = True
        Me.CheckBox53.Location = New System.Drawing.Point(127, 55)
        Me.CheckBox53.Name = "CheckBox53"
        Me.CheckBox53.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox53.TabIndex = 19
        Me.CheckBox53.UseVisualStyleBackColor = True
        '
        'CheckBox54
        '
        Me.CheckBox54.AutoSize = True
        Me.CheckBox54.Location = New System.Drawing.Point(106, 55)
        Me.CheckBox54.Name = "CheckBox54"
        Me.CheckBox54.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox54.TabIndex = 18
        Me.CheckBox54.UseVisualStyleBackColor = True
        '
        'CheckBox55
        '
        Me.CheckBox55.AutoSize = True
        Me.CheckBox55.Location = New System.Drawing.Point(85, 55)
        Me.CheckBox55.Name = "CheckBox55"
        Me.CheckBox55.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox55.TabIndex = 17
        Me.CheckBox55.UseVisualStyleBackColor = True
        '
        'Label105
        '
        Me.Label105.AutoSize = True
        Me.Label105.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label105.Location = New System.Drawing.Point(63, 16)
        Me.Label105.Name = "Label105"
        Me.Label105.Size = New System.Drawing.Size(78, 13)
        Me.Label105.TabIndex = 16
        Me.Label105.Text = "Agent Loops"
        '
        'Label106
        '
        Me.Label106.AutoSize = True
        Me.Label106.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label106.Location = New System.Drawing.Point(6, 16)
        Me.Label106.Name = "Label106"
        Me.Label106.Size = New System.Drawing.Size(36, 13)
        Me.Label106.TabIndex = 15
        Me.Label106.Text = "Zone"
        '
        'CheckBox56
        '
        Me.CheckBox56.AutoSize = True
        Me.CheckBox56.Location = New System.Drawing.Point(64, 55)
        Me.CheckBox56.Name = "CheckBox56"
        Me.CheckBox56.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox56.TabIndex = 14
        Me.CheckBox56.UseVisualStyleBackColor = True
        '
        'Label107
        '
        Me.Label107.AutoSize = True
        Me.Label107.Location = New System.Drawing.Point(127, 37)
        Me.Label107.Name = "Label107"
        Me.Label107.Size = New System.Drawing.Size(13, 13)
        Me.Label107.TabIndex = 13
        Me.Label107.Text = "4"
        '
        'Label108
        '
        Me.Label108.AutoSize = True
        Me.Label108.Location = New System.Drawing.Point(106, 37)
        Me.Label108.Name = "Label108"
        Me.Label108.Size = New System.Drawing.Size(13, 13)
        Me.Label108.TabIndex = 12
        Me.Label108.Text = "3"
        '
        'Label109
        '
        Me.Label109.AutoSize = True
        Me.Label109.Location = New System.Drawing.Point(85, 37)
        Me.Label109.Name = "Label109"
        Me.Label109.Size = New System.Drawing.Size(13, 13)
        Me.Label109.TabIndex = 11
        Me.Label109.Text = "2"
        '
        'Label110
        '
        Me.Label110.AutoSize = True
        Me.Label110.Location = New System.Drawing.Point(64, 37)
        Me.Label110.Name = "Label110"
        Me.Label110.Size = New System.Drawing.Size(13, 13)
        Me.Label110.TabIndex = 10
        Me.Label110.Text = "1"
        '
        'Label111
        '
        Me.Label111.AutoSize = True
        Me.Label111.Location = New System.Drawing.Point(6, 112)
        Me.Label111.Name = "Label111"
        Me.Label111.Size = New System.Drawing.Size(41, 13)
        Me.Label111.TabIndex = 3
        Me.Label111.Text = "Zone 4"
        '
        'Label112
        '
        Me.Label112.AutoSize = True
        Me.Label112.Location = New System.Drawing.Point(6, 93)
        Me.Label112.Name = "Label112"
        Me.Label112.Size = New System.Drawing.Size(41, 13)
        Me.Label112.TabIndex = 2
        Me.Label112.Text = "Zone 3"
        '
        'Label113
        '
        Me.Label113.AutoSize = True
        Me.Label113.Location = New System.Drawing.Point(6, 74)
        Me.Label113.Name = "Label113"
        Me.Label113.Size = New System.Drawing.Size(41, 13)
        Me.Label113.TabIndex = 1
        Me.Label113.Text = "Zone 2"
        '
        'Label114
        '
        Me.Label114.AutoSize = True
        Me.Label114.Location = New System.Drawing.Point(6, 55)
        Me.Label114.Name = "Label114"
        Me.Label114.Size = New System.Drawing.Size(41, 13)
        Me.Label114.TabIndex = 0
        Me.Label114.Text = "Zone 1"
        '
        'GroupBox9
        '
        Me.GroupBox9.Controls.Add(Me.z24a4)
        Me.GroupBox9.Controls.Add(Me.z24a3)
        Me.GroupBox9.Controls.Add(Me.z24a2)
        Me.GroupBox9.Controls.Add(Me.z24a1)
        Me.GroupBox9.Controls.Add(Me.z23a4)
        Me.GroupBox9.Controls.Add(Me.z23a3)
        Me.GroupBox9.Controls.Add(Me.z23a2)
        Me.GroupBox9.Controls.Add(Me.z23a1)
        Me.GroupBox9.Controls.Add(Me.z22a4)
        Me.GroupBox9.Controls.Add(Me.z22a3)
        Me.GroupBox9.Controls.Add(Me.z22a2)
        Me.GroupBox9.Controls.Add(Me.z22a1)
        Me.GroupBox9.Controls.Add(Me.z21a4)
        Me.GroupBox9.Controls.Add(Me.z21a3)
        Me.GroupBox9.Controls.Add(Me.z21a2)
        Me.GroupBox9.Controls.Add(Me.Label91)
        Me.GroupBox9.Controls.Add(Me.Label92)
        Me.GroupBox9.Controls.Add(Me.z21a1)
        Me.GroupBox9.Controls.Add(Me.Label93)
        Me.GroupBox9.Controls.Add(Me.Label94)
        Me.GroupBox9.Controls.Add(Me.Label95)
        Me.GroupBox9.Controls.Add(Me.Label96)
        Me.GroupBox9.Controls.Add(Me.Label101)
        Me.GroupBox9.Controls.Add(Me.Label102)
        Me.GroupBox9.Controls.Add(Me.Label103)
        Me.GroupBox9.Controls.Add(Me.Label104)
        Me.GroupBox9.Location = New System.Drawing.Point(327, 130)
        Me.GroupBox9.Name = "GroupBox9"
        Me.GroupBox9.Size = New System.Drawing.Size(150, 136)
        Me.GroupBox9.TabIndex = 57
        Me.GroupBox9.TabStop = False
        Me.GroupBox9.Text = "System Extender 2"
        '
        'z24a4
        '
        Me.z24a4.AutoSize = True
        Me.z24a4.Location = New System.Drawing.Point(127, 112)
        Me.z24a4.Name = "z24a4"
        Me.z24a4.Size = New System.Drawing.Size(15, 14)
        Me.z24a4.TabIndex = 31
        Me.z24a4.UseVisualStyleBackColor = True
        '
        'z24a3
        '
        Me.z24a3.AutoSize = True
        Me.z24a3.Location = New System.Drawing.Point(106, 112)
        Me.z24a3.Name = "z24a3"
        Me.z24a3.Size = New System.Drawing.Size(15, 14)
        Me.z24a3.TabIndex = 30
        Me.z24a3.UseVisualStyleBackColor = True
        '
        'z24a2
        '
        Me.z24a2.AutoSize = True
        Me.z24a2.Location = New System.Drawing.Point(85, 112)
        Me.z24a2.Name = "z24a2"
        Me.z24a2.Size = New System.Drawing.Size(15, 14)
        Me.z24a2.TabIndex = 29
        Me.z24a2.UseVisualStyleBackColor = True
        '
        'z24a1
        '
        Me.z24a1.AutoSize = True
        Me.z24a1.Location = New System.Drawing.Point(64, 112)
        Me.z24a1.Name = "z24a1"
        Me.z24a1.Size = New System.Drawing.Size(15, 14)
        Me.z24a1.TabIndex = 28
        Me.z24a1.UseVisualStyleBackColor = True
        '
        'z23a4
        '
        Me.z23a4.AutoSize = True
        Me.z23a4.Location = New System.Drawing.Point(127, 93)
        Me.z23a4.Name = "z23a4"
        Me.z23a4.Size = New System.Drawing.Size(15, 14)
        Me.z23a4.TabIndex = 27
        Me.z23a4.UseVisualStyleBackColor = True
        '
        'z23a3
        '
        Me.z23a3.AutoSize = True
        Me.z23a3.Location = New System.Drawing.Point(106, 93)
        Me.z23a3.Name = "z23a3"
        Me.z23a3.Size = New System.Drawing.Size(15, 14)
        Me.z23a3.TabIndex = 26
        Me.z23a3.UseVisualStyleBackColor = True
        '
        'z23a2
        '
        Me.z23a2.AutoSize = True
        Me.z23a2.Location = New System.Drawing.Point(85, 93)
        Me.z23a2.Name = "z23a2"
        Me.z23a2.Size = New System.Drawing.Size(15, 14)
        Me.z23a2.TabIndex = 25
        Me.z23a2.UseVisualStyleBackColor = True
        '
        'z23a1
        '
        Me.z23a1.AutoSize = True
        Me.z23a1.Location = New System.Drawing.Point(64, 93)
        Me.z23a1.Name = "z23a1"
        Me.z23a1.Size = New System.Drawing.Size(15, 14)
        Me.z23a1.TabIndex = 24
        Me.z23a1.UseVisualStyleBackColor = True
        '
        'z22a4
        '
        Me.z22a4.AutoSize = True
        Me.z22a4.Location = New System.Drawing.Point(127, 74)
        Me.z22a4.Name = "z22a4"
        Me.z22a4.Size = New System.Drawing.Size(15, 14)
        Me.z22a4.TabIndex = 23
        Me.z22a4.UseVisualStyleBackColor = True
        '
        'z22a3
        '
        Me.z22a3.AutoSize = True
        Me.z22a3.Location = New System.Drawing.Point(106, 74)
        Me.z22a3.Name = "z22a3"
        Me.z22a3.Size = New System.Drawing.Size(15, 14)
        Me.z22a3.TabIndex = 22
        Me.z22a3.UseVisualStyleBackColor = True
        '
        'z22a2
        '
        Me.z22a2.AutoSize = True
        Me.z22a2.Location = New System.Drawing.Point(85, 74)
        Me.z22a2.Name = "z22a2"
        Me.z22a2.Size = New System.Drawing.Size(15, 14)
        Me.z22a2.TabIndex = 21
        Me.z22a2.UseVisualStyleBackColor = True
        '
        'z22a1
        '
        Me.z22a1.AutoSize = True
        Me.z22a1.Location = New System.Drawing.Point(64, 74)
        Me.z22a1.Name = "z22a1"
        Me.z22a1.Size = New System.Drawing.Size(15, 14)
        Me.z22a1.TabIndex = 20
        Me.z22a1.UseVisualStyleBackColor = True
        '
        'z21a4
        '
        Me.z21a4.AutoSize = True
        Me.z21a4.Location = New System.Drawing.Point(127, 55)
        Me.z21a4.Name = "z21a4"
        Me.z21a4.Size = New System.Drawing.Size(15, 14)
        Me.z21a4.TabIndex = 19
        Me.z21a4.UseVisualStyleBackColor = True
        '
        'z21a3
        '
        Me.z21a3.AutoSize = True
        Me.z21a3.Location = New System.Drawing.Point(106, 55)
        Me.z21a3.Name = "z21a3"
        Me.z21a3.Size = New System.Drawing.Size(15, 14)
        Me.z21a3.TabIndex = 18
        Me.z21a3.UseVisualStyleBackColor = True
        '
        'z21a2
        '
        Me.z21a2.AutoSize = True
        Me.z21a2.Location = New System.Drawing.Point(85, 55)
        Me.z21a2.Name = "z21a2"
        Me.z21a2.Size = New System.Drawing.Size(15, 14)
        Me.z21a2.TabIndex = 17
        Me.z21a2.UseVisualStyleBackColor = True
        '
        'Label91
        '
        Me.Label91.AutoSize = True
        Me.Label91.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label91.Location = New System.Drawing.Point(63, 16)
        Me.Label91.Name = "Label91"
        Me.Label91.Size = New System.Drawing.Size(78, 13)
        Me.Label91.TabIndex = 16
        Me.Label91.Text = "Agent Loops"
        '
        'Label92
        '
        Me.Label92.AutoSize = True
        Me.Label92.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label92.Location = New System.Drawing.Point(6, 16)
        Me.Label92.Name = "Label92"
        Me.Label92.Size = New System.Drawing.Size(36, 13)
        Me.Label92.TabIndex = 15
        Me.Label92.Text = "Zone"
        '
        'z21a1
        '
        Me.z21a1.AutoSize = True
        Me.z21a1.Location = New System.Drawing.Point(64, 55)
        Me.z21a1.Name = "z21a1"
        Me.z21a1.Size = New System.Drawing.Size(15, 14)
        Me.z21a1.TabIndex = 14
        Me.z21a1.UseVisualStyleBackColor = True
        '
        'Label93
        '
        Me.Label93.AutoSize = True
        Me.Label93.Location = New System.Drawing.Point(127, 37)
        Me.Label93.Name = "Label93"
        Me.Label93.Size = New System.Drawing.Size(13, 13)
        Me.Label93.TabIndex = 13
        Me.Label93.Text = "4"
        '
        'Label94
        '
        Me.Label94.AutoSize = True
        Me.Label94.Location = New System.Drawing.Point(106, 37)
        Me.Label94.Name = "Label94"
        Me.Label94.Size = New System.Drawing.Size(13, 13)
        Me.Label94.TabIndex = 12
        Me.Label94.Text = "3"
        '
        'Label95
        '
        Me.Label95.AutoSize = True
        Me.Label95.Location = New System.Drawing.Point(85, 37)
        Me.Label95.Name = "Label95"
        Me.Label95.Size = New System.Drawing.Size(13, 13)
        Me.Label95.TabIndex = 11
        Me.Label95.Text = "2"
        '
        'Label96
        '
        Me.Label96.AutoSize = True
        Me.Label96.Location = New System.Drawing.Point(64, 37)
        Me.Label96.Name = "Label96"
        Me.Label96.Size = New System.Drawing.Size(13, 13)
        Me.Label96.TabIndex = 10
        Me.Label96.Text = "1"
        '
        'Label101
        '
        Me.Label101.AutoSize = True
        Me.Label101.Location = New System.Drawing.Point(6, 112)
        Me.Label101.Name = "Label101"
        Me.Label101.Size = New System.Drawing.Size(41, 13)
        Me.Label101.TabIndex = 3
        Me.Label101.Text = "Zone 4"
        '
        'Label102
        '
        Me.Label102.AutoSize = True
        Me.Label102.Location = New System.Drawing.Point(6, 93)
        Me.Label102.Name = "Label102"
        Me.Label102.Size = New System.Drawing.Size(41, 13)
        Me.Label102.TabIndex = 2
        Me.Label102.Text = "Zone 3"
        '
        'Label103
        '
        Me.Label103.AutoSize = True
        Me.Label103.Location = New System.Drawing.Point(6, 74)
        Me.Label103.Name = "Label103"
        Me.Label103.Size = New System.Drawing.Size(41, 13)
        Me.Label103.TabIndex = 1
        Me.Label103.Text = "Zone 2"
        '
        'Label104
        '
        Me.Label104.AutoSize = True
        Me.Label104.Location = New System.Drawing.Point(6, 55)
        Me.Label104.Name = "Label104"
        Me.Label104.Size = New System.Drawing.Size(41, 13)
        Me.Label104.TabIndex = 0
        Me.Label104.Text = "Zone 1"
        '
        'GroupBox11
        '
        Me.GroupBox11.Controls.Add(Me.Panel2)
        Me.GroupBox11.Controls.Add(Me.CheckBox57)
        Me.GroupBox11.Controls.Add(Me.CheckBox58)
        Me.GroupBox11.Controls.Add(Me.CheckBox59)
        Me.GroupBox11.Controls.Add(Me.CheckBox60)
        Me.GroupBox11.Controls.Add(Me.CheckBox61)
        Me.GroupBox11.Controls.Add(Me.CheckBox62)
        Me.GroupBox11.Controls.Add(Me.CheckBox63)
        Me.GroupBox11.Controls.Add(Me.CheckBox64)
        Me.GroupBox11.Controls.Add(Me.CheckBox65)
        Me.GroupBox11.Controls.Add(Me.CheckBox66)
        Me.GroupBox11.Controls.Add(Me.CheckBox67)
        Me.GroupBox11.Controls.Add(Me.CheckBox68)
        Me.GroupBox11.Controls.Add(Me.CheckBox69)
        Me.GroupBox11.Controls.Add(Me.CheckBox70)
        Me.GroupBox11.Controls.Add(Me.CheckBox71)
        Me.GroupBox11.Controls.Add(Me.Label115)
        Me.GroupBox11.Controls.Add(Me.Label116)
        Me.GroupBox11.Controls.Add(Me.CheckBox72)
        Me.GroupBox11.Controls.Add(Me.Label117)
        Me.GroupBox11.Controls.Add(Me.Label118)
        Me.GroupBox11.Controls.Add(Me.Label119)
        Me.GroupBox11.Controls.Add(Me.Label120)
        Me.GroupBox11.Controls.Add(Me.Label121)
        Me.GroupBox11.Controls.Add(Me.Label122)
        Me.GroupBox11.Controls.Add(Me.Label123)
        Me.GroupBox11.Controls.Add(Me.Label124)
        Me.GroupBox11.Location = New System.Drawing.Point(483, 130)
        Me.GroupBox11.Name = "GroupBox11"
        Me.GroupBox11.Size = New System.Drawing.Size(150, 136)
        Me.GroupBox11.TabIndex = 58
        Me.GroupBox11.TabStop = False
        Me.GroupBox11.Text = "System Extender 3"
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.Label125)
        Me.Panel2.Location = New System.Drawing.Point(7, 16)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(134, 109)
        Me.Panel2.TabIndex = 32
        '
        'Label125
        '
        Me.Label125.AutoSize = True
        Me.Label125.Location = New System.Drawing.Point(8, 8)
        Me.Label125.Name = "Label125"
        Me.Label125.Size = New System.Drawing.Size(76, 13)
        Me.Label125.TabIndex = 0
        Me.Label125.Text = "Not Supported"
        '
        'CheckBox57
        '
        Me.CheckBox57.AutoSize = True
        Me.CheckBox57.Location = New System.Drawing.Point(127, 112)
        Me.CheckBox57.Name = "CheckBox57"
        Me.CheckBox57.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox57.TabIndex = 31
        Me.CheckBox57.UseVisualStyleBackColor = True
        '
        'CheckBox58
        '
        Me.CheckBox58.AutoSize = True
        Me.CheckBox58.Location = New System.Drawing.Point(106, 112)
        Me.CheckBox58.Name = "CheckBox58"
        Me.CheckBox58.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox58.TabIndex = 30
        Me.CheckBox58.UseVisualStyleBackColor = True
        '
        'CheckBox59
        '
        Me.CheckBox59.AutoSize = True
        Me.CheckBox59.Location = New System.Drawing.Point(85, 112)
        Me.CheckBox59.Name = "CheckBox59"
        Me.CheckBox59.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox59.TabIndex = 29
        Me.CheckBox59.UseVisualStyleBackColor = True
        '
        'CheckBox60
        '
        Me.CheckBox60.AutoSize = True
        Me.CheckBox60.Location = New System.Drawing.Point(64, 112)
        Me.CheckBox60.Name = "CheckBox60"
        Me.CheckBox60.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox60.TabIndex = 28
        Me.CheckBox60.UseVisualStyleBackColor = True
        '
        'CheckBox61
        '
        Me.CheckBox61.AutoSize = True
        Me.CheckBox61.Location = New System.Drawing.Point(127, 93)
        Me.CheckBox61.Name = "CheckBox61"
        Me.CheckBox61.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox61.TabIndex = 27
        Me.CheckBox61.UseVisualStyleBackColor = True
        '
        'CheckBox62
        '
        Me.CheckBox62.AutoSize = True
        Me.CheckBox62.Location = New System.Drawing.Point(106, 93)
        Me.CheckBox62.Name = "CheckBox62"
        Me.CheckBox62.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox62.TabIndex = 26
        Me.CheckBox62.UseVisualStyleBackColor = True
        '
        'CheckBox63
        '
        Me.CheckBox63.AutoSize = True
        Me.CheckBox63.Location = New System.Drawing.Point(85, 93)
        Me.CheckBox63.Name = "CheckBox63"
        Me.CheckBox63.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox63.TabIndex = 25
        Me.CheckBox63.UseVisualStyleBackColor = True
        '
        'CheckBox64
        '
        Me.CheckBox64.AutoSize = True
        Me.CheckBox64.Location = New System.Drawing.Point(64, 93)
        Me.CheckBox64.Name = "CheckBox64"
        Me.CheckBox64.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox64.TabIndex = 24
        Me.CheckBox64.UseVisualStyleBackColor = True
        '
        'CheckBox65
        '
        Me.CheckBox65.AutoSize = True
        Me.CheckBox65.Location = New System.Drawing.Point(127, 74)
        Me.CheckBox65.Name = "CheckBox65"
        Me.CheckBox65.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox65.TabIndex = 23
        Me.CheckBox65.UseVisualStyleBackColor = True
        '
        'CheckBox66
        '
        Me.CheckBox66.AutoSize = True
        Me.CheckBox66.Location = New System.Drawing.Point(106, 74)
        Me.CheckBox66.Name = "CheckBox66"
        Me.CheckBox66.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox66.TabIndex = 22
        Me.CheckBox66.UseVisualStyleBackColor = True
        '
        'CheckBox67
        '
        Me.CheckBox67.AutoSize = True
        Me.CheckBox67.Location = New System.Drawing.Point(85, 74)
        Me.CheckBox67.Name = "CheckBox67"
        Me.CheckBox67.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox67.TabIndex = 21
        Me.CheckBox67.UseVisualStyleBackColor = True
        '
        'CheckBox68
        '
        Me.CheckBox68.AutoSize = True
        Me.CheckBox68.Location = New System.Drawing.Point(64, 74)
        Me.CheckBox68.Name = "CheckBox68"
        Me.CheckBox68.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox68.TabIndex = 20
        Me.CheckBox68.UseVisualStyleBackColor = True
        '
        'CheckBox69
        '
        Me.CheckBox69.AutoSize = True
        Me.CheckBox69.Location = New System.Drawing.Point(127, 55)
        Me.CheckBox69.Name = "CheckBox69"
        Me.CheckBox69.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox69.TabIndex = 19
        Me.CheckBox69.UseVisualStyleBackColor = True
        '
        'CheckBox70
        '
        Me.CheckBox70.AutoSize = True
        Me.CheckBox70.Location = New System.Drawing.Point(106, 55)
        Me.CheckBox70.Name = "CheckBox70"
        Me.CheckBox70.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox70.TabIndex = 18
        Me.CheckBox70.UseVisualStyleBackColor = True
        '
        'CheckBox71
        '
        Me.CheckBox71.AutoSize = True
        Me.CheckBox71.Location = New System.Drawing.Point(85, 55)
        Me.CheckBox71.Name = "CheckBox71"
        Me.CheckBox71.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox71.TabIndex = 17
        Me.CheckBox71.UseVisualStyleBackColor = True
        '
        'Label115
        '
        Me.Label115.AutoSize = True
        Me.Label115.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label115.Location = New System.Drawing.Point(63, 16)
        Me.Label115.Name = "Label115"
        Me.Label115.Size = New System.Drawing.Size(78, 13)
        Me.Label115.TabIndex = 16
        Me.Label115.Text = "Agent Loops"
        '
        'Label116
        '
        Me.Label116.AutoSize = True
        Me.Label116.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label116.Location = New System.Drawing.Point(6, 16)
        Me.Label116.Name = "Label116"
        Me.Label116.Size = New System.Drawing.Size(36, 13)
        Me.Label116.TabIndex = 15
        Me.Label116.Text = "Zone"
        '
        'CheckBox72
        '
        Me.CheckBox72.AutoSize = True
        Me.CheckBox72.Location = New System.Drawing.Point(64, 55)
        Me.CheckBox72.Name = "CheckBox72"
        Me.CheckBox72.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox72.TabIndex = 14
        Me.CheckBox72.UseVisualStyleBackColor = True
        '
        'Label117
        '
        Me.Label117.AutoSize = True
        Me.Label117.Location = New System.Drawing.Point(127, 37)
        Me.Label117.Name = "Label117"
        Me.Label117.Size = New System.Drawing.Size(13, 13)
        Me.Label117.TabIndex = 13
        Me.Label117.Text = "4"
        '
        'Label118
        '
        Me.Label118.AutoSize = True
        Me.Label118.Location = New System.Drawing.Point(106, 37)
        Me.Label118.Name = "Label118"
        Me.Label118.Size = New System.Drawing.Size(13, 13)
        Me.Label118.TabIndex = 12
        Me.Label118.Text = "3"
        '
        'Label119
        '
        Me.Label119.AutoSize = True
        Me.Label119.Location = New System.Drawing.Point(85, 37)
        Me.Label119.Name = "Label119"
        Me.Label119.Size = New System.Drawing.Size(13, 13)
        Me.Label119.TabIndex = 11
        Me.Label119.Text = "2"
        '
        'Label120
        '
        Me.Label120.AutoSize = True
        Me.Label120.Location = New System.Drawing.Point(64, 37)
        Me.Label120.Name = "Label120"
        Me.Label120.Size = New System.Drawing.Size(13, 13)
        Me.Label120.TabIndex = 10
        Me.Label120.Text = "1"
        '
        'Label121
        '
        Me.Label121.AutoSize = True
        Me.Label121.Location = New System.Drawing.Point(6, 112)
        Me.Label121.Name = "Label121"
        Me.Label121.Size = New System.Drawing.Size(41, 13)
        Me.Label121.TabIndex = 3
        Me.Label121.Text = "Zone 4"
        '
        'Label122
        '
        Me.Label122.AutoSize = True
        Me.Label122.Location = New System.Drawing.Point(6, 93)
        Me.Label122.Name = "Label122"
        Me.Label122.Size = New System.Drawing.Size(41, 13)
        Me.Label122.TabIndex = 2
        Me.Label122.Text = "Zone 3"
        '
        'Label123
        '
        Me.Label123.AutoSize = True
        Me.Label123.Location = New System.Drawing.Point(6, 74)
        Me.Label123.Name = "Label123"
        Me.Label123.Size = New System.Drawing.Size(41, 13)
        Me.Label123.TabIndex = 1
        Me.Label123.Text = "Zone 2"
        '
        'Label124
        '
        Me.Label124.AutoSize = True
        Me.Label124.Location = New System.Drawing.Point(6, 55)
        Me.Label124.Name = "Label124"
        Me.Label124.Size = New System.Drawing.Size(41, 13)
        Me.Label124.TabIndex = 0
        Me.Label124.Text = "Zone 1"
        '
        'GroupBox8
        '
        Me.GroupBox8.Controls.Add(Me.z14a4)
        Me.GroupBox8.Controls.Add(Me.z14a3)
        Me.GroupBox8.Controls.Add(Me.z14a2)
        Me.GroupBox8.Controls.Add(Me.z14a1)
        Me.GroupBox8.Controls.Add(Me.z13a4)
        Me.GroupBox8.Controls.Add(Me.z13a3)
        Me.GroupBox8.Controls.Add(Me.z13a2)
        Me.GroupBox8.Controls.Add(Me.z13a1)
        Me.GroupBox8.Controls.Add(Me.z12a4)
        Me.GroupBox8.Controls.Add(Me.z12a3)
        Me.GroupBox8.Controls.Add(Me.z12a2)
        Me.GroupBox8.Controls.Add(Me.z12a1)
        Me.GroupBox8.Controls.Add(Me.z11a4)
        Me.GroupBox8.Controls.Add(Me.z11a3)
        Me.GroupBox8.Controls.Add(Me.z11a2)
        Me.GroupBox8.Controls.Add(Me.Label85)
        Me.GroupBox8.Controls.Add(Me.Label86)
        Me.GroupBox8.Controls.Add(Me.z11a1)
        Me.GroupBox8.Controls.Add(Me.Label87)
        Me.GroupBox8.Controls.Add(Me.Label88)
        Me.GroupBox8.Controls.Add(Me.Label89)
        Me.GroupBox8.Controls.Add(Me.Label90)
        Me.GroupBox8.Controls.Add(Me.Label97)
        Me.GroupBox8.Controls.Add(Me.Label98)
        Me.GroupBox8.Controls.Add(Me.Label99)
        Me.GroupBox8.Controls.Add(Me.Label100)
        Me.GroupBox8.Location = New System.Drawing.Point(171, 130)
        Me.GroupBox8.Name = "GroupBox8"
        Me.GroupBox8.Size = New System.Drawing.Size(150, 136)
        Me.GroupBox8.TabIndex = 56
        Me.GroupBox8.TabStop = False
        Me.GroupBox8.Text = "System Extender 1"
        '
        'z14a4
        '
        Me.z14a4.AutoSize = True
        Me.z14a4.Location = New System.Drawing.Point(127, 112)
        Me.z14a4.Name = "z14a4"
        Me.z14a4.Size = New System.Drawing.Size(15, 14)
        Me.z14a4.TabIndex = 31
        Me.z14a4.UseVisualStyleBackColor = True
        '
        'z14a3
        '
        Me.z14a3.AutoSize = True
        Me.z14a3.Location = New System.Drawing.Point(106, 112)
        Me.z14a3.Name = "z14a3"
        Me.z14a3.Size = New System.Drawing.Size(15, 14)
        Me.z14a3.TabIndex = 30
        Me.z14a3.UseVisualStyleBackColor = True
        '
        'z14a2
        '
        Me.z14a2.AutoSize = True
        Me.z14a2.Location = New System.Drawing.Point(85, 112)
        Me.z14a2.Name = "z14a2"
        Me.z14a2.Size = New System.Drawing.Size(15, 14)
        Me.z14a2.TabIndex = 29
        Me.z14a2.UseVisualStyleBackColor = True
        '
        'z14a1
        '
        Me.z14a1.AutoSize = True
        Me.z14a1.Location = New System.Drawing.Point(64, 112)
        Me.z14a1.Name = "z14a1"
        Me.z14a1.Size = New System.Drawing.Size(15, 14)
        Me.z14a1.TabIndex = 28
        Me.z14a1.UseVisualStyleBackColor = True
        '
        'z13a4
        '
        Me.z13a4.AutoSize = True
        Me.z13a4.Location = New System.Drawing.Point(127, 93)
        Me.z13a4.Name = "z13a4"
        Me.z13a4.Size = New System.Drawing.Size(15, 14)
        Me.z13a4.TabIndex = 27
        Me.z13a4.UseVisualStyleBackColor = True
        '
        'z13a3
        '
        Me.z13a3.AutoSize = True
        Me.z13a3.Location = New System.Drawing.Point(106, 93)
        Me.z13a3.Name = "z13a3"
        Me.z13a3.Size = New System.Drawing.Size(15, 14)
        Me.z13a3.TabIndex = 26
        Me.z13a3.UseVisualStyleBackColor = True
        '
        'z13a2
        '
        Me.z13a2.AutoSize = True
        Me.z13a2.Location = New System.Drawing.Point(85, 93)
        Me.z13a2.Name = "z13a2"
        Me.z13a2.Size = New System.Drawing.Size(15, 14)
        Me.z13a2.TabIndex = 25
        Me.z13a2.UseVisualStyleBackColor = True
        '
        'z13a1
        '
        Me.z13a1.AutoSize = True
        Me.z13a1.Location = New System.Drawing.Point(64, 93)
        Me.z13a1.Name = "z13a1"
        Me.z13a1.Size = New System.Drawing.Size(15, 14)
        Me.z13a1.TabIndex = 24
        Me.z13a1.UseVisualStyleBackColor = True
        '
        'z12a4
        '
        Me.z12a4.AutoSize = True
        Me.z12a4.Location = New System.Drawing.Point(127, 74)
        Me.z12a4.Name = "z12a4"
        Me.z12a4.Size = New System.Drawing.Size(15, 14)
        Me.z12a4.TabIndex = 23
        Me.z12a4.UseVisualStyleBackColor = True
        '
        'z12a3
        '
        Me.z12a3.AutoSize = True
        Me.z12a3.Location = New System.Drawing.Point(106, 74)
        Me.z12a3.Name = "z12a3"
        Me.z12a3.Size = New System.Drawing.Size(15, 14)
        Me.z12a3.TabIndex = 22
        Me.z12a3.UseVisualStyleBackColor = True
        '
        'z12a2
        '
        Me.z12a2.AutoSize = True
        Me.z12a2.Location = New System.Drawing.Point(85, 74)
        Me.z12a2.Name = "z12a2"
        Me.z12a2.Size = New System.Drawing.Size(15, 14)
        Me.z12a2.TabIndex = 21
        Me.z12a2.UseVisualStyleBackColor = True
        '
        'z12a1
        '
        Me.z12a1.AutoSize = True
        Me.z12a1.Location = New System.Drawing.Point(64, 74)
        Me.z12a1.Name = "z12a1"
        Me.z12a1.Size = New System.Drawing.Size(15, 14)
        Me.z12a1.TabIndex = 20
        Me.z12a1.UseVisualStyleBackColor = True
        '
        'z11a4
        '
        Me.z11a4.AutoSize = True
        Me.z11a4.Location = New System.Drawing.Point(127, 55)
        Me.z11a4.Name = "z11a4"
        Me.z11a4.Size = New System.Drawing.Size(15, 14)
        Me.z11a4.TabIndex = 19
        Me.z11a4.UseVisualStyleBackColor = True
        '
        'z11a3
        '
        Me.z11a3.AutoSize = True
        Me.z11a3.Location = New System.Drawing.Point(106, 55)
        Me.z11a3.Name = "z11a3"
        Me.z11a3.Size = New System.Drawing.Size(15, 14)
        Me.z11a3.TabIndex = 18
        Me.z11a3.UseVisualStyleBackColor = True
        '
        'z11a2
        '
        Me.z11a2.AutoSize = True
        Me.z11a2.Location = New System.Drawing.Point(85, 55)
        Me.z11a2.Name = "z11a2"
        Me.z11a2.Size = New System.Drawing.Size(15, 14)
        Me.z11a2.TabIndex = 17
        Me.z11a2.UseVisualStyleBackColor = True
        '
        'Label85
        '
        Me.Label85.AutoSize = True
        Me.Label85.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label85.Location = New System.Drawing.Point(63, 16)
        Me.Label85.Name = "Label85"
        Me.Label85.Size = New System.Drawing.Size(78, 13)
        Me.Label85.TabIndex = 16
        Me.Label85.Text = "Agent Loops"
        '
        'Label86
        '
        Me.Label86.AutoSize = True
        Me.Label86.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label86.Location = New System.Drawing.Point(6, 16)
        Me.Label86.Name = "Label86"
        Me.Label86.Size = New System.Drawing.Size(36, 13)
        Me.Label86.TabIndex = 15
        Me.Label86.Text = "Zone"
        '
        'z11a1
        '
        Me.z11a1.AutoSize = True
        Me.z11a1.Location = New System.Drawing.Point(64, 55)
        Me.z11a1.Name = "z11a1"
        Me.z11a1.Size = New System.Drawing.Size(15, 14)
        Me.z11a1.TabIndex = 14
        Me.z11a1.UseVisualStyleBackColor = True
        '
        'Label87
        '
        Me.Label87.AutoSize = True
        Me.Label87.Location = New System.Drawing.Point(127, 37)
        Me.Label87.Name = "Label87"
        Me.Label87.Size = New System.Drawing.Size(13, 13)
        Me.Label87.TabIndex = 13
        Me.Label87.Text = "4"
        '
        'Label88
        '
        Me.Label88.AutoSize = True
        Me.Label88.Location = New System.Drawing.Point(106, 37)
        Me.Label88.Name = "Label88"
        Me.Label88.Size = New System.Drawing.Size(13, 13)
        Me.Label88.TabIndex = 12
        Me.Label88.Text = "3"
        '
        'Label89
        '
        Me.Label89.AutoSize = True
        Me.Label89.Location = New System.Drawing.Point(85, 37)
        Me.Label89.Name = "Label89"
        Me.Label89.Size = New System.Drawing.Size(13, 13)
        Me.Label89.TabIndex = 11
        Me.Label89.Text = "2"
        '
        'Label90
        '
        Me.Label90.AutoSize = True
        Me.Label90.Location = New System.Drawing.Point(64, 37)
        Me.Label90.Name = "Label90"
        Me.Label90.Size = New System.Drawing.Size(13, 13)
        Me.Label90.TabIndex = 10
        Me.Label90.Text = "1"
        '
        'Label97
        '
        Me.Label97.AutoSize = True
        Me.Label97.Location = New System.Drawing.Point(6, 112)
        Me.Label97.Name = "Label97"
        Me.Label97.Size = New System.Drawing.Size(41, 13)
        Me.Label97.TabIndex = 3
        Me.Label97.Text = "Zone 4"
        '
        'Label98
        '
        Me.Label98.AutoSize = True
        Me.Label98.Location = New System.Drawing.Point(6, 93)
        Me.Label98.Name = "Label98"
        Me.Label98.Size = New System.Drawing.Size(41, 13)
        Me.Label98.TabIndex = 2
        Me.Label98.Text = "Zone 3"
        '
        'Label99
        '
        Me.Label99.AutoSize = True
        Me.Label99.Location = New System.Drawing.Point(6, 74)
        Me.Label99.Name = "Label99"
        Me.Label99.Size = New System.Drawing.Size(41, 13)
        Me.Label99.TabIndex = 1
        Me.Label99.Text = "Zone 2"
        '
        'Label100
        '
        Me.Label100.AutoSize = True
        Me.Label100.Location = New System.Drawing.Point(6, 55)
        Me.Label100.Name = "Label100"
        Me.Label100.Size = New System.Drawing.Size(41, 13)
        Me.Label100.TabIndex = 0
        Me.Label100.Text = "Zone 1"
        '
        'Label68
        '
        Me.Label68.AutoSize = True
        Me.Label68.Location = New System.Drawing.Point(12, 108)
        Me.Label68.Name = "Label68"
        Me.Label68.Size = New System.Drawing.Size(782, 13)
        Me.Label68.TabIndex = 8
        Me.Label68.Text = "The AGENT RELEASE zone will initiate a FULL SYSTEM DISCHARGE, which could be both" &
    " interferent and also VERY COSTLY, depending on your agent system. "
        '
        'GroupBox7
        '
        Me.GroupBox7.Controls.Add(Me.z10a4)
        Me.GroupBox7.Controls.Add(Me.z10a3)
        Me.GroupBox7.Controls.Add(Me.z10a2)
        Me.GroupBox7.Controls.Add(Me.z10a1)
        Me.GroupBox7.Controls.Add(Me.z9a4)
        Me.GroupBox7.Controls.Add(Me.z9a3)
        Me.GroupBox7.Controls.Add(Me.z9a2)
        Me.GroupBox7.Controls.Add(Me.z9a1)
        Me.GroupBox7.Controls.Add(Me.z8a4)
        Me.GroupBox7.Controls.Add(Me.z8a3)
        Me.GroupBox7.Controls.Add(Me.z8a2)
        Me.GroupBox7.Controls.Add(Me.z8a1)
        Me.GroupBox7.Controls.Add(Me.z7a4)
        Me.GroupBox7.Controls.Add(Me.z7a3)
        Me.GroupBox7.Controls.Add(Me.z7a2)
        Me.GroupBox7.Controls.Add(Me.z7a1)
        Me.GroupBox7.Controls.Add(Me.z6a4)
        Me.GroupBox7.Controls.Add(Me.z6a3)
        Me.GroupBox7.Controls.Add(Me.z6a2)
        Me.GroupBox7.Controls.Add(Me.z6a1)
        Me.GroupBox7.Controls.Add(Me.z5a4)
        Me.GroupBox7.Controls.Add(Me.z5a3)
        Me.GroupBox7.Controls.Add(Me.z5a2)
        Me.GroupBox7.Controls.Add(Me.z5a1)
        Me.GroupBox7.Controls.Add(Me.z4a4)
        Me.GroupBox7.Controls.Add(Me.z4a3)
        Me.GroupBox7.Controls.Add(Me.z4a2)
        Me.GroupBox7.Controls.Add(Me.z4a1)
        Me.GroupBox7.Controls.Add(Me.z3a4)
        Me.GroupBox7.Controls.Add(Me.z3a3)
        Me.GroupBox7.Controls.Add(Me.z3a2)
        Me.GroupBox7.Controls.Add(Me.z3a1)
        Me.GroupBox7.Controls.Add(Me.z2a4)
        Me.GroupBox7.Controls.Add(Me.z2a3)
        Me.GroupBox7.Controls.Add(Me.z2a2)
        Me.GroupBox7.Controls.Add(Me.z2a1)
        Me.GroupBox7.Controls.Add(Me.z1a4)
        Me.GroupBox7.Controls.Add(Me.z1a3)
        Me.GroupBox7.Controls.Add(Me.z1a2)
        Me.GroupBox7.Controls.Add(Me.Label84)
        Me.GroupBox7.Controls.Add(Me.Label83)
        Me.GroupBox7.Controls.Add(Me.z1a1)
        Me.GroupBox7.Controls.Add(Me.Label81)
        Me.GroupBox7.Controls.Add(Me.Label82)
        Me.GroupBox7.Controls.Add(Me.Label80)
        Me.GroupBox7.Controls.Add(Me.Label79)
        Me.GroupBox7.Controls.Add(Me.Label77)
        Me.GroupBox7.Controls.Add(Me.Label78)
        Me.GroupBox7.Controls.Add(Me.Label73)
        Me.GroupBox7.Controls.Add(Me.Label74)
        Me.GroupBox7.Controls.Add(Me.Label75)
        Me.GroupBox7.Controls.Add(Me.Label76)
        Me.GroupBox7.Controls.Add(Me.Label72)
        Me.GroupBox7.Controls.Add(Me.Label71)
        Me.GroupBox7.Controls.Add(Me.Label70)
        Me.GroupBox7.Controls.Add(Me.Label69)
        Me.GroupBox7.Location = New System.Drawing.Point(15, 130)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Size = New System.Drawing.Size(150, 247)
        Me.GroupBox7.TabIndex = 7
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "Local panel"
        '
        'z10a4
        '
        Me.z10a4.AutoSize = True
        Me.z10a4.Location = New System.Drawing.Point(127, 226)
        Me.z10a4.Name = "z10a4"
        Me.z10a4.Size = New System.Drawing.Size(15, 14)
        Me.z10a4.TabIndex = 55
        Me.z10a4.UseVisualStyleBackColor = True
        '
        'z10a3
        '
        Me.z10a3.AutoSize = True
        Me.z10a3.Location = New System.Drawing.Point(106, 226)
        Me.z10a3.Name = "z10a3"
        Me.z10a3.Size = New System.Drawing.Size(15, 14)
        Me.z10a3.TabIndex = 54
        Me.z10a3.UseVisualStyleBackColor = True
        '
        'z10a2
        '
        Me.z10a2.AutoSize = True
        Me.z10a2.Location = New System.Drawing.Point(85, 226)
        Me.z10a2.Name = "z10a2"
        Me.z10a2.Size = New System.Drawing.Size(15, 14)
        Me.z10a2.TabIndex = 53
        Me.z10a2.UseVisualStyleBackColor = True
        '
        'z10a1
        '
        Me.z10a1.AutoSize = True
        Me.z10a1.Location = New System.Drawing.Point(64, 226)
        Me.z10a1.Name = "z10a1"
        Me.z10a1.Size = New System.Drawing.Size(15, 14)
        Me.z10a1.TabIndex = 52
        Me.z10a1.UseVisualStyleBackColor = True
        '
        'z9a4
        '
        Me.z9a4.AutoSize = True
        Me.z9a4.Location = New System.Drawing.Point(127, 207)
        Me.z9a4.Name = "z9a4"
        Me.z9a4.Size = New System.Drawing.Size(15, 14)
        Me.z9a4.TabIndex = 51
        Me.z9a4.UseVisualStyleBackColor = True
        '
        'z9a3
        '
        Me.z9a3.AutoSize = True
        Me.z9a3.Location = New System.Drawing.Point(106, 207)
        Me.z9a3.Name = "z9a3"
        Me.z9a3.Size = New System.Drawing.Size(15, 14)
        Me.z9a3.TabIndex = 50
        Me.z9a3.UseVisualStyleBackColor = True
        '
        'z9a2
        '
        Me.z9a2.AutoSize = True
        Me.z9a2.Location = New System.Drawing.Point(85, 207)
        Me.z9a2.Name = "z9a2"
        Me.z9a2.Size = New System.Drawing.Size(15, 14)
        Me.z9a2.TabIndex = 49
        Me.z9a2.UseVisualStyleBackColor = True
        '
        'z9a1
        '
        Me.z9a1.AutoSize = True
        Me.z9a1.Location = New System.Drawing.Point(64, 207)
        Me.z9a1.Name = "z9a1"
        Me.z9a1.Size = New System.Drawing.Size(15, 14)
        Me.z9a1.TabIndex = 48
        Me.z9a1.UseVisualStyleBackColor = True
        '
        'z8a4
        '
        Me.z8a4.AutoSize = True
        Me.z8a4.Location = New System.Drawing.Point(127, 188)
        Me.z8a4.Name = "z8a4"
        Me.z8a4.Size = New System.Drawing.Size(15, 14)
        Me.z8a4.TabIndex = 47
        Me.z8a4.UseVisualStyleBackColor = True
        '
        'z8a3
        '
        Me.z8a3.AutoSize = True
        Me.z8a3.Location = New System.Drawing.Point(106, 188)
        Me.z8a3.Name = "z8a3"
        Me.z8a3.Size = New System.Drawing.Size(15, 14)
        Me.z8a3.TabIndex = 46
        Me.z8a3.UseVisualStyleBackColor = True
        '
        'z8a2
        '
        Me.z8a2.AutoSize = True
        Me.z8a2.Location = New System.Drawing.Point(85, 188)
        Me.z8a2.Name = "z8a2"
        Me.z8a2.Size = New System.Drawing.Size(15, 14)
        Me.z8a2.TabIndex = 45
        Me.z8a2.UseVisualStyleBackColor = True
        '
        'z8a1
        '
        Me.z8a1.AutoSize = True
        Me.z8a1.Location = New System.Drawing.Point(64, 188)
        Me.z8a1.Name = "z8a1"
        Me.z8a1.Size = New System.Drawing.Size(15, 14)
        Me.z8a1.TabIndex = 44
        Me.z8a1.UseVisualStyleBackColor = True
        '
        'z7a4
        '
        Me.z7a4.AutoSize = True
        Me.z7a4.Location = New System.Drawing.Point(127, 169)
        Me.z7a4.Name = "z7a4"
        Me.z7a4.Size = New System.Drawing.Size(15, 14)
        Me.z7a4.TabIndex = 43
        Me.z7a4.UseVisualStyleBackColor = True
        '
        'z7a3
        '
        Me.z7a3.AutoSize = True
        Me.z7a3.Location = New System.Drawing.Point(106, 169)
        Me.z7a3.Name = "z7a3"
        Me.z7a3.Size = New System.Drawing.Size(15, 14)
        Me.z7a3.TabIndex = 42
        Me.z7a3.UseVisualStyleBackColor = True
        '
        'z7a2
        '
        Me.z7a2.AutoSize = True
        Me.z7a2.Location = New System.Drawing.Point(85, 169)
        Me.z7a2.Name = "z7a2"
        Me.z7a2.Size = New System.Drawing.Size(15, 14)
        Me.z7a2.TabIndex = 41
        Me.z7a2.UseVisualStyleBackColor = True
        '
        'z7a1
        '
        Me.z7a1.AutoSize = True
        Me.z7a1.Location = New System.Drawing.Point(64, 169)
        Me.z7a1.Name = "z7a1"
        Me.z7a1.Size = New System.Drawing.Size(15, 14)
        Me.z7a1.TabIndex = 40
        Me.z7a1.UseVisualStyleBackColor = True
        '
        'z6a4
        '
        Me.z6a4.AutoSize = True
        Me.z6a4.Location = New System.Drawing.Point(127, 150)
        Me.z6a4.Name = "z6a4"
        Me.z6a4.Size = New System.Drawing.Size(15, 14)
        Me.z6a4.TabIndex = 39
        Me.z6a4.UseVisualStyleBackColor = True
        '
        'z6a3
        '
        Me.z6a3.AutoSize = True
        Me.z6a3.Location = New System.Drawing.Point(106, 150)
        Me.z6a3.Name = "z6a3"
        Me.z6a3.Size = New System.Drawing.Size(15, 14)
        Me.z6a3.TabIndex = 38
        Me.z6a3.UseVisualStyleBackColor = True
        '
        'z6a2
        '
        Me.z6a2.AutoSize = True
        Me.z6a2.Location = New System.Drawing.Point(85, 150)
        Me.z6a2.Name = "z6a2"
        Me.z6a2.Size = New System.Drawing.Size(15, 14)
        Me.z6a2.TabIndex = 37
        Me.z6a2.UseVisualStyleBackColor = True
        '
        'z6a1
        '
        Me.z6a1.AutoSize = True
        Me.z6a1.Location = New System.Drawing.Point(64, 150)
        Me.z6a1.Name = "z6a1"
        Me.z6a1.Size = New System.Drawing.Size(15, 14)
        Me.z6a1.TabIndex = 36
        Me.z6a1.UseVisualStyleBackColor = True
        '
        'z5a4
        '
        Me.z5a4.AutoSize = True
        Me.z5a4.Location = New System.Drawing.Point(127, 131)
        Me.z5a4.Name = "z5a4"
        Me.z5a4.Size = New System.Drawing.Size(15, 14)
        Me.z5a4.TabIndex = 35
        Me.z5a4.UseVisualStyleBackColor = True
        '
        'z5a3
        '
        Me.z5a3.AutoSize = True
        Me.z5a3.Location = New System.Drawing.Point(106, 131)
        Me.z5a3.Name = "z5a3"
        Me.z5a3.Size = New System.Drawing.Size(15, 14)
        Me.z5a3.TabIndex = 34
        Me.z5a3.UseVisualStyleBackColor = True
        '
        'z5a2
        '
        Me.z5a2.AutoSize = True
        Me.z5a2.Location = New System.Drawing.Point(85, 131)
        Me.z5a2.Name = "z5a2"
        Me.z5a2.Size = New System.Drawing.Size(15, 14)
        Me.z5a2.TabIndex = 33
        Me.z5a2.UseVisualStyleBackColor = True
        '
        'z5a1
        '
        Me.z5a1.AutoSize = True
        Me.z5a1.Location = New System.Drawing.Point(64, 131)
        Me.z5a1.Name = "z5a1"
        Me.z5a1.Size = New System.Drawing.Size(15, 14)
        Me.z5a1.TabIndex = 32
        Me.z5a1.UseVisualStyleBackColor = True
        '
        'z4a4
        '
        Me.z4a4.AutoSize = True
        Me.z4a4.Location = New System.Drawing.Point(127, 112)
        Me.z4a4.Name = "z4a4"
        Me.z4a4.Size = New System.Drawing.Size(15, 14)
        Me.z4a4.TabIndex = 31
        Me.z4a4.UseVisualStyleBackColor = True
        '
        'z4a3
        '
        Me.z4a3.AutoSize = True
        Me.z4a3.Location = New System.Drawing.Point(106, 112)
        Me.z4a3.Name = "z4a3"
        Me.z4a3.Size = New System.Drawing.Size(15, 14)
        Me.z4a3.TabIndex = 30
        Me.z4a3.UseVisualStyleBackColor = True
        '
        'z4a2
        '
        Me.z4a2.AutoSize = True
        Me.z4a2.Location = New System.Drawing.Point(85, 112)
        Me.z4a2.Name = "z4a2"
        Me.z4a2.Size = New System.Drawing.Size(15, 14)
        Me.z4a2.TabIndex = 29
        Me.z4a2.UseVisualStyleBackColor = True
        '
        'z4a1
        '
        Me.z4a1.AutoSize = True
        Me.z4a1.Location = New System.Drawing.Point(64, 112)
        Me.z4a1.Name = "z4a1"
        Me.z4a1.Size = New System.Drawing.Size(15, 14)
        Me.z4a1.TabIndex = 28
        Me.z4a1.UseVisualStyleBackColor = True
        '
        'z3a4
        '
        Me.z3a4.AutoSize = True
        Me.z3a4.Location = New System.Drawing.Point(127, 93)
        Me.z3a4.Name = "z3a4"
        Me.z3a4.Size = New System.Drawing.Size(15, 14)
        Me.z3a4.TabIndex = 27
        Me.z3a4.UseVisualStyleBackColor = True
        '
        'z3a3
        '
        Me.z3a3.AutoSize = True
        Me.z3a3.Location = New System.Drawing.Point(106, 93)
        Me.z3a3.Name = "z3a3"
        Me.z3a3.Size = New System.Drawing.Size(15, 14)
        Me.z3a3.TabIndex = 26
        Me.z3a3.UseVisualStyleBackColor = True
        '
        'z3a2
        '
        Me.z3a2.AutoSize = True
        Me.z3a2.Location = New System.Drawing.Point(85, 93)
        Me.z3a2.Name = "z3a2"
        Me.z3a2.Size = New System.Drawing.Size(15, 14)
        Me.z3a2.TabIndex = 25
        Me.z3a2.UseVisualStyleBackColor = True
        '
        'z3a1
        '
        Me.z3a1.AutoSize = True
        Me.z3a1.Location = New System.Drawing.Point(64, 93)
        Me.z3a1.Name = "z3a1"
        Me.z3a1.Size = New System.Drawing.Size(15, 14)
        Me.z3a1.TabIndex = 24
        Me.z3a1.UseVisualStyleBackColor = True
        '
        'z2a4
        '
        Me.z2a4.AutoSize = True
        Me.z2a4.Location = New System.Drawing.Point(127, 74)
        Me.z2a4.Name = "z2a4"
        Me.z2a4.Size = New System.Drawing.Size(15, 14)
        Me.z2a4.TabIndex = 23
        Me.z2a4.UseVisualStyleBackColor = True
        '
        'z2a3
        '
        Me.z2a3.AutoSize = True
        Me.z2a3.Location = New System.Drawing.Point(106, 74)
        Me.z2a3.Name = "z2a3"
        Me.z2a3.Size = New System.Drawing.Size(15, 14)
        Me.z2a3.TabIndex = 22
        Me.z2a3.UseVisualStyleBackColor = True
        '
        'z2a2
        '
        Me.z2a2.AutoSize = True
        Me.z2a2.Location = New System.Drawing.Point(85, 74)
        Me.z2a2.Name = "z2a2"
        Me.z2a2.Size = New System.Drawing.Size(15, 14)
        Me.z2a2.TabIndex = 21
        Me.z2a2.UseVisualStyleBackColor = True
        '
        'z2a1
        '
        Me.z2a1.AutoSize = True
        Me.z2a1.Location = New System.Drawing.Point(64, 74)
        Me.z2a1.Name = "z2a1"
        Me.z2a1.Size = New System.Drawing.Size(15, 14)
        Me.z2a1.TabIndex = 20
        Me.z2a1.UseVisualStyleBackColor = True
        '
        'z1a4
        '
        Me.z1a4.AutoSize = True
        Me.z1a4.Location = New System.Drawing.Point(127, 55)
        Me.z1a4.Name = "z1a4"
        Me.z1a4.Size = New System.Drawing.Size(15, 14)
        Me.z1a4.TabIndex = 19
        Me.z1a4.UseVisualStyleBackColor = True
        '
        'z1a3
        '
        Me.z1a3.AutoSize = True
        Me.z1a3.Location = New System.Drawing.Point(106, 55)
        Me.z1a3.Name = "z1a3"
        Me.z1a3.Size = New System.Drawing.Size(15, 14)
        Me.z1a3.TabIndex = 18
        Me.z1a3.UseVisualStyleBackColor = True
        '
        'z1a2
        '
        Me.z1a2.AutoSize = True
        Me.z1a2.Location = New System.Drawing.Point(85, 55)
        Me.z1a2.Name = "z1a2"
        Me.z1a2.Size = New System.Drawing.Size(15, 14)
        Me.z1a2.TabIndex = 17
        Me.z1a2.UseVisualStyleBackColor = True
        '
        'Label84
        '
        Me.Label84.AutoSize = True
        Me.Label84.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label84.Location = New System.Drawing.Point(63, 16)
        Me.Label84.Name = "Label84"
        Me.Label84.Size = New System.Drawing.Size(78, 13)
        Me.Label84.TabIndex = 16
        Me.Label84.Text = "Agent Loops"
        '
        'Label83
        '
        Me.Label83.AutoSize = True
        Me.Label83.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label83.Location = New System.Drawing.Point(6, 16)
        Me.Label83.Name = "Label83"
        Me.Label83.Size = New System.Drawing.Size(36, 13)
        Me.Label83.TabIndex = 15
        Me.Label83.Text = "Zone"
        '
        'z1a1
        '
        Me.z1a1.AutoSize = True
        Me.z1a1.Location = New System.Drawing.Point(64, 55)
        Me.z1a1.Name = "z1a1"
        Me.z1a1.Size = New System.Drawing.Size(15, 14)
        Me.z1a1.TabIndex = 14
        Me.z1a1.UseVisualStyleBackColor = True
        '
        'Label81
        '
        Me.Label81.AutoSize = True
        Me.Label81.Location = New System.Drawing.Point(127, 37)
        Me.Label81.Name = "Label81"
        Me.Label81.Size = New System.Drawing.Size(13, 13)
        Me.Label81.TabIndex = 13
        Me.Label81.Text = "4"
        '
        'Label82
        '
        Me.Label82.AutoSize = True
        Me.Label82.Location = New System.Drawing.Point(106, 37)
        Me.Label82.Name = "Label82"
        Me.Label82.Size = New System.Drawing.Size(13, 13)
        Me.Label82.TabIndex = 12
        Me.Label82.Text = "3"
        '
        'Label80
        '
        Me.Label80.AutoSize = True
        Me.Label80.Location = New System.Drawing.Point(85, 37)
        Me.Label80.Name = "Label80"
        Me.Label80.Size = New System.Drawing.Size(13, 13)
        Me.Label80.TabIndex = 11
        Me.Label80.Text = "2"
        '
        'Label79
        '
        Me.Label79.AutoSize = True
        Me.Label79.Location = New System.Drawing.Point(64, 37)
        Me.Label79.Name = "Label79"
        Me.Label79.Size = New System.Drawing.Size(13, 13)
        Me.Label79.TabIndex = 10
        Me.Label79.Text = "1"
        '
        'Label77
        '
        Me.Label77.AutoSize = True
        Me.Label77.Location = New System.Drawing.Point(6, 226)
        Me.Label77.Name = "Label77"
        Me.Label77.Size = New System.Drawing.Size(47, 13)
        Me.Label77.TabIndex = 9
        Me.Label77.Text = "Zone 10"
        '
        'Label78
        '
        Me.Label78.AutoSize = True
        Me.Label78.Location = New System.Drawing.Point(6, 207)
        Me.Label78.Name = "Label78"
        Me.Label78.Size = New System.Drawing.Size(41, 13)
        Me.Label78.TabIndex = 8
        Me.Label78.Text = "Zone 9"
        '
        'Label73
        '
        Me.Label73.AutoSize = True
        Me.Label73.Location = New System.Drawing.Point(6, 188)
        Me.Label73.Name = "Label73"
        Me.Label73.Size = New System.Drawing.Size(41, 13)
        Me.Label73.TabIndex = 7
        Me.Label73.Text = "Zone 8"
        '
        'Label74
        '
        Me.Label74.AutoSize = True
        Me.Label74.Location = New System.Drawing.Point(6, 169)
        Me.Label74.Name = "Label74"
        Me.Label74.Size = New System.Drawing.Size(41, 13)
        Me.Label74.TabIndex = 6
        Me.Label74.Text = "Zone 7"
        '
        'Label75
        '
        Me.Label75.AutoSize = True
        Me.Label75.Location = New System.Drawing.Point(6, 150)
        Me.Label75.Name = "Label75"
        Me.Label75.Size = New System.Drawing.Size(41, 13)
        Me.Label75.TabIndex = 5
        Me.Label75.Text = "Zone 6"
        '
        'Label76
        '
        Me.Label76.AutoSize = True
        Me.Label76.Location = New System.Drawing.Point(6, 131)
        Me.Label76.Name = "Label76"
        Me.Label76.Size = New System.Drawing.Size(41, 13)
        Me.Label76.TabIndex = 4
        Me.Label76.Text = "Zone 5"
        '
        'Label72
        '
        Me.Label72.AutoSize = True
        Me.Label72.Location = New System.Drawing.Point(6, 112)
        Me.Label72.Name = "Label72"
        Me.Label72.Size = New System.Drawing.Size(41, 13)
        Me.Label72.TabIndex = 3
        Me.Label72.Text = "Zone 4"
        '
        'Label71
        '
        Me.Label71.AutoSize = True
        Me.Label71.Location = New System.Drawing.Point(6, 93)
        Me.Label71.Name = "Label71"
        Me.Label71.Size = New System.Drawing.Size(41, 13)
        Me.Label71.TabIndex = 2
        Me.Label71.Text = "Zone 3"
        '
        'Label70
        '
        Me.Label70.AutoSize = True
        Me.Label70.Location = New System.Drawing.Point(6, 74)
        Me.Label70.Name = "Label70"
        Me.Label70.Size = New System.Drawing.Size(41, 13)
        Me.Label70.TabIndex = 1
        Me.Label70.Text = "Zone 2"
        '
        'Label69
        '
        Me.Label69.AutoSize = True
        Me.Label69.Location = New System.Drawing.Point(6, 55)
        Me.Label69.Name = "Label69"
        Me.Label69.Size = New System.Drawing.Size(41, 13)
        Me.Label69.TabIndex = 0
        Me.Label69.Text = "Zone 1"
        '
        'txtAgentCountdown
        '
        Me.txtAgentCountdown.Location = New System.Drawing.Point(15, 75)
        Me.txtAgentCountdown.Name = "txtAgentCountdown"
        Me.txtAgentCountdown.Size = New System.Drawing.Size(115, 20)
        Me.txtAgentCountdown.TabIndex = 6
        '
        'Label67
        '
        Me.Label67.AutoSize = True
        Me.Label67.Location = New System.Drawing.Point(12, 57)
        Me.Label67.Name = "Label67"
        Me.Label67.Size = New System.Drawing.Size(272, 13)
        Me.Label67.TabIndex = 5
        Me.Label67.Text = "Seconds to count down before activating agent release:"
        '
        'btnAgentBehavSave
        '
        Me.btnAgentBehavSave.Location = New System.Drawing.Point(194, 313)
        Me.btnAgentBehavSave.Name = "btnAgentBehavSave"
        Me.btnAgentBehavSave.Size = New System.Drawing.Size(75, 22)
        Me.btnAgentBehavSave.TabIndex = 4
        Me.btnAgentBehavSave.Text = "Save"
        Me.btnAgentBehavSave.UseVisualStyleBackColor = True
        '
        'txtAgentDelay
        '
        Me.txtAgentDelay.Location = New System.Drawing.Point(15, 30)
        Me.txtAgentDelay.Name = "txtAgentDelay"
        Me.txtAgentDelay.Size = New System.Drawing.Size(115, 20)
        Me.txtAgentDelay.TabIndex = 3
        '
        'Label66
        '
        Me.Label66.AutoSize = True
        Me.Label66.Location = New System.Drawing.Point(12, 12)
        Me.Label66.Name = "Label66"
        Me.Label66.Size = New System.Drawing.Size(522, 13)
        Me.Label66.TabIndex = 0
        Me.Label66.Text = "After full alarm (second stage if you have second stage enabled) before agent cou" &
    "ntdown begins, in seconds:" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'TabPage41
        '
        Me.TabPage41.Controls.Add(Me.Label127)
        Me.TabPage41.Controls.Add(Me.GroupBox13)
        Me.TabPage41.Location = New System.Drawing.Point(4, 22)
        Me.TabPage41.Name = "TabPage41"
        Me.TabPage41.Size = New System.Drawing.Size(877, 411)
        Me.TabPage41.TabIndex = 3
        Me.TabPage41.Text = "Abort Switch"
        Me.TabPage41.UseVisualStyleBackColor = True
        '
        'Label127
        '
        Me.Label127.AutoSize = True
        Me.Label127.ForeColor = System.Drawing.Color.Red
        Me.Label127.Location = New System.Drawing.Point(6, 85)
        Me.Label127.Name = "Label127"
        Me.Label127.Size = New System.Drawing.Size(556, 13)
        Me.Label127.TabIndex = 3
        Me.Label127.Text = "It is HIGHLY recommended you enable this abort switch, as it can prevent an accid" &
    "ental (and costly) false discharge."
        '
        'GroupBox13
        '
        Me.GroupBox13.Controls.Add(Me.Label129)
        Me.GroupBox13.Controls.Add(Me.rdoAbortDisabled)
        Me.GroupBox13.Controls.Add(Me.rdoAbortEnabled)
        Me.GroupBox13.Location = New System.Drawing.Point(9, 9)
        Me.GroupBox13.Name = "GroupBox13"
        Me.GroupBox13.Size = New System.Drawing.Size(269, 64)
        Me.GroupBox13.TabIndex = 2
        Me.GroupBox13.TabStop = False
        Me.GroupBox13.Text = "Enable Agent Abort Switch"
        '
        'Label129
        '
        Me.Label129.Location = New System.Drawing.Point(154, 16)
        Me.Label129.Name = "Label129"
        Me.Label129.Size = New System.Drawing.Size(110, 45)
        Me.Label129.TabIndex = 2
        Me.Label129.Text = "The ability to abort an agent release which is counting down"
        '
        'rdoAbortDisabled
        '
        Me.rdoAbortDisabled.AutoSize = True
        Me.rdoAbortDisabled.Location = New System.Drawing.Point(80, 28)
        Me.rdoAbortDisabled.Name = "rdoAbortDisabled"
        Me.rdoAbortDisabled.Size = New System.Drawing.Size(66, 17)
        Me.rdoAbortDisabled.TabIndex = 1
        Me.rdoAbortDisabled.TabStop = True
        Me.rdoAbortDisabled.Text = "Disabled"
        Me.rdoAbortDisabled.UseVisualStyleBackColor = True
        '
        'rdoAbortEnabled
        '
        Me.rdoAbortEnabled.AutoSize = True
        Me.rdoAbortEnabled.Location = New System.Drawing.Point(10, 28)
        Me.rdoAbortEnabled.Name = "rdoAbortEnabled"
        Me.rdoAbortEnabled.Size = New System.Drawing.Size(64, 17)
        Me.rdoAbortEnabled.TabIndex = 0
        Me.rdoAbortEnabled.TabStop = True
        Me.rdoAbortEnabled.Text = "Enabled"
        Me.rdoAbortEnabled.UseVisualStyleBackColor = True
        '
        'TabPage14
        '
        Me.TabPage14.Controls.Add(Me.btnSysModelNumberSave)
        Me.TabPage14.Controls.Add(Me.cbbSysModelNumber)
        Me.TabPage14.Controls.Add(Me.Label1)
        Me.TabPage14.Location = New System.Drawing.Point(4, 22)
        Me.TabPage14.Name = "TabPage14"
        Me.TabPage14.Size = New System.Drawing.Size(885, 437)
        Me.TabPage14.TabIndex = 4
        Me.TabPage14.Text = "System Model"
        Me.TabPage14.UseVisualStyleBackColor = True
        '
        'btnSysModelNumberSave
        '
        Me.btnSysModelNumberSave.Location = New System.Drawing.Point(10, 52)
        Me.btnSysModelNumberSave.Name = "btnSysModelNumberSave"
        Me.btnSysModelNumberSave.Size = New System.Drawing.Size(75, 23)
        Me.btnSysModelNumberSave.TabIndex = 2
        Me.btnSysModelNumberSave.Text = "Save"
        Me.btnSysModelNumberSave.UseVisualStyleBackColor = True
        '
        'cbbSysModelNumber
        '
        Me.cbbSysModelNumber.AutoCompleteCustomSource.AddRange(New String() {"SYGMAH PowerMarshall PM-9", "SYGMAH PowerMarshall PM-10", "SYGMAH PowerMarshall PM-10RT", "PowerMarshall 9 Compatible", "PowerMarshall 10/10RT Compatible"})
        Me.cbbSysModelNumber.FormattingEnabled = True
        Me.cbbSysModelNumber.Items.AddRange(New Object() {"SYGMAH PowerMarshall PM-9", "SYGMAH PowerMarshall PM-10", "SYGMAH PowerMarshall PM-10RT", "PowerMarshall 9 Compatible", "PowerMarshall 10/10RT Compatible"})
        Me.cbbSysModelNumber.Location = New System.Drawing.Point(10, 25)
        Me.cbbSysModelNumber.Name = "cbbSysModelNumber"
        Me.cbbSysModelNumber.Size = New System.Drawing.Size(866, 21)
        Me.cbbSysModelNumber.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(7, 7)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(191, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Specify the control unit's model number"
        '
        'TabPage25
        '
        Me.TabPage25.Controls.Add(Me.TabControl7)
        Me.TabPage25.Location = New System.Drawing.Point(4, 22)
        Me.TabPage25.Name = "TabPage25"
        Me.TabPage25.Size = New System.Drawing.Size(893, 463)
        Me.TabPage25.TabIndex = 4
        Me.TabPage25.Text = "System Extender"
        Me.TabPage25.UseVisualStyleBackColor = True
        '
        'TabControl7
        '
        Me.TabControl7.Controls.Add(Me.TabPage28)
        Me.TabControl7.Controls.Add(Me.TabPage29)
        Me.TabControl7.Controls.Add(Me.TabPage30)
        Me.TabControl7.Controls.Add(Me.TabPage31)
        Me.TabControl7.Controls.Add(Me.TabPage32)
        Me.TabControl7.Controls.Add(Me.TabPage33)
        Me.TabControl7.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl7.Location = New System.Drawing.Point(0, 0)
        Me.TabControl7.Name = "TabControl7"
        Me.TabControl7.SelectedIndex = 0
        Me.TabControl7.Size = New System.Drawing.Size(893, 463)
        Me.TabControl7.TabIndex = 0
        '
        'TabPage28
        '
        Me.TabPage28.Controls.Add(Me.RichTextBox1)
        Me.TabPage28.Controls.Add(Me.Label16)
        Me.TabPage28.Location = New System.Drawing.Point(4, 22)
        Me.TabPage28.Name = "TabPage28"
        Me.TabPage28.Size = New System.Drawing.Size(885, 437)
        Me.TabPage28.TabIndex = 0
        Me.TabPage28.Text = "About"
        Me.TabPage28.UseVisualStyleBackColor = True
        '
        'RichTextBox1
        '
        Me.RichTextBox1.BackColor = System.Drawing.Color.White
        Me.RichTextBox1.Location = New System.Drawing.Point(11, 159)
        Me.RichTextBox1.Name = "RichTextBox1"
        Me.RichTextBox1.ReadOnly = True
        Me.RichTextBox1.Size = New System.Drawing.Size(863, 265)
        Me.RichTextBox1.TabIndex = 1
        Me.RichTextBox1.Text = resources.GetString("RichTextBox1.Text")
        '
        'Label16
        '
        Me.Label16.Location = New System.Drawing.Point(8, 8)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(873, 148)
        Me.Label16.TabIndex = 0
        Me.Label16.Text = resources.GetString("Label16.Text")
        '
        'TabPage29
        '
        Me.TabPage29.Controls.Add(Me.GroupBox2)
        Me.TabPage29.Location = New System.Drawing.Point(4, 22)
        Me.TabPage29.Name = "TabPage29"
        Me.TabPage29.Size = New System.Drawing.Size(885, 437)
        Me.TabPage29.TabIndex = 1
        Me.TabPage29.Text = "Setup"
        Me.TabPage29.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Label17)
        Me.GroupBox2.Controls.Add(Me.rdoSysExtEnabled)
        Me.GroupBox2.Controls.Add(Me.rdoSysExtDisabled)
        Me.GroupBox2.Location = New System.Drawing.Point(7, 7)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(874, 65)
        Me.GroupBox2.TabIndex = 0
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Enable System Extender"
        '
        'Label17
        '
        Me.Label17.ForeColor = System.Drawing.Color.Red
        Me.Label17.Location = New System.Drawing.Point(151, 24)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(717, 34)
        Me.Label17.TabIndex = 2
        Me.Label17.Text = resources.GetString("Label17.Text")
        '
        'rdoSysExtEnabled
        '
        Me.rdoSysExtEnabled.AutoSize = True
        Me.rdoSysExtEnabled.Location = New System.Drawing.Point(82, 28)
        Me.rdoSysExtEnabled.Name = "rdoSysExtEnabled"
        Me.rdoSysExtEnabled.Size = New System.Drawing.Size(64, 17)
        Me.rdoSysExtEnabled.TabIndex = 1
        Me.rdoSysExtEnabled.TabStop = True
        Me.rdoSysExtEnabled.Text = "Enabled"
        Me.rdoSysExtEnabled.UseVisualStyleBackColor = True
        '
        'rdoSysExtDisabled
        '
        Me.rdoSysExtDisabled.AutoSize = True
        Me.rdoSysExtDisabled.Location = New System.Drawing.Point(10, 28)
        Me.rdoSysExtDisabled.Name = "rdoSysExtDisabled"
        Me.rdoSysExtDisabled.Size = New System.Drawing.Size(66, 17)
        Me.rdoSysExtDisabled.TabIndex = 0
        Me.rdoSysExtDisabled.TabStop = True
        Me.rdoSysExtDisabled.Text = "Disabled"
        Me.rdoSysExtDisabled.UseVisualStyleBackColor = True
        '
        'TabPage30
        '
        Me.TabPage30.Controls.Add(Me.SEzone14bypass)
        Me.TabPage30.Controls.Add(Me.SEzone13bypass)
        Me.TabPage30.Controls.Add(Me.SEzone12bypass)
        Me.TabPage30.Controls.Add(Me.SEzone11bypass)
        Me.TabPage30.Controls.Add(Me.txtHZone12Name)
        Me.TabPage30.Controls.Add(Me.Label23)
        Me.TabPage30.Controls.Add(Me.txtHZone11Name)
        Me.TabPage30.Controls.Add(Me.Label24)
        Me.TabPage30.Controls.Add(Me.Label25)
        Me.TabPage30.Controls.Add(Me.btnZone1xSave)
        Me.TabPage30.Controls.Add(Me.txtZone14Name)
        Me.TabPage30.Controls.Add(Me.Label22)
        Me.TabPage30.Controls.Add(Me.txtZone13Name)
        Me.TabPage30.Controls.Add(Me.Label21)
        Me.TabPage30.Controls.Add(Me.txtZone12Name)
        Me.TabPage30.Controls.Add(Me.Label20)
        Me.TabPage30.Controls.Add(Me.txtZone11Name)
        Me.TabPage30.Controls.Add(Me.Label19)
        Me.TabPage30.Controls.Add(Me.Label18)
        Me.TabPage30.Location = New System.Drawing.Point(4, 22)
        Me.TabPage30.Name = "TabPage30"
        Me.TabPage30.Size = New System.Drawing.Size(885, 437)
        Me.TabPage30.TabIndex = 2
        Me.TabPage30.Text = "Extender 1"
        Me.TabPage30.UseVisualStyleBackColor = True
        '
        'SEzone14bypass
        '
        Me.SEzone14bypass.AutoSize = True
        Me.SEzone14bypass.Location = New System.Drawing.Point(341, 108)
        Me.SEzone14bypass.Name = "SEzone14bypass"
        Me.SEzone14bypass.Size = New System.Drawing.Size(100, 17)
        Me.SEzone14bypass.TabIndex = 18
        Me.SEzone14bypass.Text = "Bypass Stage 1"
        Me.SEzone14bypass.UseVisualStyleBackColor = True
        '
        'SEzone13bypass
        '
        Me.SEzone13bypass.AutoSize = True
        Me.SEzone13bypass.Location = New System.Drawing.Point(341, 82)
        Me.SEzone13bypass.Name = "SEzone13bypass"
        Me.SEzone13bypass.Size = New System.Drawing.Size(100, 17)
        Me.SEzone13bypass.TabIndex = 17
        Me.SEzone13bypass.Text = "Bypass Stage 1"
        Me.SEzone13bypass.UseVisualStyleBackColor = True
        '
        'SEzone12bypass
        '
        Me.SEzone12bypass.AutoSize = True
        Me.SEzone12bypass.Location = New System.Drawing.Point(341, 56)
        Me.SEzone12bypass.Name = "SEzone12bypass"
        Me.SEzone12bypass.Size = New System.Drawing.Size(100, 17)
        Me.SEzone12bypass.TabIndex = 16
        Me.SEzone12bypass.Text = "Bypass Stage 1"
        Me.SEzone12bypass.UseVisualStyleBackColor = True
        '
        'SEzone11bypass
        '
        Me.SEzone11bypass.AutoSize = True
        Me.SEzone11bypass.Location = New System.Drawing.Point(341, 30)
        Me.SEzone11bypass.Name = "SEzone11bypass"
        Me.SEzone11bypass.Size = New System.Drawing.Size(100, 17)
        Me.SEzone11bypass.TabIndex = 15
        Me.SEzone11bypass.Text = "Bypass Stage 1"
        Me.SEzone11bypass.UseVisualStyleBackColor = True
        '
        'txtHZone12Name
        '
        Me.txtHZone12Name.Location = New System.Drawing.Point(64, 183)
        Me.txtHZone12Name.Name = "txtHZone12Name"
        Me.txtHZone12Name.Size = New System.Drawing.Size(271, 20)
        Me.txtHZone12Name.TabIndex = 14
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(8, 186)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(50, 13)
        Me.Label23.TabIndex = 13
        Me.Label23.Text = "Zone 1-2"
        '
        'txtHZone11Name
        '
        Me.txtHZone11Name.Location = New System.Drawing.Point(64, 157)
        Me.txtHZone11Name.Name = "txtHZone11Name"
        Me.txtHZone11Name.Size = New System.Drawing.Size(271, 20)
        Me.txtHZone11Name.TabIndex = 12
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(8, 160)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(50, 13)
        Me.Label24.TabIndex = 11
        Me.Label24.Text = "Zone 1-1"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(8, 138)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(122, 13)
        Me.Label25.TabIndex = 10
        Me.Label25.Text = "Configure Hazard Zones"
        '
        'btnZone1xSave
        '
        Me.btnZone1xSave.Location = New System.Drawing.Point(260, 209)
        Me.btnZone1xSave.Name = "btnZone1xSave"
        Me.btnZone1xSave.Size = New System.Drawing.Size(75, 23)
        Me.btnZone1xSave.TabIndex = 9
        Me.btnZone1xSave.Text = "Save"
        Me.btnZone1xSave.UseVisualStyleBackColor = True
        '
        'txtZone14Name
        '
        Me.txtZone14Name.Location = New System.Drawing.Point(64, 105)
        Me.txtZone14Name.Name = "txtZone14Name"
        Me.txtZone14Name.Size = New System.Drawing.Size(271, 20)
        Me.txtZone14Name.TabIndex = 8
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(8, 108)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(50, 13)
        Me.Label22.TabIndex = 7
        Me.Label22.Text = "Zone 1-4"
        '
        'txtZone13Name
        '
        Me.txtZone13Name.Location = New System.Drawing.Point(64, 79)
        Me.txtZone13Name.Name = "txtZone13Name"
        Me.txtZone13Name.Size = New System.Drawing.Size(271, 20)
        Me.txtZone13Name.TabIndex = 6
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(8, 82)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(50, 13)
        Me.Label21.TabIndex = 5
        Me.Label21.Text = "Zone 1-3"
        '
        'txtZone12Name
        '
        Me.txtZone12Name.Location = New System.Drawing.Point(64, 53)
        Me.txtZone12Name.Name = "txtZone12Name"
        Me.txtZone12Name.Size = New System.Drawing.Size(271, 20)
        Me.txtZone12Name.TabIndex = 4
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(8, 56)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(50, 13)
        Me.Label20.TabIndex = 3
        Me.Label20.Text = "Zone 1-2"
        '
        'txtZone11Name
        '
        Me.txtZone11Name.Location = New System.Drawing.Point(64, 27)
        Me.txtZone11Name.Name = "txtZone11Name"
        Me.txtZone11Name.Size = New System.Drawing.Size(271, 20)
        Me.txtZone11Name.TabIndex = 2
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(8, 30)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(50, 13)
        Me.Label19.TabIndex = 1
        Me.Label19.Text = "Zone 1-1"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(8, 8)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(105, 13)
        Me.Label18.TabIndex = 0
        Me.Label18.Text = "Configure Fire Zones"
        '
        'TabPage31
        '
        Me.TabPage31.Controls.Add(Me.SEzone24bypass)
        Me.TabPage31.Controls.Add(Me.SEzone23bypass)
        Me.TabPage31.Controls.Add(Me.SEzone22bypass)
        Me.TabPage31.Controls.Add(Me.SEzone21bypass)
        Me.TabPage31.Controls.Add(Me.txtHZone22Name)
        Me.TabPage31.Controls.Add(Me.Label26)
        Me.TabPage31.Controls.Add(Me.txtHZone21Name)
        Me.TabPage31.Controls.Add(Me.Label27)
        Me.TabPage31.Controls.Add(Me.Label28)
        Me.TabPage31.Controls.Add(Me.Button1)
        Me.TabPage31.Controls.Add(Me.txtZone24Name)
        Me.TabPage31.Controls.Add(Me.Label29)
        Me.TabPage31.Controls.Add(Me.txtZone23Name)
        Me.TabPage31.Controls.Add(Me.Label30)
        Me.TabPage31.Controls.Add(Me.txtZone22Name)
        Me.TabPage31.Controls.Add(Me.Label31)
        Me.TabPage31.Controls.Add(Me.txtZone21Name)
        Me.TabPage31.Controls.Add(Me.Label32)
        Me.TabPage31.Controls.Add(Me.Label33)
        Me.TabPage31.Location = New System.Drawing.Point(4, 22)
        Me.TabPage31.Name = "TabPage31"
        Me.TabPage31.Size = New System.Drawing.Size(885, 437)
        Me.TabPage31.TabIndex = 3
        Me.TabPage31.Text = "Extender 2"
        Me.TabPage31.UseVisualStyleBackColor = True
        '
        'SEzone24bypass
        '
        Me.SEzone24bypass.AutoSize = True
        Me.SEzone24bypass.Location = New System.Drawing.Point(341, 108)
        Me.SEzone24bypass.Name = "SEzone24bypass"
        Me.SEzone24bypass.Size = New System.Drawing.Size(100, 17)
        Me.SEzone24bypass.TabIndex = 33
        Me.SEzone24bypass.Text = "Bypass Stage 1"
        Me.SEzone24bypass.UseVisualStyleBackColor = True
        '
        'SEzone23bypass
        '
        Me.SEzone23bypass.AutoSize = True
        Me.SEzone23bypass.Location = New System.Drawing.Point(341, 82)
        Me.SEzone23bypass.Name = "SEzone23bypass"
        Me.SEzone23bypass.Size = New System.Drawing.Size(100, 17)
        Me.SEzone23bypass.TabIndex = 32
        Me.SEzone23bypass.Text = "Bypass Stage 1"
        Me.SEzone23bypass.UseVisualStyleBackColor = True
        '
        'SEzone22bypass
        '
        Me.SEzone22bypass.AutoSize = True
        Me.SEzone22bypass.Location = New System.Drawing.Point(341, 56)
        Me.SEzone22bypass.Name = "SEzone22bypass"
        Me.SEzone22bypass.Size = New System.Drawing.Size(100, 17)
        Me.SEzone22bypass.TabIndex = 31
        Me.SEzone22bypass.Text = "Bypass Stage 1"
        Me.SEzone22bypass.UseVisualStyleBackColor = True
        '
        'SEzone21bypass
        '
        Me.SEzone21bypass.AutoSize = True
        Me.SEzone21bypass.Location = New System.Drawing.Point(341, 30)
        Me.SEzone21bypass.Name = "SEzone21bypass"
        Me.SEzone21bypass.Size = New System.Drawing.Size(100, 17)
        Me.SEzone21bypass.TabIndex = 30
        Me.SEzone21bypass.Text = "Bypass Stage 1"
        Me.SEzone21bypass.UseVisualStyleBackColor = True
        '
        'txtHZone22Name
        '
        Me.txtHZone22Name.Location = New System.Drawing.Point(64, 183)
        Me.txtHZone22Name.Name = "txtHZone22Name"
        Me.txtHZone22Name.Size = New System.Drawing.Size(271, 20)
        Me.txtHZone22Name.TabIndex = 29
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(8, 186)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(50, 13)
        Me.Label26.TabIndex = 28
        Me.Label26.Text = "Zone 2-2"
        '
        'txtHZone21Name
        '
        Me.txtHZone21Name.Location = New System.Drawing.Point(64, 157)
        Me.txtHZone21Name.Name = "txtHZone21Name"
        Me.txtHZone21Name.Size = New System.Drawing.Size(271, 20)
        Me.txtHZone21Name.TabIndex = 27
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(8, 160)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(50, 13)
        Me.Label27.TabIndex = 26
        Me.Label27.Text = "Zone 2-1"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(8, 138)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(122, 13)
        Me.Label28.TabIndex = 25
        Me.Label28.Text = "Configure Hazard Zones"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(260, 209)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 24
        Me.Button1.Text = "Save"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'txtZone24Name
        '
        Me.txtZone24Name.Location = New System.Drawing.Point(64, 105)
        Me.txtZone24Name.Name = "txtZone24Name"
        Me.txtZone24Name.Size = New System.Drawing.Size(271, 20)
        Me.txtZone24Name.TabIndex = 23
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(8, 108)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(50, 13)
        Me.Label29.TabIndex = 22
        Me.Label29.Text = "Zone 2-4"
        '
        'txtZone23Name
        '
        Me.txtZone23Name.Location = New System.Drawing.Point(64, 79)
        Me.txtZone23Name.Name = "txtZone23Name"
        Me.txtZone23Name.Size = New System.Drawing.Size(271, 20)
        Me.txtZone23Name.TabIndex = 21
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(8, 82)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(50, 13)
        Me.Label30.TabIndex = 20
        Me.Label30.Text = "Zone 2-3"
        '
        'txtZone22Name
        '
        Me.txtZone22Name.Location = New System.Drawing.Point(64, 53)
        Me.txtZone22Name.Name = "txtZone22Name"
        Me.txtZone22Name.Size = New System.Drawing.Size(271, 20)
        Me.txtZone22Name.TabIndex = 19
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Location = New System.Drawing.Point(8, 56)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(50, 13)
        Me.Label31.TabIndex = 18
        Me.Label31.Text = "Zone 2-2"
        '
        'txtZone21Name
        '
        Me.txtZone21Name.Location = New System.Drawing.Point(64, 27)
        Me.txtZone21Name.Name = "txtZone21Name"
        Me.txtZone21Name.Size = New System.Drawing.Size(271, 20)
        Me.txtZone21Name.TabIndex = 17
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Location = New System.Drawing.Point(8, 30)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(50, 13)
        Me.Label32.TabIndex = 16
        Me.Label32.Text = "Zone 2-1"
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Location = New System.Drawing.Point(8, 8)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(105, 13)
        Me.Label33.TabIndex = 15
        Me.Label33.Text = "Configure Fire Zones"
        '
        'TabPage32
        '
        Me.TabPage32.Controls.Add(Me.Label34)
        Me.TabPage32.Location = New System.Drawing.Point(4, 22)
        Me.TabPage32.Name = "TabPage32"
        Me.TabPage32.Size = New System.Drawing.Size(885, 437)
        Me.TabPage32.TabIndex = 4
        Me.TabPage32.Text = "Extender 3"
        Me.TabPage32.UseVisualStyleBackColor = True
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Location = New System.Drawing.Point(7, 7)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(95, 13)
        Me.Label34.TabIndex = 0
        Me.Label34.Text = "Not Yet Supported"
        '
        'TabPage33
        '
        Me.TabPage33.Controls.Add(Me.Label35)
        Me.TabPage33.Location = New System.Drawing.Point(4, 22)
        Me.TabPage33.Name = "TabPage33"
        Me.TabPage33.Size = New System.Drawing.Size(885, 437)
        Me.TabPage33.TabIndex = 5
        Me.TabPage33.Text = "Extender 4"
        Me.TabPage33.UseVisualStyleBackColor = True
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Location = New System.Drawing.Point(7, 7)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(95, 13)
        Me.Label35.TabIndex = 1
        Me.Label35.Text = "Not Yet Supported"
        '
        'TabPage5
        '
        Me.TabPage5.Controls.Add(Me.TabControl3)
        Me.TabPage5.Location = New System.Drawing.Point(4, 22)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Size = New System.Drawing.Size(893, 463)
        Me.TabPage5.TabIndex = 2
        Me.TabPage5.Text = "Security"
        Me.TabPage5.UseVisualStyleBackColor = True
        '
        'TabControl3
        '
        Me.TabControl3.Controls.Add(Me.TabPage7)
        Me.TabControl3.Controls.Add(Me.TabPage8)
        Me.TabControl3.Controls.Add(Me.TabPage9)
        Me.TabControl3.Controls.Add(Me.TabPage6)
        Me.TabControl3.Controls.Add(Me.TabPage36)
        Me.TabControl3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl3.Location = New System.Drawing.Point(0, 0)
        Me.TabControl3.Name = "TabControl3"
        Me.TabControl3.SelectedIndex = 0
        Me.TabControl3.Size = New System.Drawing.Size(893, 463)
        Me.TabControl3.TabIndex = 0
        '
        'TabPage7
        '
        Me.TabPage7.Controls.Add(Me.btnLockCodeRemoved)
        Me.TabPage7.Controls.Add(Me.btnPWsave)
        Me.TabPage7.Controls.Add(Me.Label132)
        Me.TabPage7.Controls.Add(Me.Label131)
        Me.TabPage7.Controls.Add(Me.txtPWset2)
        Me.TabPage7.Controls.Add(Me.Label130)
        Me.TabPage7.Controls.Add(Me.txtPWset1)
        Me.TabPage7.Location = New System.Drawing.Point(4, 22)
        Me.TabPage7.Name = "TabPage7"
        Me.TabPage7.Size = New System.Drawing.Size(885, 437)
        Me.TabPage7.TabIndex = 0
        Me.TabPage7.Text = "Control Lockout Code"
        Me.TabPage7.UseVisualStyleBackColor = True
        '
        'btnLockCodeRemoved
        '
        Me.btnLockCodeRemoved.Location = New System.Drawing.Point(166, 80)
        Me.btnLockCodeRemoved.Name = "btnLockCodeRemoved"
        Me.btnLockCodeRemoved.Size = New System.Drawing.Size(117, 23)
        Me.btnLockCodeRemoved.TabIndex = 6
        Me.btnLockCodeRemoved.Text = "Remove Existing"
        Me.btnLockCodeRemoved.UseVisualStyleBackColor = True
        '
        'btnPWsave
        '
        Me.btnPWsave.Location = New System.Drawing.Point(289, 80)
        Me.btnPWsave.Name = "btnPWsave"
        Me.btnPWsave.Size = New System.Drawing.Size(75, 23)
        Me.btnPWsave.TabIndex = 5
        Me.btnPWsave.Text = "Save"
        Me.btnPWsave.UseVisualStyleBackColor = True
        '
        'Label132
        '
        Me.Label132.AutoSize = True
        Me.Label132.Location = New System.Drawing.Point(8, 57)
        Me.Label132.Name = "Label132"
        Me.Label132.Size = New System.Drawing.Size(90, 13)
        Me.Label132.TabIndex = 4
        Me.Label132.Text = "Confirm password"
        '
        'Label131
        '
        Me.Label131.AutoSize = True
        Me.Label131.Location = New System.Drawing.Point(8, 31)
        Me.Label131.Name = "Label131"
        Me.Label131.Size = New System.Drawing.Size(77, 13)
        Me.Label131.TabIndex = 3
        Me.Label131.Text = "New password"
        '
        'txtPWset2
        '
        Me.txtPWset2.Location = New System.Drawing.Point(100, 54)
        Me.txtPWset2.Name = "txtPWset2"
        Me.txtPWset2.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtPWset2.Size = New System.Drawing.Size(264, 20)
        Me.txtPWset2.TabIndex = 2
        '
        'Label130
        '
        Me.Label130.AutoSize = True
        Me.Label130.Location = New System.Drawing.Point(8, 8)
        Me.Label130.Name = "Label130"
        Me.Label130.Size = New System.Drawing.Size(584, 13)
        Me.Label130.TabIndex = 1
        Me.Label130.Text = "Set the lockout code for the PowerCommander virtual control panel. This prevents " &
    "unauthorized access to system controls."
        '
        'txtPWset1
        '
        Me.txtPWset1.Location = New System.Drawing.Point(100, 28)
        Me.txtPWset1.Name = "txtPWset1"
        Me.txtPWset1.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtPWset1.Size = New System.Drawing.Size(264, 20)
        Me.txtPWset1.TabIndex = 0
        '
        'TabPage8
        '
        Me.TabPage8.Controls.Add(Me.Label133)
        Me.TabPage8.Location = New System.Drawing.Point(4, 22)
        Me.TabPage8.Name = "TabPage8"
        Me.TabPage8.Size = New System.Drawing.Size(885, 437)
        Me.TabPage8.TabIndex = 1
        Me.TabPage8.Text = "Automatic Lockout"
        Me.TabPage8.UseVisualStyleBackColor = True
        '
        'Label133
        '
        Me.Label133.AutoSize = True
        Me.Label133.Location = New System.Drawing.Point(10, 8)
        Me.Label133.Name = "Label133"
        Me.Label133.Size = New System.Drawing.Size(48, 13)
        Me.Label133.TabIndex = 0
        Me.Label133.Text = "Defunct."
        '
        'TabPage9
        '
        Me.TabPage9.Controls.Add(Me.Label135)
        Me.TabPage9.Controls.Add(Me.GroupBox14)
        Me.TabPage9.Controls.Add(Me.Label134)
        Me.TabPage9.Location = New System.Drawing.Point(4, 22)
        Me.TabPage9.Name = "TabPage9"
        Me.TabPage9.Size = New System.Drawing.Size(885, 437)
        Me.TabPage9.TabIndex = 2
        Me.TabPage9.Text = "Disable PowerCommander Quit"
        Me.TabPage9.UseVisualStyleBackColor = True
        '
        'Label135
        '
        Me.Label135.ForeColor = System.Drawing.Color.Red
        Me.Label135.Location = New System.Drawing.Point(10, 112)
        Me.Label135.Name = "Label135"
        Me.Label135.Size = New System.Drawing.Size(442, 51)
        Me.Label135.TabIndex = 5
        Me.Label135.Text = resources.GetString("Label135.Text")
        '
        'GroupBox14
        '
        Me.GroupBox14.Controls.Add(Me.Label136)
        Me.GroupBox14.Controls.Add(Me.rdoQuitDisabled)
        Me.GroupBox14.Controls.Add(Me.rdoQuitEnabled)
        Me.GroupBox14.Location = New System.Drawing.Point(13, 36)
        Me.GroupBox14.Name = "GroupBox14"
        Me.GroupBox14.Size = New System.Drawing.Size(439, 64)
        Me.GroupBox14.TabIndex = 4
        Me.GroupBox14.TabStop = False
        Me.GroupBox14.Text = "Show the quit button in PowerCommander"
        '
        'Label136
        '
        Me.Label136.Location = New System.Drawing.Point(154, 16)
        Me.Label136.Name = "Label136"
        Me.Label136.Size = New System.Drawing.Size(285, 45)
        Me.Label136.TabIndex = 2
        Me.Label136.Text = "When enabled is selected, PowerCommander will offer a quit button. When disabled " &
    "is selected, PowerCommander will disable this option"
        '
        'rdoQuitDisabled
        '
        Me.rdoQuitDisabled.AutoSize = True
        Me.rdoQuitDisabled.Location = New System.Drawing.Point(80, 28)
        Me.rdoQuitDisabled.Name = "rdoQuitDisabled"
        Me.rdoQuitDisabled.Size = New System.Drawing.Size(66, 17)
        Me.rdoQuitDisabled.TabIndex = 1
        Me.rdoQuitDisabled.TabStop = True
        Me.rdoQuitDisabled.Text = "Disabled"
        Me.rdoQuitDisabled.UseVisualStyleBackColor = True
        '
        'rdoQuitEnabled
        '
        Me.rdoQuitEnabled.AutoSize = True
        Me.rdoQuitEnabled.Location = New System.Drawing.Point(10, 28)
        Me.rdoQuitEnabled.Name = "rdoQuitEnabled"
        Me.rdoQuitEnabled.Size = New System.Drawing.Size(64, 17)
        Me.rdoQuitEnabled.TabIndex = 0
        Me.rdoQuitEnabled.TabStop = True
        Me.rdoQuitEnabled.Text = "Enabled"
        Me.rdoQuitEnabled.UseVisualStyleBackColor = True
        '
        'Label134
        '
        Me.Label134.AutoSize = True
        Me.Label134.Location = New System.Drawing.Point(10, 10)
        Me.Label134.Name = "Label134"
        Me.Label134.Size = New System.Drawing.Size(208, 13)
        Me.Label134.TabIndex = 0
        Me.Label134.Text = "Prevent PowerCommander from being quit."
        '
        'TabPage6
        '
        Me.TabPage6.Controls.Add(Me.GroupBox15)
        Me.TabPage6.Location = New System.Drawing.Point(4, 22)
        Me.TabPage6.Name = "TabPage6"
        Me.TabPage6.Size = New System.Drawing.Size(885, 437)
        Me.TabPage6.TabIndex = 3
        Me.TabPage6.Text = "Security Audit Log"
        Me.TabPage6.UseVisualStyleBackColor = True
        '
        'GroupBox15
        '
        Me.GroupBox15.Controls.Add(Me.Label138)
        Me.GroupBox15.Controls.Add(Me.RadioButton1)
        Me.GroupBox15.Controls.Add(Me.RadioButton2)
        Me.GroupBox15.Location = New System.Drawing.Point(8, 8)
        Me.GroupBox15.Name = "GroupBox15"
        Me.GroupBox15.Size = New System.Drawing.Size(269, 64)
        Me.GroupBox15.TabIndex = 2
        Me.GroupBox15.TabStop = False
        Me.GroupBox15.Text = "Enable Audit Logging"
        '
        'Label138
        '
        Me.Label138.Location = New System.Drawing.Point(154, 16)
        Me.Label138.Name = "Label138"
        Me.Label138.Size = New System.Drawing.Size(110, 45)
        Me.Label138.TabIndex = 2
        Me.Label138.Text = "The system will append actions to a logfile if enabled"
        '
        'RadioButton1
        '
        Me.RadioButton1.AutoSize = True
        Me.RadioButton1.Checked = True
        Me.RadioButton1.Enabled = False
        Me.RadioButton1.Location = New System.Drawing.Point(80, 28)
        Me.RadioButton1.Name = "RadioButton1"
        Me.RadioButton1.Size = New System.Drawing.Size(66, 17)
        Me.RadioButton1.TabIndex = 1
        Me.RadioButton1.TabStop = True
        Me.RadioButton1.Text = "Disabled"
        Me.RadioButton1.UseVisualStyleBackColor = True
        '
        'RadioButton2
        '
        Me.RadioButton2.AutoSize = True
        Me.RadioButton2.Enabled = False
        Me.RadioButton2.Location = New System.Drawing.Point(10, 28)
        Me.RadioButton2.Name = "RadioButton2"
        Me.RadioButton2.Size = New System.Drawing.Size(64, 17)
        Me.RadioButton2.TabIndex = 0
        Me.RadioButton2.Text = "Enabled"
        Me.RadioButton2.UseVisualStyleBackColor = True
        '
        'TabPage36
        '
        Me.TabPage36.Controls.Add(Me.btnInfoRemove)
        Me.TabPage36.Controls.Add(Me.btnSaveInfo)
        Me.TabPage36.Controls.Add(Me.txtNotes)
        Me.TabPage36.Controls.Add(Me.Label161)
        Me.TabPage36.Controls.Add(Me.txtDiscord)
        Me.TabPage36.Controls.Add(Me.Label159)
        Me.TabPage36.Controls.Add(Me.txtPhone2)
        Me.TabPage36.Controls.Add(Me.Label160)
        Me.TabPage36.Controls.Add(Me.txtPhone1)
        Me.TabPage36.Controls.Add(Me.Label158)
        Me.TabPage36.Controls.Add(Me.txtEmail)
        Me.TabPage36.Controls.Add(Me.Label157)
        Me.TabPage36.Controls.Add(Me.txtLastName)
        Me.TabPage36.Controls.Add(Me.Label156)
        Me.TabPage36.Controls.Add(Me.txtFirstName)
        Me.TabPage36.Controls.Add(Me.Label155)
        Me.TabPage36.Controls.Add(Me.Label154)
        Me.TabPage36.Location = New System.Drawing.Point(4, 22)
        Me.TabPage36.Name = "TabPage36"
        Me.TabPage36.Size = New System.Drawing.Size(885, 437)
        Me.TabPage36.TabIndex = 4
        Me.TabPage36.Text = "Contact Information"
        Me.TabPage36.UseVisualStyleBackColor = True
        '
        'btnSaveInfo
        '
        Me.btnSaveInfo.Location = New System.Drawing.Point(259, 318)
        Me.btnSaveInfo.Name = "btnSaveInfo"
        Me.btnSaveInfo.Size = New System.Drawing.Size(75, 23)
        Me.btnSaveInfo.TabIndex = 15
        Me.btnSaveInfo.Text = "Save"
        Me.btnSaveInfo.UseVisualStyleBackColor = True
        '
        'txtNotes
        '
        Me.txtNotes.Location = New System.Drawing.Point(71, 189)
        Me.txtNotes.Multiline = True
        Me.txtNotes.Name = "txtNotes"
        Me.txtNotes.Size = New System.Drawing.Size(263, 123)
        Me.txtNotes.TabIndex = 14
        '
        'Label161
        '
        Me.Label161.AutoSize = True
        Me.Label161.Location = New System.Drawing.Point(8, 192)
        Me.Label161.Name = "Label161"
        Me.Label161.Size = New System.Drawing.Size(35, 13)
        Me.Label161.TabIndex = 13
        Me.Label161.Text = "Notes"
        '
        'txtDiscord
        '
        Me.txtDiscord.Location = New System.Drawing.Point(71, 163)
        Me.txtDiscord.Name = "txtDiscord"
        Me.txtDiscord.Size = New System.Drawing.Size(263, 20)
        Me.txtDiscord.TabIndex = 12
        '
        'Label159
        '
        Me.Label159.AutoSize = True
        Me.Label159.Location = New System.Drawing.Point(8, 166)
        Me.Label159.Name = "Label159"
        Me.Label159.Size = New System.Drawing.Size(43, 13)
        Me.Label159.TabIndex = 11
        Me.Label159.Text = "Discord"
        '
        'txtPhone2
        '
        Me.txtPhone2.Location = New System.Drawing.Point(71, 137)
        Me.txtPhone2.Name = "txtPhone2"
        Me.txtPhone2.Size = New System.Drawing.Size(263, 20)
        Me.txtPhone2.TabIndex = 10
        '
        'Label160
        '
        Me.Label160.AutoSize = True
        Me.Label160.Location = New System.Drawing.Point(8, 140)
        Me.Label160.Name = "Label160"
        Me.Label160.Size = New System.Drawing.Size(47, 13)
        Me.Label160.TabIndex = 9
        Me.Label160.Text = "Phone 2"
        '
        'txtPhone1
        '
        Me.txtPhone1.Location = New System.Drawing.Point(71, 111)
        Me.txtPhone1.Name = "txtPhone1"
        Me.txtPhone1.Size = New System.Drawing.Size(263, 20)
        Me.txtPhone1.TabIndex = 8
        '
        'Label158
        '
        Me.Label158.AutoSize = True
        Me.Label158.Location = New System.Drawing.Point(8, 114)
        Me.Label158.Name = "Label158"
        Me.Label158.Size = New System.Drawing.Size(47, 13)
        Me.Label158.TabIndex = 7
        Me.Label158.Text = "Phone 1"
        '
        'txtEmail
        '
        Me.txtEmail.Location = New System.Drawing.Point(71, 85)
        Me.txtEmail.Name = "txtEmail"
        Me.txtEmail.Size = New System.Drawing.Size(263, 20)
        Me.txtEmail.TabIndex = 6
        '
        'Label157
        '
        Me.Label157.AutoSize = True
        Me.Label157.Location = New System.Drawing.Point(8, 88)
        Me.Label157.Name = "Label157"
        Me.Label157.Size = New System.Drawing.Size(32, 13)
        Me.Label157.TabIndex = 5
        Me.Label157.Text = "Email"
        '
        'txtLastName
        '
        Me.txtLastName.Location = New System.Drawing.Point(71, 59)
        Me.txtLastName.Name = "txtLastName"
        Me.txtLastName.Size = New System.Drawing.Size(263, 20)
        Me.txtLastName.TabIndex = 4
        '
        'Label156
        '
        Me.Label156.AutoSize = True
        Me.Label156.Location = New System.Drawing.Point(8, 62)
        Me.Label156.Name = "Label156"
        Me.Label156.Size = New System.Drawing.Size(58, 13)
        Me.Label156.TabIndex = 3
        Me.Label156.Text = "Last Name"
        '
        'txtFirstName
        '
        Me.txtFirstName.Location = New System.Drawing.Point(71, 33)
        Me.txtFirstName.Name = "txtFirstName"
        Me.txtFirstName.Size = New System.Drawing.Size(263, 20)
        Me.txtFirstName.TabIndex = 2
        '
        'Label155
        '
        Me.Label155.AutoSize = True
        Me.Label155.Location = New System.Drawing.Point(8, 36)
        Me.Label155.Name = "Label155"
        Me.Label155.Size = New System.Drawing.Size(57, 13)
        Me.Label155.TabIndex = 1
        Me.Label155.Text = "First Name"
        '
        'Label154
        '
        Me.Label154.AutoSize = True
        Me.Label154.Location = New System.Drawing.Point(8, 8)
        Me.Label154.Name = "Label154"
        Me.Label154.Size = New System.Drawing.Size(271, 13)
        Me.Label154.TabIndex = 0
        Me.Label154.Text = "Set information to help people contact you if the need to"
        '
        'TabPage15
        '
        Me.TabPage15.Controls.Add(Me.debugPanel)
        Me.TabPage15.Controls.Add(Me.btnDebugShowSettings)
        Me.TabPage15.Controls.Add(Me.Label5)
        Me.TabPage15.Location = New System.Drawing.Point(4, 22)
        Me.TabPage15.Name = "TabPage15"
        Me.TabPage15.Size = New System.Drawing.Size(893, 463)
        Me.TabPage15.TabIndex = 3
        Me.TabPage15.Text = "Debug (Advanced)"
        Me.TabPage15.UseVisualStyleBackColor = True
        '
        'debugPanel
        '
        Me.debugPanel.Controls.Add(Me.Label152)
        Me.debugPanel.Controls.Add(Me.btnLampTest)
        Me.debugPanel.Controls.Add(Me.Label153)
        Me.debugPanel.Controls.Add(Me.Label151)
        Me.debugPanel.Controls.Add(Me.btnSailorMode)
        Me.debugPanel.Controls.Add(Me.Label150)
        Me.debugPanel.Controls.Add(Me.Label139)
        Me.debugPanel.Controls.Add(Me.fqLbl)
        Me.debugPanel.Controls.Add(Me.btnForceQuitDone)
        Me.debugPanel.Controls.Add(Me.txtForceQuitBox)
        Me.debugPanel.Controls.Add(Me.btnForceQuit)
        Me.debugPanel.Controls.Add(Me.Label137)
        Me.debugPanel.Controls.Add(Me.btnSetDefaultConfigs)
        Me.debugPanel.Controls.Add(Me.Label7)
        Me.debugPanel.Controls.Add(Me.btnSettingsReset)
        Me.debugPanel.Controls.Add(Me.Label6)
        Me.debugPanel.Location = New System.Drawing.Point(11, 55)
        Me.debugPanel.Name = "debugPanel"
        Me.debugPanel.Size = New System.Drawing.Size(874, 393)
        Me.debugPanel.TabIndex = 2
        Me.debugPanel.Visible = False
        '
        'Label152
        '
        Me.Label152.AutoSize = True
        Me.Label152.Location = New System.Drawing.Point(315, 125)
        Me.Label152.Name = "Label152"
        Me.Label152.Size = New System.Drawing.Size(389, 13)
        Me.Label152.TabIndex = 15
        Me.Label152.Text = "PowerCommander will need to be restarted to resynchronize the display elements."
        '
        'btnLampTest
        '
        Me.btnLampTest.Location = New System.Drawing.Point(229, 120)
        Me.btnLampTest.Name = "btnLampTest"
        Me.btnLampTest.Size = New System.Drawing.Size(75, 23)
        Me.btnLampTest.TabIndex = 14
        Me.btnLampTest.Text = "Test"
        Me.btnLampTest.UseVisualStyleBackColor = True
        '
        'Label153
        '
        Me.Label153.AutoSize = True
        Me.Label153.Location = New System.Drawing.Point(13, 125)
        Me.Label153.Name = "Label153"
        Me.Label153.Size = New System.Drawing.Size(115, 13)
        Me.Label153.TabIndex = 13
        Me.Label153.Text = "Control Panel lamp test"
        '
        'Label151
        '
        Me.Label151.AutoSize = True
        Me.Label151.Location = New System.Drawing.Point(315, 96)
        Me.Label151.Name = "Label151"
        Me.Label151.Size = New System.Drawing.Size(236, 13)
        Me.Label151.TabIndex = 12
        Me.Label151.Text = "Changes will last until PowerCommander restarts."
        '
        'btnSailorMode
        '
        Me.btnSailorMode.Enabled = False
        Me.btnSailorMode.Location = New System.Drawing.Point(229, 91)
        Me.btnSailorMode.Name = "btnSailorMode"
        Me.btnSailorMode.Size = New System.Drawing.Size(75, 23)
        Me.btnSailorMode.TabIndex = 11
        Me.btnSailorMode.Text = "Start"
        Me.btnSailorMode.UseVisualStyleBackColor = True
        '
        'Label150
        '
        Me.Label150.AutoSize = True
        Me.Label150.Location = New System.Drawing.Point(13, 96)
        Me.Label150.Name = "Label150"
        Me.Label150.Size = New System.Drawing.Size(62, 13)
        Me.Label150.TabIndex = 10
        Me.Label150.Text = "Sailor mode"
        '
        'Label139
        '
        Me.Label139.AutoSize = True
        Me.Label139.Location = New System.Drawing.Point(315, 39)
        Me.Label139.Name = "Label139"
        Me.Label139.Size = New System.Drawing.Size(301, 13)
        Me.Label139.TabIndex = 9
        Me.Label139.Text = "Obsolete function. Defaults will be set when you reset settings."
        '
        'fqLbl
        '
        Me.fqLbl.AutoSize = True
        Me.fqLbl.Location = New System.Drawing.Point(315, 67)
        Me.fqLbl.Name = "fqLbl"
        Me.fqLbl.Size = New System.Drawing.Size(138, 13)
        Me.fqLbl.TabIndex = 8
        Me.fqLbl.Text = "Enter lock code to continue"
        Me.fqLbl.Visible = False
        '
        'btnForceQuitDone
        '
        Me.btnForceQuitDone.Location = New System.Drawing.Point(687, 62)
        Me.btnForceQuitDone.Name = "btnForceQuitDone"
        Me.btnForceQuitDone.Size = New System.Drawing.Size(75, 23)
        Me.btnForceQuitDone.TabIndex = 7
        Me.btnForceQuitDone.Text = "Done"
        Me.btnForceQuitDone.UseVisualStyleBackColor = True
        Me.btnForceQuitDone.Visible = False
        '
        'txtForceQuitBox
        '
        Me.txtForceQuitBox.Location = New System.Drawing.Point(459, 64)
        Me.txtForceQuitBox.Name = "txtForceQuitBox"
        Me.txtForceQuitBox.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtForceQuitBox.Size = New System.Drawing.Size(222, 20)
        Me.txtForceQuitBox.TabIndex = 6
        Me.txtForceQuitBox.Visible = False
        '
        'btnForceQuit
        '
        Me.btnForceQuit.Location = New System.Drawing.Point(229, 62)
        Me.btnForceQuit.Name = "btnForceQuit"
        Me.btnForceQuit.Size = New System.Drawing.Size(75, 23)
        Me.btnForceQuit.TabIndex = 5
        Me.btnForceQuit.Text = "Quit"
        Me.btnForceQuit.UseVisualStyleBackColor = True
        '
        'Label137
        '
        Me.Label137.AutoSize = True
        Me.Label137.Location = New System.Drawing.Point(13, 67)
        Me.Label137.Name = "Label137"
        Me.Label137.Size = New System.Drawing.Size(158, 13)
        Me.Label137.TabIndex = 4
        Me.Label137.Text = "Quit PowerCommander Override"
        '
        'btnSetDefaultConfigs
        '
        Me.btnSetDefaultConfigs.Enabled = False
        Me.btnSetDefaultConfigs.Location = New System.Drawing.Point(229, 34)
        Me.btnSetDefaultConfigs.Name = "btnSetDefaultConfigs"
        Me.btnSetDefaultConfigs.Size = New System.Drawing.Size(75, 23)
        Me.btnSetDefaultConfigs.TabIndex = 3
        Me.btnSetDefaultConfigs.Text = "Set"
        Me.btnSetDefaultConfigs.UseVisualStyleBackColor = True
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(13, 39)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(162, 13)
        Me.Label7.TabIndex = 2
        Me.Label7.Text = "Set recommended configurations"
        '
        'btnSettingsReset
        '
        Me.btnSettingsReset.Location = New System.Drawing.Point(229, 7)
        Me.btnSettingsReset.Name = "btnSettingsReset"
        Me.btnSettingsReset.Size = New System.Drawing.Size(75, 23)
        Me.btnSettingsReset.TabIndex = 1
        Me.btnSettingsReset.Text = "Reset"
        Me.btnSettingsReset.UseVisualStyleBackColor = True
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(13, 12)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(210, 13)
        Me.Label6.TabIndex = 0
        Me.Label6.Text = "Reset configuration file (My.Settings.Reset)"
        '
        'btnDebugShowSettings
        '
        Me.btnDebugShowSettings.Location = New System.Drawing.Point(11, 26)
        Me.btnDebugShowSettings.Name = "btnDebugShowSettings"
        Me.btnDebugShowSettings.Size = New System.Drawing.Size(214, 23)
        Me.btnDebugShowSettings.TabIndex = 1
        Me.btnDebugShowSettings.Text = "I understand. Show Debug Functions"
        Me.btnDebugShowSettings.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.ForeColor = System.Drawing.Color.Red
        Me.Label5.Location = New System.Drawing.Point(8, 8)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(467, 13)
        Me.Label5.TabIndex = 0
        Me.Label5.Text = "These are advanced functions which may cause problems with your system. Use at yo" &
    "ur own risk."
        '
        'btnInfoRemove
        '
        Me.btnInfoRemove.Location = New System.Drawing.Point(178, 318)
        Me.btnInfoRemove.Name = "btnInfoRemove"
        Me.btnInfoRemove.Size = New System.Drawing.Size(75, 23)
        Me.btnInfoRemove.TabIndex = 16
        Me.btnInfoRemove.Text = "Remove"
        Me.btnInfoRemove.UseVisualStyleBackColor = True
        '
        'Configuration
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.btnDone
        Me.ClientSize = New System.Drawing.Size(901, 539)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Configuration"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "System Configuration"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage3.ResumeLayout(False)
        Me.TabControl2.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        CType(Me.ColorSlider, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage4.ResumeLayout(False)
        Me.TabControl4.ResumeLayout(False)
        Me.TabPage10.ResumeLayout(False)
        Me.TabControl6.ResumeLayout(False)
        Me.TabPage23.ResumeLayout(False)
        Me.TabPage23.PerformLayout()
        Me.TabPage22.ResumeLayout(False)
        Me.TabPage22.PerformLayout()
        Me.TabPage27.ResumeLayout(False)
        Me.TabPage27.PerformLayout()
        Me.TabPage11.ResumeLayout(False)
        Me.TabControl5.ResumeLayout(False)
        Me.TabPage16.ResumeLayout(False)
        Me.TabPage16.PerformLayout()
        Me.TabPage17.ResumeLayout(False)
        Me.TabPage17.PerformLayout()
        Me.grbUnsilence.ResumeLayout(False)
        Me.grbUnsilence.PerformLayout()
        Me.grbSilence.ResumeLayout(False)
        Me.grbSilence.PerformLayout()
        Me.TabPage21.ResumeLayout(False)
        Me.TabPage21.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.TabPage18.ResumeLayout(False)
        Me.TabPage18.PerformLayout()
        Me.TabPage19.ResumeLayout(False)
        Me.TabPage19.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.TabPage20.ResumeLayout(False)
        Me.TabPage20.PerformLayout()
        Me.TabPage12.ResumeLayout(False)
        Me.TabControl8.ResumeLayout(False)
        Me.TabPage34.ResumeLayout(False)
        Me.TabPage34.PerformLayout()
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        Me.TabPage26.ResumeLayout(False)
        Me.TabPage26.PerformLayout()
        Me.TabPage35.ResumeLayout(False)
        Me.TabPage35.PerformLayout()
        Me.TabPage13.ResumeLayout(False)
        Me.TabControl9.ResumeLayout(False)
        Me.TabPage38.ResumeLayout(False)
        Me.TabPage38.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage39.ResumeLayout(False)
        Me.TabPage39.PerformLayout()
        Me.TabPage40.ResumeLayout(False)
        Me.TabPage40.PerformLayout()
        Me.GroupBox12.ResumeLayout(False)
        Me.GroupBox10.ResumeLayout(False)
        Me.GroupBox10.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.GroupBox9.ResumeLayout(False)
        Me.GroupBox9.PerformLayout()
        Me.GroupBox11.ResumeLayout(False)
        Me.GroupBox11.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.GroupBox8.ResumeLayout(False)
        Me.GroupBox8.PerformLayout()
        Me.GroupBox7.ResumeLayout(False)
        Me.GroupBox7.PerformLayout()
        Me.TabPage41.ResumeLayout(False)
        Me.TabPage41.PerformLayout()
        Me.GroupBox13.ResumeLayout(False)
        Me.GroupBox13.PerformLayout()
        Me.TabPage14.ResumeLayout(False)
        Me.TabPage14.PerformLayout()
        Me.TabPage25.ResumeLayout(False)
        Me.TabControl7.ResumeLayout(False)
        Me.TabPage28.ResumeLayout(False)
        Me.TabPage29.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.TabPage30.ResumeLayout(False)
        Me.TabPage30.PerformLayout()
        Me.TabPage31.ResumeLayout(False)
        Me.TabPage31.PerformLayout()
        Me.TabPage32.ResumeLayout(False)
        Me.TabPage32.PerformLayout()
        Me.TabPage33.ResumeLayout(False)
        Me.TabPage33.PerformLayout()
        Me.TabPage5.ResumeLayout(False)
        Me.TabControl3.ResumeLayout(False)
        Me.TabPage7.ResumeLayout(False)
        Me.TabPage7.PerformLayout()
        Me.TabPage8.ResumeLayout(False)
        Me.TabPage8.PerformLayout()
        Me.TabPage9.ResumeLayout(False)
        Me.TabPage9.PerformLayout()
        Me.GroupBox14.ResumeLayout(False)
        Me.GroupBox14.PerformLayout()
        Me.TabPage6.ResumeLayout(False)
        Me.GroupBox15.ResumeLayout(False)
        Me.GroupBox15.PerformLayout()
        Me.TabPage36.ResumeLayout(False)
        Me.TabPage36.PerformLayout()
        Me.TabPage15.ResumeLayout(False)
        Me.TabPage15.PerformLayout()
        Me.debugPanel.ResumeLayout(False)
        Me.debugPanel.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents lblIndSaveStat As Label
    Friend WithEvents btnDone As Button
    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents TabPage3 As TabPage
    Friend WithEvents TabPage4 As TabPage
    Friend WithEvents TabPage5 As TabPage
    Friend WithEvents TabControl2 As TabControl
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents TabControl3 As TabControl
    Friend WithEvents TabPage7 As TabPage
    Friend WithEvents TabPage8 As TabPage
    Friend WithEvents TabPage9 As TabPage
    Friend WithEvents TabControl4 As TabControl
    Friend WithEvents TabPage10 As TabPage
    Friend WithEvents TabPage11 As TabPage
    Friend WithEvents TabPage12 As TabPage
    Friend WithEvents TabPage13 As TabPage
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents Label2 As Label
    Friend WithEvents TabPage6 As TabPage
    Friend WithEvents TabControl5 As TabControl
    Friend WithEvents TabPage16 As TabPage
    Friend WithEvents TabPage17 As TabPage
    Friend WithEvents TabPage18 As TabPage
    Friend WithEvents TabPage19 As TabPage
    Friend WithEvents TabPage20 As TabPage
    Friend WithEvents Label3 As Label
    Friend WithEvents btnFireACDsave As Button
    Friend WithEvents txtFireACDbox As TextBox
    Friend WithEvents TabPage14 As TabPage
    Friend WithEvents Label1 As Label
    Friend WithEvents cbbSysModelNumber As ComboBox
    Friend WithEvents btnSysModelNumberSave As Button
    Friend WithEvents Label4 As Label
    Friend WithEvents TabPage15 As TabPage
    Friend WithEvents Label5 As Label
    Friend WithEvents btnDebugShowSettings As Button
    Friend WithEvents debugPanel As Panel
    Friend WithEvents Label6 As Label
    Friend WithEvents btnSettingsReset As Button
    Friend WithEvents btnSetDefaultConfigs As Button
    Friend WithEvents Label7 As Label
    Friend WithEvents txtSysName As TextBox
    Friend WithEvents btnSysNameSave As Button
    Friend WithEvents Label8 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents grbSilence As GroupBox
    Friend WithEvents grbUnsilence As GroupBox
    Friend WithEvents rdoSilenceDisable As RadioButton
    Friend WithEvents rdoSilenceEnable As RadioButton
    Friend WithEvents rdoUnsilenceDisable As RadioButton
    Friend WithEvents rdoUnsilenceEnable As RadioButton
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents TabPage21 As TabPage
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents rdoAutoSilDisabled As RadioButton
    Friend WithEvents rdoAutoSilEnabled As RadioButton
    Friend WithEvents Label14 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents btnFASSave As Button
    Friend WithEvents txtFireAutoSilDelay As TextBox
    Friend WithEvents TabControl6 As TabControl
    Friend WithEvents TabPage24 As TabPage
    Friend WithEvents TabPage23 As TabPage
    Friend WithEvents TabPage22 As TabPage
    Friend WithEvents Label15 As Label
    Friend WithEvents TabPage25 As TabPage
    Friend WithEvents TabControl7 As TabControl
    Friend WithEvents TabPage28 As TabPage
    Friend WithEvents TabPage29 As TabPage
    Friend WithEvents Label16 As Label
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents rdoSysExtEnabled As RadioButton
    Friend WithEvents rdoSysExtDisabled As RadioButton
    Friend WithEvents Label17 As Label
    Friend WithEvents RichTextBox1 As RichTextBox
    Friend WithEvents TabPage30 As TabPage
    Friend WithEvents TabPage31 As TabPage
    Friend WithEvents TabPage32 As TabPage
    Friend WithEvents TabPage33 As TabPage
    Friend WithEvents Label18 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents txtZone14Name As TextBox
    Friend WithEvents Label22 As Label
    Friend WithEvents txtZone13Name As TextBox
    Friend WithEvents Label21 As Label
    Friend WithEvents txtZone12Name As TextBox
    Friend WithEvents Label20 As Label
    Friend WithEvents txtZone11Name As TextBox
    Friend WithEvents btnZone1xSave As Button
    Friend WithEvents txtHZone12Name As TextBox
    Friend WithEvents Label23 As Label
    Friend WithEvents txtHZone11Name As TextBox
    Friend WithEvents Label24 As Label
    Friend WithEvents Label25 As Label
    Friend WithEvents txtHZone22Name As TextBox
    Friend WithEvents Label26 As Label
    Friend WithEvents txtHZone21Name As TextBox
    Friend WithEvents Label27 As Label
    Friend WithEvents Label28 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents txtZone24Name As TextBox
    Friend WithEvents Label29 As Label
    Friend WithEvents txtZone23Name As TextBox
    Friend WithEvents Label30 As Label
    Friend WithEvents txtZone22Name As TextBox
    Friend WithEvents Label31 As Label
    Friend WithEvents txtZone21Name As TextBox
    Friend WithEvents Label32 As Label
    Friend WithEvents Label33 As Label
    Friend WithEvents Label34 As Label
    Friend WithEvents Label35 As Label
    Friend WithEvents SEzone11bypass As CheckBox
    Friend WithEvents SEzone14bypass As CheckBox
    Friend WithEvents SEzone13bypass As CheckBox
    Friend WithEvents SEzone12bypass As CheckBox
    Friend WithEvents SEzone24bypass As CheckBox
    Friend WithEvents SEzone23bypass As CheckBox
    Friend WithEvents SEzone22bypass As CheckBox
    Friend WithEvents SEzone21bypass As CheckBox
    Friend WithEvents Label36 As Label
    Friend WithEvents Label37 As Label
    Friend WithEvents chkF8bypass As CheckBox
    Friend WithEvents chkF7bypass As CheckBox
    Friend WithEvents chkF6bypass As CheckBox
    Friend WithEvents chkF5bypass As CheckBox
    Friend WithEvents txtF8name As TextBox
    Friend WithEvents Label43 As Label
    Friend WithEvents txtF7name As TextBox
    Friend WithEvents Label44 As Label
    Friend WithEvents txtF6name As TextBox
    Friend WithEvents Label45 As Label
    Friend WithEvents txtF5name As TextBox
    Friend WithEvents Label46 As Label
    Friend WithEvents chkF4bypass As CheckBox
    Friend WithEvents chkF3bypass As CheckBox
    Friend WithEvents chkF2bypass As CheckBox
    Friend WithEvents chkF1bypass As CheckBox
    Friend WithEvents txtF4name As TextBox
    Friend WithEvents Label38 As Label
    Friend WithEvents txtF3name As TextBox
    Friend WithEvents Label39 As Label
    Friend WithEvents txtF2name As TextBox
    Friend WithEvents Label40 As Label
    Friend WithEvents txtF1name As TextBox
    Friend WithEvents Label41 As Label
    Friend WithEvents Label42 As Label
    Friend WithEvents chkF10bypass As CheckBox
    Friend WithEvents chkF9bypass As CheckBox
    Friend WithEvents txtF10name As TextBox
    Friend WithEvents Label47 As Label
    Friend WithEvents txtF9name As TextBox
    Friend WithEvents Label48 As Label
    Friend WithEvents Label49 As Label
    Friend WithEvents btnSaveZones As Button
    Friend WithEvents Label50 As Label
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents rdo2Senabled As RadioButton
    Friend WithEvents rdo2Sdisabled As RadioButton
    Friend WithEvents Label51 As Label
    Friend WithEvents Label52 As Label
    Friend WithEvents txtS1delay As TextBox
    Friend WithEvents btn2Ssave As Button
    Friend WithEvents GroupBox5 As GroupBox
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents chkS2audible As CheckBox
    Friend WithEvents chkS1audible As CheckBox
    Friend WithEvents Label53 As Label
    Friend WithEvents Label54 As Label
    Friend WithEvents TabControl8 As TabControl
    Friend WithEvents TabPage34 As TabPage
    Friend WithEvents TabPage35 As TabPage
    Friend WithEvents TabPage26 As TabPage
    Friend WithEvents chkS2visual As CheckBox
    Friend WithEvents chkS1visual As CheckBox
    Friend WithEvents chkS2notifier As CheckBox
    Friend WithEvents chkS1notifier As CheckBox
    Friend WithEvents chkS2buzzer As CheckBox
    Friend WithEvents chkS1buzzer As CheckBox
    Friend WithEvents TabPage27 As TabPage
    Friend WithEvents notepad As TextBox
    Friend WithEvents btnNotepadSave As Button
    Friend WithEvents Label55 As Label
    Friend WithEvents Label56 As Label
    Friend WithEvents btnHazAutoStopSave As Button
    Friend WithEvents txtHazAutoStopDelay As TextBox
    Friend WithEvents GroupBox6 As GroupBox
    Friend WithEvents rdoHazASdisabled As RadioButton
    Friend WithEvents rdoHazASenabled As RadioButton
    Friend WithEvents Label57 As Label
    Friend WithEvents btnHazSave As Button
    Friend WithEvents txthaz4name As TextBox
    Friend WithEvents Label58 As Label
    Friend WithEvents txthaz3name As TextBox
    Friend WithEvents Label59 As Label
    Friend WithEvents txthaz2name As TextBox
    Friend WithEvents Label60 As Label
    Friend WithEvents txthaz1name As TextBox
    Friend WithEvents Label61 As Label
    Friend WithEvents Label62 As Label
    Friend WithEvents TabControl9 As TabControl
    Friend WithEvents TabPage38 As TabPage
    Friend WithEvents TabPage39 As TabPage
    Friend WithEvents TabPage40 As TabPage
    Friend WithEvents TabPage41 As TabPage
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label63 As Label
    Friend WithEvents RichTextBox2 As RichTextBox
    Friend WithEvents Label64 As Label
    Friend WithEvents lblIndAgent As Label
    Friend WithEvents btnAgentDisable As Button
    Friend WithEvents btnAgentEnable As Button
    Friend WithEvents btnAgentTestMode As Button
    Friend WithEvents Label65 As Label
    Friend WithEvents Label66 As Label
    Friend WithEvents btnAgentBehavSave As Button
    Friend WithEvents txtAgentDelay As TextBox
    Friend WithEvents txtAgentCountdown As TextBox
    Friend WithEvents Label67 As Label
    Friend WithEvents Label68 As Label
    Friend WithEvents GroupBox7 As GroupBox
    Friend WithEvents Label77 As Label
    Friend WithEvents Label78 As Label
    Friend WithEvents Label73 As Label
    Friend WithEvents Label74 As Label
    Friend WithEvents Label75 As Label
    Friend WithEvents Label76 As Label
    Friend WithEvents Label72 As Label
    Friend WithEvents Label71 As Label
    Friend WithEvents Label70 As Label
    Friend WithEvents Label69 As Label
    Friend WithEvents Label81 As Label
    Friend WithEvents Label82 As Label
    Friend WithEvents Label80 As Label
    Friend WithEvents Label79 As Label
    Friend WithEvents z1a1 As CheckBox
    Friend WithEvents Label84 As Label
    Friend WithEvents Label83 As Label
    Friend WithEvents z1a3 As CheckBox
    Friend WithEvents z1a2 As CheckBox
    Friend WithEvents z1a4 As CheckBox
    Friend WithEvents z2a4 As CheckBox
    Friend WithEvents z2a3 As CheckBox
    Friend WithEvents z2a2 As CheckBox
    Friend WithEvents z2a1 As CheckBox
    Friend WithEvents z4a4 As CheckBox
    Friend WithEvents z4a3 As CheckBox
    Friend WithEvents z4a2 As CheckBox
    Friend WithEvents z4a1 As CheckBox
    Friend WithEvents z3a4 As CheckBox
    Friend WithEvents z3a3 As CheckBox
    Friend WithEvents z3a2 As CheckBox
    Friend WithEvents z3a1 As CheckBox
    Friend WithEvents z8a4 As CheckBox
    Friend WithEvents z8a3 As CheckBox
    Friend WithEvents z8a2 As CheckBox
    Friend WithEvents z8a1 As CheckBox
    Friend WithEvents z7a4 As CheckBox
    Friend WithEvents z7a3 As CheckBox
    Friend WithEvents z7a2 As CheckBox
    Friend WithEvents z7a1 As CheckBox
    Friend WithEvents z6a4 As CheckBox
    Friend WithEvents z6a3 As CheckBox
    Friend WithEvents z6a2 As CheckBox
    Friend WithEvents z6a1 As CheckBox
    Friend WithEvents z5a4 As CheckBox
    Friend WithEvents z5a3 As CheckBox
    Friend WithEvents z5a2 As CheckBox
    Friend WithEvents z5a1 As CheckBox
    Friend WithEvents z10a4 As CheckBox
    Friend WithEvents z10a3 As CheckBox
    Friend WithEvents z10a2 As CheckBox
    Friend WithEvents z10a1 As CheckBox
    Friend WithEvents z9a4 As CheckBox
    Friend WithEvents z9a3 As CheckBox
    Friend WithEvents z9a2 As CheckBox
    Friend WithEvents z9a1 As CheckBox
    Friend WithEvents GroupBox8 As GroupBox
    Friend WithEvents z14a4 As CheckBox
    Friend WithEvents z14a3 As CheckBox
    Friend WithEvents z14a2 As CheckBox
    Friend WithEvents z14a1 As CheckBox
    Friend WithEvents z13a4 As CheckBox
    Friend WithEvents z13a3 As CheckBox
    Friend WithEvents z13a2 As CheckBox
    Friend WithEvents z13a1 As CheckBox
    Friend WithEvents z12a4 As CheckBox
    Friend WithEvents z12a3 As CheckBox
    Friend WithEvents z12a2 As CheckBox
    Friend WithEvents z12a1 As CheckBox
    Friend WithEvents z11a4 As CheckBox
    Friend WithEvents z11a3 As CheckBox
    Friend WithEvents z11a2 As CheckBox
    Friend WithEvents Label85 As Label
    Friend WithEvents Label86 As Label
    Friend WithEvents z11a1 As CheckBox
    Friend WithEvents Label87 As Label
    Friend WithEvents Label88 As Label
    Friend WithEvents Label89 As Label
    Friend WithEvents Label90 As Label
    Friend WithEvents Label97 As Label
    Friend WithEvents Label98 As Label
    Friend WithEvents Label99 As Label
    Friend WithEvents Label100 As Label
    Friend WithEvents GroupBox9 As GroupBox
    Friend WithEvents z24a4 As CheckBox
    Friend WithEvents z24a3 As CheckBox
    Friend WithEvents z24a2 As CheckBox
    Friend WithEvents z24a1 As CheckBox
    Friend WithEvents z23a4 As CheckBox
    Friend WithEvents z23a3 As CheckBox
    Friend WithEvents z23a2 As CheckBox
    Friend WithEvents z23a1 As CheckBox
    Friend WithEvents z22a4 As CheckBox
    Friend WithEvents z22a3 As CheckBox
    Friend WithEvents z22a2 As CheckBox
    Friend WithEvents z22a1 As CheckBox
    Friend WithEvents z21a4 As CheckBox
    Friend WithEvents z21a3 As CheckBox
    Friend WithEvents z21a2 As CheckBox
    Friend WithEvents Label91 As Label
    Friend WithEvents Label92 As Label
    Friend WithEvents z21a1 As CheckBox
    Friend WithEvents Label93 As Label
    Friend WithEvents Label94 As Label
    Friend WithEvents Label95 As Label
    Friend WithEvents Label96 As Label
    Friend WithEvents Label101 As Label
    Friend WithEvents Label102 As Label
    Friend WithEvents Label103 As Label
    Friend WithEvents Label104 As Label
    Friend WithEvents GroupBox10 As GroupBox
    Friend WithEvents CheckBox25 As CheckBox
    Friend WithEvents CheckBox26 As CheckBox
    Friend WithEvents CheckBox27 As CheckBox
    Friend WithEvents CheckBox28 As CheckBox
    Friend WithEvents CheckBox29 As CheckBox
    Friend WithEvents CheckBox30 As CheckBox
    Friend WithEvents CheckBox31 As CheckBox
    Friend WithEvents CheckBox32 As CheckBox
    Friend WithEvents CheckBox49 As CheckBox
    Friend WithEvents CheckBox50 As CheckBox
    Friend WithEvents CheckBox51 As CheckBox
    Friend WithEvents CheckBox52 As CheckBox
    Friend WithEvents CheckBox53 As CheckBox
    Friend WithEvents CheckBox54 As CheckBox
    Friend WithEvents CheckBox55 As CheckBox
    Friend WithEvents Label105 As Label
    Friend WithEvents Label106 As Label
    Friend WithEvents CheckBox56 As CheckBox
    Friend WithEvents Label107 As Label
    Friend WithEvents Label108 As Label
    Friend WithEvents Label109 As Label
    Friend WithEvents Label110 As Label
    Friend WithEvents Label111 As Label
    Friend WithEvents Label112 As Label
    Friend WithEvents Label113 As Label
    Friend WithEvents Label114 As Label
    Friend WithEvents GroupBox11 As GroupBox
    Friend WithEvents CheckBox57 As CheckBox
    Friend WithEvents CheckBox58 As CheckBox
    Friend WithEvents CheckBox59 As CheckBox
    Friend WithEvents CheckBox60 As CheckBox
    Friend WithEvents CheckBox61 As CheckBox
    Friend WithEvents CheckBox62 As CheckBox
    Friend WithEvents CheckBox63 As CheckBox
    Friend WithEvents CheckBox64 As CheckBox
    Friend WithEvents CheckBox65 As CheckBox
    Friend WithEvents CheckBox66 As CheckBox
    Friend WithEvents CheckBox67 As CheckBox
    Friend WithEvents CheckBox68 As CheckBox
    Friend WithEvents CheckBox69 As CheckBox
    Friend WithEvents CheckBox70 As CheckBox
    Friend WithEvents CheckBox71 As CheckBox
    Friend WithEvents Label115 As Label
    Friend WithEvents Label116 As Label
    Friend WithEvents CheckBox72 As CheckBox
    Friend WithEvents Label117 As Label
    Friend WithEvents Label118 As Label
    Friend WithEvents Label119 As Label
    Friend WithEvents Label120 As Label
    Friend WithEvents Label121 As Label
    Friend WithEvents Label122 As Label
    Friend WithEvents Label123 As Label
    Friend WithEvents Label124 As Label
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Label126 As Label
    Friend WithEvents Label125 As Label
    Friend WithEvents GroupBox12 As GroupBox
    Friend WithEvents Label128 As Label
    Friend WithEvents GroupBox13 As GroupBox
    Friend WithEvents Label129 As Label
    Friend WithEvents rdoAbortDisabled As RadioButton
    Friend WithEvents rdoAbortEnabled As RadioButton
    Friend WithEvents Label127 As Label
    Friend WithEvents Label130 As Label
    Friend WithEvents txtPWset1 As TextBox
    Friend WithEvents txtPWset2 As TextBox
    Friend WithEvents Label132 As Label
    Friend WithEvents Label131 As Label
    Friend WithEvents btnPWsave As Button
    Friend WithEvents Label133 As Label
    Friend WithEvents Label134 As Label
    Friend WithEvents Label135 As Label
    Friend WithEvents GroupBox14 As GroupBox
    Friend WithEvents Label136 As Label
    Friend WithEvents rdoQuitDisabled As RadioButton
    Friend WithEvents rdoQuitEnabled As RadioButton
    Friend WithEvents btnForceQuit As Button
    Friend WithEvents Label137 As Label
    Friend WithEvents btnForceQuitDone As Button
    Friend WithEvents txtForceQuitBox As TextBox
    Friend WithEvents fqLbl As Label
    Friend WithEvents GroupBox15 As GroupBox
    Friend WithEvents Label138 As Label
    Friend WithEvents RadioButton1 As RadioButton
    Friend WithEvents RadioButton2 As RadioButton
    Friend WithEvents btnLockCodeRemoved As Button
    Friend WithEvents Label139 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents ColorSlider As TrackBar
    Friend WithEvents Label140 As Label
    Friend WithEvents Label147 As Label
    Friend WithEvents Label146 As Label
    Friend WithEvents Label145 As Label
    Friend WithEvents Label144 As Label
    Friend WithEvents Label143 As Label
    Friend WithEvents Label142 As Label
    Friend WithEvents Label141 As Label
    Friend WithEvents Label148 As Label
    Friend WithEvents btnColorSave As Button
    Friend WithEvents Label149 As Label
    Friend WithEvents Panel4 As Panel
    Friend WithEvents btnSailorMode As Button
    Friend WithEvents Label150 As Label
    Friend WithEvents Label151 As Label
    Friend WithEvents Label152 As Label
    Friend WithEvents btnLampTest As Button
    Friend WithEvents Label153 As Label
    Friend WithEvents TabPage36 As TabPage
    Friend WithEvents Label154 As Label
    Friend WithEvents txtLastName As TextBox
    Friend WithEvents Label156 As Label
    Friend WithEvents txtFirstName As TextBox
    Friend WithEvents Label155 As Label
    Friend WithEvents txtDiscord As TextBox
    Friend WithEvents Label159 As Label
    Friend WithEvents txtPhone2 As TextBox
    Friend WithEvents Label160 As Label
    Friend WithEvents txtPhone1 As TextBox
    Friend WithEvents Label158 As Label
    Friend WithEvents txtEmail As TextBox
    Friend WithEvents Label157 As Label
    Friend WithEvents txtNotes As TextBox
    Friend WithEvents Label161 As Label
    Friend WithEvents btnSaveInfo As Button
    Friend WithEvents btnInfoRemove As Button
End Class
