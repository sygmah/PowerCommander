﻿Public Class MainWin
    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles btnMainQuit.Click
        If My.Settings.ControlPreventQuit = True Then
            MessageBox.Show("PowerCommander administrator has prevented the ability to quit PowerCommander. PowerCommander needs to be running in order for the fire alarm system to operate. Quitting this program will cause the system to become unoperational until it is started and reconnected. Contact system administrator for assistance.", "Security", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            Quit.Show()
        End If
    End Sub

    Private Sub MainWin_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        lblIndSoftwareVer.Text = My.Settings.SysVer
        lblIndName.Text = My.Settings.SystemName
        lblIndModel.Text = My.Settings.SystemModel
        If My.Settings.ControlLockSet = False Then
            lblIndNoPassword.Visible = True
        End If
        If My.Settings.SysConfigSet = False Then
            lblIndNoConfig.Visible = True
        End If
        If My.Settings.ControlLockSet = True Then
            controlPanel.Visible = False
            btnMainQuit.Enabled = False
            btnMainConfigureSystem.Enabled = False
            btnMainChangePort.Enabled = False
        End If

        'set interface color
        If My.Settings.InterfaceColor = 0 Then
            LCD.ForeColor = Color.White
        ElseIf My.Settings.InterfaceColor = 1 Then
            LCD.ForeColor = Color.Yellow
        ElseIf My.Settings.InterfaceColor = 2 Then
            LCD.ForeColor = Color.Green
        ElseIf My.Settings.InterfaceColor = 3 Then
            LCD.ForeColor = Color.Blue
        ElseIf My.Settings.InterfaceColor = 4 Then
            LCD.ForeColor = Color.Purple
        ElseIf My.Settings.InterfaceColor = 5 Then
            LCD.ForeColor = Color.HotPink
        ElseIf My.Settings.InterfaceColor = 6 Then
            LCD.ForeColor = Color.Red
        ElseIf My.Settings.InterfaceColor = 7 Then
            LCD.ForeColor = Color.Orange
        ElseIf My.Settings.InterfaceColor = 8 Then
            LCD.ForeColor = Color.Black
            LCD.BackColor = Color.White
        End If

        'sync "LEDs"
        LCD.Text = "PowerCommander interface is starting up... Please wait..."

        LEDpower.Visible = False
        LEDtrouble.Visible = False
        LEDfire.Visible = False
        LEDfireSil.Visible = False
        LEDhazard.Visible = False
        LEDtblAck.Visible = False
        LEDhazAck.Visible = False
        LEDhush.Visible = False
        LEDagent.Visible = False
        LEDabort.Visible = False

        btnCtlReset.Enabled = False
        btnCtlSil.Enabled = False
        btnCtlTblAck.Enabled = False
        btnCtlHazAck.Enabled = False
        btnCtlHush.Enabled = False
        btnCtlAgentAbort.Enabled = False

        LEDtblNAC.Visible = False
        LEDtblIDC.Visible = False
        LEDtblComm.Visible = False
        LEDtblPower.Visible = False
        LEDtblTemp.Visible = False
        LEDtblExtender.Visible = False

        LEDz1TBL.Visible = False
        LEDz2TBL.Visible = False
        LEDz3TBL.Visible = False
        LEDz4TBL.Visible = False
        LEDz5TBL.Visible = False
        LEDz6TBL.Visible = False
        LEDz7TBL.Visible = False
        LEDz8TBL.Visible = False
        LEDz9TBL.Visible = False
        LEDz10TBL.Visible = False

        LEDz1ALM.Visible = False
        LEDz2ALM.Visible = False
        LEDz3ALM.Visible = False
        LEDz4ALM.Visible = False
        LEDz5ALM.Visible = False
        LEDz6ALM.Visible = False
        LEDz7ALM.Visible = False
        LEDz8ALM.Visible = False
        LEDz9ALM.Visible = False
        LEDz10ALM.Visible = False

        'indicate no connection
        LEDtrouble.Visible = True
        LEDtblComm.Visible = True
        LCD.Text = "TROUBLE:" & vbCrLf & "COMMUNICATION FAULT" & vbCrLf & "PowerCommander couldn't establish a link with the control unit. Make sure you choose the correct serial port address and that the system is connected and powered on."
    End Sub

    Private Sub BtnMainConfigureSystem_Click(sender As Object, e As EventArgs) Handles btnMainConfigureSystem.Click
        Configuration.Show()
        My.Settings.SysConfigSet = True
        lblIndNoConfig.Visible = False
    End Sub

    Private Sub BtnMainAbout_Click(sender As Object, e As EventArgs) Handles btnMainAbout.Click
        About.Show()
    End Sub

    Private Sub BtnMainChangePort_Click(sender As Object, e As EventArgs) Handles btnMainChangePort.Click
        PortSelector.Show()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If txtUnlockBox.Text = My.Settings.ControlLockCode Then
            controlPanel.Visible = True
            btnMainQuit.Enabled = True
            btnMainConfigureSystem.Enabled = True
            btnMainChangePort.Enabled = True
            Button1.Enabled = False
        Else
            MessageBox.Show("The system couldn't unlock the control panel because the lock code you entered does not match the one on record.", "Security", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
        txtUnlockBox.Text = Nothing
    End Sub

    Private Sub LblIndNoConfig_Click(sender As Object, e As EventArgs) Handles lblIndNoConfig.Click
        Configuration.Show()
        lblIndNoConfig.Visible = False
        My.Settings.SysConfigSet = True
    End Sub

    Private Sub LblIndNoPassword_Click(sender As Object, e As EventArgs) Handles lblIndNoPassword.Click
        Configuration.Show()
        lblIndNoPassword.Visible = False
        My.Settings.SysConfigSet = True
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btnLockCP.Click
        controlPanel.Visible = False
        btnMainQuit.Enabled = False
        btnMainConfigureSystem.Enabled = False
        btnMainChangePort.Enabled = False
        Button1.Enabled = True
    End Sub

    Private Sub BtnAdminContact_Click(sender As Object, e As EventArgs) Handles btnAdminContact.Click
        adminInfo.Show()
    End Sub

    Private Sub BtnAgentStat_Click(sender As Object, e As EventArgs) Handles btnAgentStat.Click
        If My.Settings.AgentTesting = True Then
            MessageBox.Show("The suppression system is currently down for testing. Agent release has been locked out to prevent accidental discharge.", "Agent Release System", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        ElseIf My.Settings.AgentEnabled = False Then
            MessageBox.Show("To control fire suppression agent release with the PowerCommander system, you must first set up Agent Release System in configuration.", "Agent Release System", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else

        End If
    End Sub

    Private Sub Button4_Click_1(sender As Object, e As EventArgs) Handles btnDiag.Click

    End Sub

    Private Sub BtnExtenderZones_Click(sender As Object, e As EventArgs) Handles btnExtenderZones.Click
        If My.Settings.SEenabled = False Then
            MessageBox.Show("System Extender is not enabled. To use one or more System Extenders, you must first enable and configure System Extender in the configuration. You must also configure the System Extender software on each remote system.", "System Extender", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub

    Private Sub BtnZoneMap_Click(sender As Object, e As EventArgs) Handles btnZoneMap.Click
        MessageBox.Show("There is no zone map available.", "Zone Map", MessageBoxButtons.OK, MessageBoxIcon.Error)
    End Sub
End Class
