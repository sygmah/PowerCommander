﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class MainWin
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(MainWin))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.btnMainConfigureSystem = New System.Windows.Forms.Button()
        Me.btnMainAbout = New System.Windows.Forms.Button()
        Me.btnMainChangePort = New System.Windows.Forms.Button()
        Me.btnMainQuit = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.lblIndNoPassword = New System.Windows.Forms.Label()
        Me.lblIndNoConfig = New System.Windows.Forms.Label()
        Me.lblIndSoftwareVer = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.controlPanel = New System.Windows.Forms.Panel()
        Me.lblOF1 = New System.Windows.Forms.Label()
        Me.btnAdminContact = New System.Windows.Forms.Button()
        Me.btnAgentStat = New System.Windows.Forms.Button()
        Me.btnDiag = New System.Windows.Forms.Button()
        Me.btnExtenderZones = New System.Windows.Forms.Button()
        Me.btnZoneMap = New System.Windows.Forms.Button()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.LEDz10ALM = New System.Windows.Forms.Panel()
        Me.fa10 = New System.Windows.Forms.Label()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.LEDz10TBL = New System.Windows.Forms.Panel()
        Me.ft10 = New System.Windows.Forms.Label()
        Me.LEDz9ALM = New System.Windows.Forms.Panel()
        Me.fa9 = New System.Windows.Forms.Label()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.LEDz9TBL = New System.Windows.Forms.Panel()
        Me.ft9 = New System.Windows.Forms.Label()
        Me.LEDz8ALM = New System.Windows.Forms.Panel()
        Me.fa8 = New System.Windows.Forms.Label()
        Me.LEDz7ALM = New System.Windows.Forms.Panel()
        Me.fa7 = New System.Windows.Forms.Label()
        Me.LEDz8TBL = New System.Windows.Forms.Panel()
        Me.ft8 = New System.Windows.Forms.Label()
        Me.LEDz7TBL = New System.Windows.Forms.Panel()
        Me.ft7 = New System.Windows.Forms.Label()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.LEDz6ALM = New System.Windows.Forms.Panel()
        Me.fa6 = New System.Windows.Forms.Label()
        Me.LEDz6TBL = New System.Windows.Forms.Panel()
        Me.ft6 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.LEDz5ALM = New System.Windows.Forms.Panel()
        Me.fa5 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.LEDz5TBL = New System.Windows.Forms.Panel()
        Me.ft5 = New System.Windows.Forms.Label()
        Me.LEDz4ALM = New System.Windows.Forms.Panel()
        Me.fa4 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.LEDz4TBL = New System.Windows.Forms.Panel()
        Me.ft4 = New System.Windows.Forms.Label()
        Me.LEDz3ALM = New System.Windows.Forms.Panel()
        Me.fa3 = New System.Windows.Forms.Label()
        Me.LEDz2ALM = New System.Windows.Forms.Panel()
        Me.fa2 = New System.Windows.Forms.Label()
        Me.LEDz3TBL = New System.Windows.Forms.Panel()
        Me.ft3 = New System.Windows.Forms.Label()
        Me.LEDz2TBL = New System.Windows.Forms.Panel()
        Me.ft2 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.LEDz1ALM = New System.Windows.Forms.Panel()
        Me.fa1 = New System.Windows.Forms.Label()
        Me.LEDz1TBL = New System.Windows.Forms.Panel()
        Me.ft1 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.LEDtblExtender = New System.Windows.Forms.Panel()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.LEDtblTemp = New System.Windows.Forms.Panel()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.LEDtblPower = New System.Windows.Forms.Panel()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.LEDtblComm = New System.Windows.Forms.Panel()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.LEDtblIDC = New System.Windows.Forms.Panel()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.LEDtblNAC = New System.Windows.Forms.Panel()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.btnCtlAgentAbort = New System.Windows.Forms.Button()
        Me.btnCtlHush = New System.Windows.Forms.Button()
        Me.btnCtlHazAck = New System.Windows.Forms.Button()
        Me.btnCtlSil = New System.Windows.Forms.Button()
        Me.btnCtlTblAck = New System.Windows.Forms.Button()
        Me.btnCtlReset = New System.Windows.Forms.Button()
        Me.LEDabort = New System.Windows.Forms.Panel()
        Me.lblAbort = New System.Windows.Forms.Label()
        Me.LEDagent = New System.Windows.Forms.Panel()
        Me.lblAgent = New System.Windows.Forms.Label()
        Me.LEDtblAck = New System.Windows.Forms.Panel()
        Me.lblTblAck = New System.Windows.Forms.Label()
        Me.LEDhush = New System.Windows.Forms.Panel()
        Me.lblHush = New System.Windows.Forms.Label()
        Me.LEDhazAck = New System.Windows.Forms.Panel()
        Me.lblHazAck = New System.Windows.Forms.Label()
        Me.LEDfireSil = New System.Windows.Forms.Panel()
        Me.lblSil = New System.Windows.Forms.Label()
        Me.LEDhazard = New System.Windows.Forms.Panel()
        Me.lblHaz = New System.Windows.Forms.Label()
        Me.LEDfire = New System.Windows.Forms.Panel()
        Me.lblAlm = New System.Windows.Forms.Label()
        Me.LEDtrouble = New System.Windows.Forms.Panel()
        Me.lblTbl = New System.Windows.Forms.Label()
        Me.LEDpower = New System.Windows.Forms.Panel()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.btnHelp = New System.Windows.Forms.Button()
        Me.btnCommTest = New System.Windows.Forms.Button()
        Me.display = New System.Windows.Forms.Panel()
        Me.LCD = New System.Windows.Forms.Label()
        Me.btnLockCP = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.lblIndName = New System.Windows.Forms.Label()
        Me.lblIndModel = New System.Windows.Forms.Label()
        Me.lblIndStat = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtUnlockBox = New System.Windows.Forms.TextBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.serial = New System.IO.Ports.SerialPort(Me.components)
        Me.Panel1.SuspendLayout()
        Me.controlPanel.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.LEDz10ALM.SuspendLayout()
        Me.LEDz10TBL.SuspendLayout()
        Me.LEDz9ALM.SuspendLayout()
        Me.LEDz9TBL.SuspendLayout()
        Me.LEDz8ALM.SuspendLayout()
        Me.LEDz7ALM.SuspendLayout()
        Me.LEDz8TBL.SuspendLayout()
        Me.LEDz7TBL.SuspendLayout()
        Me.LEDz6ALM.SuspendLayout()
        Me.LEDz6TBL.SuspendLayout()
        Me.LEDz5ALM.SuspendLayout()
        Me.LEDz5TBL.SuspendLayout()
        Me.LEDz4ALM.SuspendLayout()
        Me.LEDz4TBL.SuspendLayout()
        Me.LEDz3ALM.SuspendLayout()
        Me.LEDz2ALM.SuspendLayout()
        Me.LEDz3TBL.SuspendLayout()
        Me.LEDz2TBL.SuspendLayout()
        Me.LEDz1ALM.SuspendLayout()
        Me.LEDz1TBL.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.LEDtblExtender.SuspendLayout()
        Me.LEDtblTemp.SuspendLayout()
        Me.LEDtblPower.SuspendLayout()
        Me.LEDtblComm.SuspendLayout()
        Me.LEDtblIDC.SuspendLayout()
        Me.LEDtblNAC.SuspendLayout()
        Me.LEDabort.SuspendLayout()
        Me.LEDagent.SuspendLayout()
        Me.LEDtblAck.SuspendLayout()
        Me.LEDhush.SuspendLayout()
        Me.LEDhazAck.SuspendLayout()
        Me.LEDfireSil.SuspendLayout()
        Me.LEDhazard.SuspendLayout()
        Me.LEDfire.SuspendLayout()
        Me.LEDtrouble.SuspendLayout()
        Me.LEDpower.SuspendLayout()
        Me.display.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Montserrat Light", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Red
        Me.Label1.Location = New System.Drawing.Point(55, 14)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(327, 44)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "PowerCommander"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Montserrat", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Red
        Me.Label2.Location = New System.Drawing.Point(369, 14)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(43, 44)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "X"
        '
        'btnMainConfigureSystem
        '
        Me.btnMainConfigureSystem.Location = New System.Drawing.Point(423, 12)
        Me.btnMainConfigureSystem.Name = "btnMainConfigureSystem"
        Me.btnMainConfigureSystem.Size = New System.Drawing.Size(116, 46)
        Me.btnMainConfigureSystem.TabIndex = 3
        Me.btnMainConfigureSystem.Text = "Configure System"
        Me.btnMainConfigureSystem.UseVisualStyleBackColor = True
        '
        'btnMainAbout
        '
        Me.btnMainAbout.Location = New System.Drawing.Point(545, 12)
        Me.btnMainAbout.Name = "btnMainAbout"
        Me.btnMainAbout.Size = New System.Drawing.Size(72, 46)
        Me.btnMainAbout.TabIndex = 4
        Me.btnMainAbout.Text = "About..."
        Me.btnMainAbout.UseVisualStyleBackColor = True
        '
        'btnMainChangePort
        '
        Me.btnMainChangePort.Location = New System.Drawing.Point(623, 12)
        Me.btnMainChangePort.Name = "btnMainChangePort"
        Me.btnMainChangePort.Size = New System.Drawing.Size(97, 46)
        Me.btnMainChangePort.TabIndex = 5
        Me.btnMainChangePort.Text = "Change Port"
        Me.btnMainChangePort.UseVisualStyleBackColor = True
        '
        'btnMainQuit
        '
        Me.btnMainQuit.Location = New System.Drawing.Point(726, 12)
        Me.btnMainQuit.Name = "btnMainQuit"
        Me.btnMainQuit.Size = New System.Drawing.Size(142, 46)
        Me.btnMainQuit.TabIndex = 6
        Me.btnMainQuit.Text = "Quit PowerMarshall X"
        Me.btnMainQuit.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.ControlLight
        Me.Panel1.Controls.Add(Me.lblIndNoPassword)
        Me.Panel1.Controls.Add(Me.lblIndNoConfig)
        Me.Panel1.Controls.Add(Me.lblIndSoftwareVer)
        Me.Panel1.Controls.Add(Me.Label8)
        Me.Panel1.Controls.Add(Me.controlPanel)
        Me.Panel1.Controls.Add(Me.Button1)
        Me.Panel1.Controls.Add(Me.lblIndName)
        Me.Panel1.Controls.Add(Me.lblIndModel)
        Me.Panel1.Controls.Add(Me.lblIndStat)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.txtUnlockBox)
        Me.Panel1.Location = New System.Drawing.Point(12, 66)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(856, 401)
        Me.Panel1.TabIndex = 7
        '
        'lblIndNoPassword
        '
        Me.lblIndNoPassword.ForeColor = System.Drawing.Color.Red
        Me.lblIndNoPassword.Location = New System.Drawing.Point(10, 267)
        Me.lblIndNoPassword.Name = "lblIndNoPassword"
        Me.lblIndNoPassword.Size = New System.Drawing.Size(206, 54)
        Me.lblIndNoPassword.TabIndex = 13
        Me.lblIndNoPassword.Text = "Your system is missing a lock code. Without a lock code, you can't disable the co" &
    "ntrol interface. Check the security tab."
        Me.lblIndNoPassword.TextAlign = System.Drawing.ContentAlignment.BottomLeft
        Me.lblIndNoPassword.Visible = False
        '
        'lblIndNoConfig
        '
        Me.lblIndNoConfig.ForeColor = System.Drawing.Color.Red
        Me.lblIndNoConfig.Location = New System.Drawing.Point(10, 321)
        Me.lblIndNoConfig.Name = "lblIndNoConfig"
        Me.lblIndNoConfig.Size = New System.Drawing.Size(206, 54)
        Me.lblIndNoConfig.TabIndex = 12
        Me.lblIndNoConfig.Text = "Your system has not been configured. Please open Configuration Editor to update c" &
    "onfigurations and set up your system."
        Me.lblIndNoConfig.TextAlign = System.Drawing.ContentAlignment.BottomLeft
        Me.lblIndNoConfig.Visible = False
        '
        'lblIndSoftwareVer
        '
        Me.lblIndSoftwareVer.AutoSize = True
        Me.lblIndSoftwareVer.Location = New System.Drawing.Point(91, 379)
        Me.lblIndSoftwareVer.Name = "lblIndSoftwareVer"
        Me.lblIndSoftwareVer.Size = New System.Drawing.Size(75, 13)
        Me.lblIndSoftwareVer.TabIndex = 10
        Me.lblIndSoftwareVer.Text = "System Name:"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(9, 379)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(70, 13)
        Me.Label8.TabIndex = 9
        Me.Label8.Text = "Software ver:"
        '
        'controlPanel
        '
        Me.controlPanel.BackColor = System.Drawing.Color.White
        Me.controlPanel.Controls.Add(Me.lblOF1)
        Me.controlPanel.Controls.Add(Me.btnAdminContact)
        Me.controlPanel.Controls.Add(Me.btnAgentStat)
        Me.controlPanel.Controls.Add(Me.btnDiag)
        Me.controlPanel.Controls.Add(Me.btnExtenderZones)
        Me.controlPanel.Controls.Add(Me.btnZoneMap)
        Me.controlPanel.Controls.Add(Me.GroupBox2)
        Me.controlPanel.Controls.Add(Me.GroupBox1)
        Me.controlPanel.Controls.Add(Me.btnCtlAgentAbort)
        Me.controlPanel.Controls.Add(Me.btnCtlHush)
        Me.controlPanel.Controls.Add(Me.btnCtlHazAck)
        Me.controlPanel.Controls.Add(Me.btnCtlSil)
        Me.controlPanel.Controls.Add(Me.btnCtlTblAck)
        Me.controlPanel.Controls.Add(Me.btnCtlReset)
        Me.controlPanel.Controls.Add(Me.LEDabort)
        Me.controlPanel.Controls.Add(Me.LEDagent)
        Me.controlPanel.Controls.Add(Me.LEDtblAck)
        Me.controlPanel.Controls.Add(Me.LEDhush)
        Me.controlPanel.Controls.Add(Me.LEDhazAck)
        Me.controlPanel.Controls.Add(Me.LEDfireSil)
        Me.controlPanel.Controls.Add(Me.LEDhazard)
        Me.controlPanel.Controls.Add(Me.LEDfire)
        Me.controlPanel.Controls.Add(Me.LEDtrouble)
        Me.controlPanel.Controls.Add(Me.LEDpower)
        Me.controlPanel.Controls.Add(Me.btnHelp)
        Me.controlPanel.Controls.Add(Me.btnCommTest)
        Me.controlPanel.Controls.Add(Me.display)
        Me.controlPanel.Controls.Add(Me.btnLockCP)
        Me.controlPanel.Location = New System.Drawing.Point(221, 3)
        Me.controlPanel.Name = "controlPanel"
        Me.controlPanel.Size = New System.Drawing.Size(632, 395)
        Me.controlPanel.TabIndex = 8
        '
        'lblOF1
        '
        Me.lblOF1.AutoSize = True
        Me.lblOF1.Location = New System.Drawing.Point(52, 336)
        Me.lblOF1.Name = "lblOF1"
        Me.lblOF1.Size = New System.Drawing.Size(65, 13)
        Me.lblOF1.TabIndex = 23
        Me.lblOF1.Text = "IS BROKEN"
        Me.lblOF1.Visible = False
        '
        'btnAdminContact
        '
        Me.btnAdminContact.Location = New System.Drawing.Point(438, 357)
        Me.btnAdminContact.Name = "btnAdminContact"
        Me.btnAdminContact.Size = New System.Drawing.Size(150, 23)
        Me.btnAdminContact.TabIndex = 22
        Me.btnAdminContact.Text = "Contact Admin"
        Me.btnAdminContact.UseVisualStyleBackColor = True
        '
        'btnAgentStat
        '
        Me.btnAgentStat.Location = New System.Drawing.Point(282, 357)
        Me.btnAgentStat.Name = "btnAgentStat"
        Me.btnAgentStat.Size = New System.Drawing.Size(150, 23)
        Me.btnAgentStat.TabIndex = 21
        Me.btnAgentStat.Text = "Agent Details"
        Me.btnAgentStat.UseVisualStyleBackColor = True
        '
        'btnDiag
        '
        Me.btnDiag.Location = New System.Drawing.Point(13, 119)
        Me.btnDiag.Name = "btnDiag"
        Me.btnDiag.Size = New System.Drawing.Size(75, 23)
        Me.btnDiag.TabIndex = 20
        Me.btnDiag.Text = "Diagnostics"
        Me.btnDiag.UseVisualStyleBackColor = True
        '
        'btnExtenderZones
        '
        Me.btnExtenderZones.Location = New System.Drawing.Point(126, 357)
        Me.btnExtenderZones.Name = "btnExtenderZones"
        Me.btnExtenderZones.Size = New System.Drawing.Size(150, 23)
        Me.btnExtenderZones.TabIndex = 19
        Me.btnExtenderZones.Text = "Show Extender Zones"
        Me.btnExtenderZones.UseVisualStyleBackColor = True
        '
        'btnZoneMap
        '
        Me.btnZoneMap.Location = New System.Drawing.Point(45, 357)
        Me.btnZoneMap.Name = "btnZoneMap"
        Me.btnZoneMap.Size = New System.Drawing.Size(75, 23)
        Me.btnZoneMap.TabIndex = 18
        Me.btnZoneMap.Text = "Zone Map"
        Me.btnZoneMap.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Label38)
        Me.GroupBox2.Controls.Add(Me.Label39)
        Me.GroupBox2.Controls.Add(Me.LEDz10ALM)
        Me.GroupBox2.Controls.Add(Me.Label41)
        Me.GroupBox2.Controls.Add(Me.LEDz10TBL)
        Me.GroupBox2.Controls.Add(Me.LEDz9ALM)
        Me.GroupBox2.Controls.Add(Me.Label44)
        Me.GroupBox2.Controls.Add(Me.LEDz9TBL)
        Me.GroupBox2.Controls.Add(Me.LEDz8ALM)
        Me.GroupBox2.Controls.Add(Me.LEDz7ALM)
        Me.GroupBox2.Controls.Add(Me.LEDz8TBL)
        Me.GroupBox2.Controls.Add(Me.LEDz7TBL)
        Me.GroupBox2.Controls.Add(Me.Label50)
        Me.GroupBox2.Controls.Add(Me.LEDz6ALM)
        Me.GroupBox2.Controls.Add(Me.LEDz6TBL)
        Me.GroupBox2.Controls.Add(Me.Label35)
        Me.GroupBox2.Controls.Add(Me.Label32)
        Me.GroupBox2.Controls.Add(Me.LEDz5ALM)
        Me.GroupBox2.Controls.Add(Me.Label29)
        Me.GroupBox2.Controls.Add(Me.LEDz5TBL)
        Me.GroupBox2.Controls.Add(Me.LEDz4ALM)
        Me.GroupBox2.Controls.Add(Me.Label26)
        Me.GroupBox2.Controls.Add(Me.LEDz4TBL)
        Me.GroupBox2.Controls.Add(Me.LEDz3ALM)
        Me.GroupBox2.Controls.Add(Me.LEDz2ALM)
        Me.GroupBox2.Controls.Add(Me.LEDz3TBL)
        Me.GroupBox2.Controls.Add(Me.LEDz2TBL)
        Me.GroupBox2.Controls.Add(Me.Label25)
        Me.GroupBox2.Controls.Add(Me.LEDz1ALM)
        Me.GroupBox2.Controls.Add(Me.LEDz1TBL)
        Me.GroupBox2.Location = New System.Drawing.Point(151, 174)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(438, 169)
        Me.GroupBox2.TabIndex = 17
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "INTERNAL FIRE ZONES"
        '
        'Label38
        '
        Me.Label38.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label38.Location = New System.Drawing.Point(347, 119)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(78, 18)
        Me.Label38.TabIndex = 24
        Me.Label38.Text = "ZONE 10"
        Me.Label38.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label39
        '
        Me.Label39.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label39.Location = New System.Drawing.Point(263, 119)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(78, 18)
        Me.Label39.TabIndex = 25
        Me.Label39.Text = "ZONE 9"
        Me.Label39.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LEDz10ALM
        '
        Me.LEDz10ALM.BackColor = System.Drawing.Color.Red
        Me.LEDz10ALM.Controls.Add(Me.fa10)
        Me.LEDz10ALM.ForeColor = System.Drawing.Color.White
        Me.LEDz10ALM.Location = New System.Drawing.Point(347, 139)
        Me.LEDz10ALM.Name = "LEDz10ALM"
        Me.LEDz10ALM.Size = New System.Drawing.Size(78, 18)
        Me.LEDz10ALM.TabIndex = 20
        '
        'fa10
        '
        Me.fa10.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.fa10.Location = New System.Drawing.Point(0, 0)
        Me.fa10.Name = "fa10"
        Me.fa10.Size = New System.Drawing.Size(78, 18)
        Me.fa10.TabIndex = 4
        Me.fa10.Text = "ALARM"
        Me.fa10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label41
        '
        Me.Label41.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label41.Location = New System.Drawing.Point(179, 119)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(78, 18)
        Me.Label41.TabIndex = 26
        Me.Label41.Text = "ZONE 8"
        Me.Label41.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LEDz10TBL
        '
        Me.LEDz10TBL.BackColor = System.Drawing.Color.Yellow
        Me.LEDz10TBL.Controls.Add(Me.ft10)
        Me.LEDz10TBL.Location = New System.Drawing.Point(347, 100)
        Me.LEDz10TBL.Name = "LEDz10TBL"
        Me.LEDz10TBL.Size = New System.Drawing.Size(78, 18)
        Me.LEDz10TBL.TabIndex = 16
        '
        'ft10
        '
        Me.ft10.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ft10.Location = New System.Drawing.Point(0, 0)
        Me.ft10.Name = "ft10"
        Me.ft10.Size = New System.Drawing.Size(78, 18)
        Me.ft10.TabIndex = 4
        Me.ft10.Text = "TROUBLE"
        Me.ft10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LEDz9ALM
        '
        Me.LEDz9ALM.BackColor = System.Drawing.Color.Red
        Me.LEDz9ALM.Controls.Add(Me.fa9)
        Me.LEDz9ALM.ForeColor = System.Drawing.Color.White
        Me.LEDz9ALM.Location = New System.Drawing.Point(263, 139)
        Me.LEDz9ALM.Name = "LEDz9ALM"
        Me.LEDz9ALM.Size = New System.Drawing.Size(78, 18)
        Me.LEDz9ALM.TabIndex = 21
        '
        'fa9
        '
        Me.fa9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.fa9.Location = New System.Drawing.Point(0, 0)
        Me.fa9.Name = "fa9"
        Me.fa9.Size = New System.Drawing.Size(78, 18)
        Me.fa9.TabIndex = 4
        Me.fa9.Text = "ALARM"
        Me.fa9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label44
        '
        Me.Label44.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label44.Location = New System.Drawing.Point(95, 119)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(78, 18)
        Me.Label44.TabIndex = 27
        Me.Label44.Text = "ZONE 7"
        Me.Label44.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LEDz9TBL
        '
        Me.LEDz9TBL.BackColor = System.Drawing.Color.Yellow
        Me.LEDz9TBL.Controls.Add(Me.ft9)
        Me.LEDz9TBL.Location = New System.Drawing.Point(263, 100)
        Me.LEDz9TBL.Name = "LEDz9TBL"
        Me.LEDz9TBL.Size = New System.Drawing.Size(78, 18)
        Me.LEDz9TBL.TabIndex = 17
        '
        'ft9
        '
        Me.ft9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ft9.Location = New System.Drawing.Point(0, 0)
        Me.ft9.Name = "ft9"
        Me.ft9.Size = New System.Drawing.Size(78, 18)
        Me.ft9.TabIndex = 4
        Me.ft9.Text = "TROUBLE"
        Me.ft9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LEDz8ALM
        '
        Me.LEDz8ALM.BackColor = System.Drawing.Color.Red
        Me.LEDz8ALM.Controls.Add(Me.fa8)
        Me.LEDz8ALM.ForeColor = System.Drawing.Color.White
        Me.LEDz8ALM.Location = New System.Drawing.Point(179, 139)
        Me.LEDz8ALM.Name = "LEDz8ALM"
        Me.LEDz8ALM.Size = New System.Drawing.Size(78, 18)
        Me.LEDz8ALM.TabIndex = 22
        '
        'fa8
        '
        Me.fa8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.fa8.Location = New System.Drawing.Point(0, 0)
        Me.fa8.Name = "fa8"
        Me.fa8.Size = New System.Drawing.Size(78, 18)
        Me.fa8.TabIndex = 4
        Me.fa8.Text = "ALARM"
        Me.fa8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LEDz7ALM
        '
        Me.LEDz7ALM.BackColor = System.Drawing.Color.Red
        Me.LEDz7ALM.Controls.Add(Me.fa7)
        Me.LEDz7ALM.ForeColor = System.Drawing.Color.White
        Me.LEDz7ALM.Location = New System.Drawing.Point(95, 139)
        Me.LEDz7ALM.Name = "LEDz7ALM"
        Me.LEDz7ALM.Size = New System.Drawing.Size(78, 18)
        Me.LEDz7ALM.TabIndex = 23
        '
        'fa7
        '
        Me.fa7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.fa7.Location = New System.Drawing.Point(0, 0)
        Me.fa7.Name = "fa7"
        Me.fa7.Size = New System.Drawing.Size(78, 18)
        Me.fa7.TabIndex = 4
        Me.fa7.Text = "ALARM"
        Me.fa7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LEDz8TBL
        '
        Me.LEDz8TBL.BackColor = System.Drawing.Color.Yellow
        Me.LEDz8TBL.Controls.Add(Me.ft8)
        Me.LEDz8TBL.Location = New System.Drawing.Point(179, 100)
        Me.LEDz8TBL.Name = "LEDz8TBL"
        Me.LEDz8TBL.Size = New System.Drawing.Size(78, 18)
        Me.LEDz8TBL.TabIndex = 18
        '
        'ft8
        '
        Me.ft8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ft8.Location = New System.Drawing.Point(0, 0)
        Me.ft8.Name = "ft8"
        Me.ft8.Size = New System.Drawing.Size(78, 18)
        Me.ft8.TabIndex = 4
        Me.ft8.Text = "TROUBLE"
        Me.ft8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LEDz7TBL
        '
        Me.LEDz7TBL.BackColor = System.Drawing.Color.Yellow
        Me.LEDz7TBL.Controls.Add(Me.ft7)
        Me.LEDz7TBL.Location = New System.Drawing.Point(95, 100)
        Me.LEDz7TBL.Name = "LEDz7TBL"
        Me.LEDz7TBL.Size = New System.Drawing.Size(78, 18)
        Me.LEDz7TBL.TabIndex = 19
        '
        'ft7
        '
        Me.ft7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ft7.Location = New System.Drawing.Point(0, 0)
        Me.ft7.Name = "ft7"
        Me.ft7.Size = New System.Drawing.Size(78, 18)
        Me.ft7.TabIndex = 4
        Me.ft7.Text = "TROUBLE"
        Me.ft7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label50
        '
        Me.Label50.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label50.Location = New System.Drawing.Point(11, 119)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(78, 18)
        Me.Label50.TabIndex = 15
        Me.Label50.Text = "ZONE 6"
        Me.Label50.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LEDz6ALM
        '
        Me.LEDz6ALM.BackColor = System.Drawing.Color.Red
        Me.LEDz6ALM.Controls.Add(Me.fa6)
        Me.LEDz6ALM.ForeColor = System.Drawing.Color.White
        Me.LEDz6ALM.Location = New System.Drawing.Point(11, 139)
        Me.LEDz6ALM.Name = "LEDz6ALM"
        Me.LEDz6ALM.Size = New System.Drawing.Size(78, 18)
        Me.LEDz6ALM.TabIndex = 14
        '
        'fa6
        '
        Me.fa6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.fa6.Location = New System.Drawing.Point(0, 0)
        Me.fa6.Name = "fa6"
        Me.fa6.Size = New System.Drawing.Size(78, 18)
        Me.fa6.TabIndex = 4
        Me.fa6.Text = "ALARM"
        Me.fa6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LEDz6TBL
        '
        Me.LEDz6TBL.BackColor = System.Drawing.Color.Yellow
        Me.LEDz6TBL.Controls.Add(Me.ft6)
        Me.LEDz6TBL.Location = New System.Drawing.Point(11, 100)
        Me.LEDz6TBL.Name = "LEDz6TBL"
        Me.LEDz6TBL.Size = New System.Drawing.Size(78, 18)
        Me.LEDz6TBL.TabIndex = 13
        '
        'ft6
        '
        Me.ft6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ft6.Location = New System.Drawing.Point(0, 0)
        Me.ft6.Name = "ft6"
        Me.ft6.Size = New System.Drawing.Size(78, 18)
        Me.ft6.TabIndex = 4
        Me.ft6.Text = "TROUBLE"
        Me.ft6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label35
        '
        Me.Label35.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label35.Location = New System.Drawing.Point(347, 38)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(78, 18)
        Me.Label35.TabIndex = 12
        Me.Label35.Text = "ZONE 5"
        Me.Label35.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label32
        '
        Me.Label32.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label32.Location = New System.Drawing.Point(263, 38)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(78, 18)
        Me.Label32.TabIndex = 12
        Me.Label32.Text = "ZONE 4"
        Me.Label32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LEDz5ALM
        '
        Me.LEDz5ALM.BackColor = System.Drawing.Color.Red
        Me.LEDz5ALM.Controls.Add(Me.fa5)
        Me.LEDz5ALM.ForeColor = System.Drawing.Color.White
        Me.LEDz5ALM.Location = New System.Drawing.Point(347, 58)
        Me.LEDz5ALM.Name = "LEDz5ALM"
        Me.LEDz5ALM.Size = New System.Drawing.Size(78, 18)
        Me.LEDz5ALM.TabIndex = 11
        '
        'fa5
        '
        Me.fa5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.fa5.Location = New System.Drawing.Point(0, 0)
        Me.fa5.Name = "fa5"
        Me.fa5.Size = New System.Drawing.Size(78, 18)
        Me.fa5.TabIndex = 4
        Me.fa5.Text = "ALARM"
        Me.fa5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label29
        '
        Me.Label29.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.Location = New System.Drawing.Point(179, 38)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(78, 18)
        Me.Label29.TabIndex = 12
        Me.Label29.Text = "ZONE 3"
        Me.Label29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LEDz5TBL
        '
        Me.LEDz5TBL.BackColor = System.Drawing.Color.Yellow
        Me.LEDz5TBL.Controls.Add(Me.ft5)
        Me.LEDz5TBL.Location = New System.Drawing.Point(347, 19)
        Me.LEDz5TBL.Name = "LEDz5TBL"
        Me.LEDz5TBL.Size = New System.Drawing.Size(78, 18)
        Me.LEDz5TBL.TabIndex = 10
        '
        'ft5
        '
        Me.ft5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ft5.Location = New System.Drawing.Point(0, 0)
        Me.ft5.Name = "ft5"
        Me.ft5.Size = New System.Drawing.Size(78, 18)
        Me.ft5.TabIndex = 4
        Me.ft5.Text = "TROUBLE"
        Me.ft5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LEDz4ALM
        '
        Me.LEDz4ALM.BackColor = System.Drawing.Color.Red
        Me.LEDz4ALM.Controls.Add(Me.fa4)
        Me.LEDz4ALM.ForeColor = System.Drawing.Color.White
        Me.LEDz4ALM.Location = New System.Drawing.Point(263, 58)
        Me.LEDz4ALM.Name = "LEDz4ALM"
        Me.LEDz4ALM.Size = New System.Drawing.Size(78, 18)
        Me.LEDz4ALM.TabIndex = 11
        '
        'fa4
        '
        Me.fa4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.fa4.Location = New System.Drawing.Point(0, 0)
        Me.fa4.Name = "fa4"
        Me.fa4.Size = New System.Drawing.Size(78, 18)
        Me.fa4.TabIndex = 4
        Me.fa4.Text = "ALARM"
        Me.fa4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label26
        '
        Me.Label26.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.Location = New System.Drawing.Point(95, 38)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(78, 18)
        Me.Label26.TabIndex = 12
        Me.Label26.Text = "ZONE 2"
        Me.Label26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LEDz4TBL
        '
        Me.LEDz4TBL.BackColor = System.Drawing.Color.Yellow
        Me.LEDz4TBL.Controls.Add(Me.ft4)
        Me.LEDz4TBL.Location = New System.Drawing.Point(263, 19)
        Me.LEDz4TBL.Name = "LEDz4TBL"
        Me.LEDz4TBL.Size = New System.Drawing.Size(78, 18)
        Me.LEDz4TBL.TabIndex = 10
        '
        'ft4
        '
        Me.ft4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ft4.Location = New System.Drawing.Point(0, 0)
        Me.ft4.Name = "ft4"
        Me.ft4.Size = New System.Drawing.Size(78, 18)
        Me.ft4.TabIndex = 4
        Me.ft4.Text = "TROUBLE"
        Me.ft4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LEDz3ALM
        '
        Me.LEDz3ALM.BackColor = System.Drawing.Color.Red
        Me.LEDz3ALM.Controls.Add(Me.fa3)
        Me.LEDz3ALM.ForeColor = System.Drawing.Color.White
        Me.LEDz3ALM.Location = New System.Drawing.Point(179, 58)
        Me.LEDz3ALM.Name = "LEDz3ALM"
        Me.LEDz3ALM.Size = New System.Drawing.Size(78, 18)
        Me.LEDz3ALM.TabIndex = 11
        '
        'fa3
        '
        Me.fa3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.fa3.Location = New System.Drawing.Point(0, 0)
        Me.fa3.Name = "fa3"
        Me.fa3.Size = New System.Drawing.Size(78, 18)
        Me.fa3.TabIndex = 4
        Me.fa3.Text = "ALARM"
        Me.fa3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LEDz2ALM
        '
        Me.LEDz2ALM.BackColor = System.Drawing.Color.Red
        Me.LEDz2ALM.Controls.Add(Me.fa2)
        Me.LEDz2ALM.ForeColor = System.Drawing.Color.White
        Me.LEDz2ALM.Location = New System.Drawing.Point(95, 58)
        Me.LEDz2ALM.Name = "LEDz2ALM"
        Me.LEDz2ALM.Size = New System.Drawing.Size(78, 18)
        Me.LEDz2ALM.TabIndex = 11
        '
        'fa2
        '
        Me.fa2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.fa2.Location = New System.Drawing.Point(0, 0)
        Me.fa2.Name = "fa2"
        Me.fa2.Size = New System.Drawing.Size(78, 18)
        Me.fa2.TabIndex = 4
        Me.fa2.Text = "ALARM"
        Me.fa2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LEDz3TBL
        '
        Me.LEDz3TBL.BackColor = System.Drawing.Color.Yellow
        Me.LEDz3TBL.Controls.Add(Me.ft3)
        Me.LEDz3TBL.Location = New System.Drawing.Point(179, 19)
        Me.LEDz3TBL.Name = "LEDz3TBL"
        Me.LEDz3TBL.Size = New System.Drawing.Size(78, 18)
        Me.LEDz3TBL.TabIndex = 10
        '
        'ft3
        '
        Me.ft3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ft3.Location = New System.Drawing.Point(0, 0)
        Me.ft3.Name = "ft3"
        Me.ft3.Size = New System.Drawing.Size(78, 18)
        Me.ft3.TabIndex = 4
        Me.ft3.Text = "TROUBLE"
        Me.ft3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LEDz2TBL
        '
        Me.LEDz2TBL.BackColor = System.Drawing.Color.Yellow
        Me.LEDz2TBL.Controls.Add(Me.ft2)
        Me.LEDz2TBL.Location = New System.Drawing.Point(95, 19)
        Me.LEDz2TBL.Name = "LEDz2TBL"
        Me.LEDz2TBL.Size = New System.Drawing.Size(78, 18)
        Me.LEDz2TBL.TabIndex = 10
        '
        'ft2
        '
        Me.ft2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ft2.Location = New System.Drawing.Point(0, 0)
        Me.ft2.Name = "ft2"
        Me.ft2.Size = New System.Drawing.Size(78, 18)
        Me.ft2.TabIndex = 4
        Me.ft2.Text = "TROUBLE"
        Me.ft2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label25
        '
        Me.Label25.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.Location = New System.Drawing.Point(11, 38)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(78, 18)
        Me.Label25.TabIndex = 9
        Me.Label25.Text = "ZONE 1"
        Me.Label25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LEDz1ALM
        '
        Me.LEDz1ALM.BackColor = System.Drawing.Color.Red
        Me.LEDz1ALM.Controls.Add(Me.fa1)
        Me.LEDz1ALM.ForeColor = System.Drawing.Color.White
        Me.LEDz1ALM.Location = New System.Drawing.Point(11, 58)
        Me.LEDz1ALM.Name = "LEDz1ALM"
        Me.LEDz1ALM.Size = New System.Drawing.Size(78, 18)
        Me.LEDz1ALM.TabIndex = 8
        '
        'fa1
        '
        Me.fa1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.fa1.Location = New System.Drawing.Point(0, 0)
        Me.fa1.Name = "fa1"
        Me.fa1.Size = New System.Drawing.Size(78, 18)
        Me.fa1.TabIndex = 4
        Me.fa1.Text = "ALARM"
        Me.fa1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LEDz1TBL
        '
        Me.LEDz1TBL.BackColor = System.Drawing.Color.Yellow
        Me.LEDz1TBL.Controls.Add(Me.ft1)
        Me.LEDz1TBL.Location = New System.Drawing.Point(11, 19)
        Me.LEDz1TBL.Name = "LEDz1TBL"
        Me.LEDz1TBL.Size = New System.Drawing.Size(78, 18)
        Me.LEDz1TBL.TabIndex = 7
        '
        'ft1
        '
        Me.ft1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ft1.Location = New System.Drawing.Point(0, 0)
        Me.ft1.Name = "ft1"
        Me.ft1.Size = New System.Drawing.Size(78, 18)
        Me.ft1.TabIndex = 4
        Me.ft1.Text = "TROUBLE"
        Me.ft1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.LEDtblExtender)
        Me.GroupBox1.Controls.Add(Me.LEDtblTemp)
        Me.GroupBox1.Controls.Add(Me.LEDtblPower)
        Me.GroupBox1.Controls.Add(Me.LEDtblComm)
        Me.GroupBox1.Controls.Add(Me.LEDtblIDC)
        Me.GroupBox1.Controls.Add(Me.LEDtblNAC)
        Me.GroupBox1.Location = New System.Drawing.Point(44, 174)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(101, 169)
        Me.GroupBox1.TabIndex = 16
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "TROUBLE"
        '
        'LEDtblExtender
        '
        Me.LEDtblExtender.BackColor = System.Drawing.Color.Yellow
        Me.LEDtblExtender.Controls.Add(Me.Label24)
        Me.LEDtblExtender.Location = New System.Drawing.Point(11, 139)
        Me.LEDtblExtender.Name = "LEDtblExtender"
        Me.LEDtblExtender.Size = New System.Drawing.Size(78, 18)
        Me.LEDtblExtender.TabIndex = 12
        '
        'Label24
        '
        Me.Label24.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(0, 0)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(78, 18)
        Me.Label24.TabIndex = 4
        Me.Label24.Text = "EXTENDER"
        Me.Label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LEDtblTemp
        '
        Me.LEDtblTemp.BackColor = System.Drawing.Color.Yellow
        Me.LEDtblTemp.Controls.Add(Me.Label23)
        Me.LEDtblTemp.Location = New System.Drawing.Point(11, 115)
        Me.LEDtblTemp.Name = "LEDtblTemp"
        Me.LEDtblTemp.Size = New System.Drawing.Size(78, 18)
        Me.LEDtblTemp.TabIndex = 11
        '
        'Label23
        '
        Me.Label23.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(0, 0)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(78, 18)
        Me.Label23.TabIndex = 4
        Me.Label23.Text = "TEMP"
        Me.Label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LEDtblPower
        '
        Me.LEDtblPower.BackColor = System.Drawing.Color.Yellow
        Me.LEDtblPower.Controls.Add(Me.Label20)
        Me.LEDtblPower.Location = New System.Drawing.Point(11, 91)
        Me.LEDtblPower.Name = "LEDtblPower"
        Me.LEDtblPower.Size = New System.Drawing.Size(78, 18)
        Me.LEDtblPower.TabIndex = 10
        '
        'Label20
        '
        Me.Label20.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(0, 0)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(78, 18)
        Me.Label20.TabIndex = 4
        Me.Label20.Text = "POWER"
        Me.Label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LEDtblComm
        '
        Me.LEDtblComm.BackColor = System.Drawing.Color.Yellow
        Me.LEDtblComm.Controls.Add(Me.Label19)
        Me.LEDtblComm.Location = New System.Drawing.Point(11, 67)
        Me.LEDtblComm.Name = "LEDtblComm"
        Me.LEDtblComm.Size = New System.Drawing.Size(78, 18)
        Me.LEDtblComm.TabIndex = 9
        '
        'Label19
        '
        Me.Label19.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(0, 0)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(78, 18)
        Me.Label19.TabIndex = 4
        Me.Label19.Text = "COMM"
        Me.Label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LEDtblIDC
        '
        Me.LEDtblIDC.BackColor = System.Drawing.Color.Yellow
        Me.LEDtblIDC.Controls.Add(Me.Label18)
        Me.LEDtblIDC.Location = New System.Drawing.Point(11, 43)
        Me.LEDtblIDC.Name = "LEDtblIDC"
        Me.LEDtblIDC.Size = New System.Drawing.Size(78, 18)
        Me.LEDtblIDC.TabIndex = 8
        '
        'Label18
        '
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(0, 0)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(78, 18)
        Me.Label18.TabIndex = 4
        Me.Label18.Text = "IDC"
        Me.Label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LEDtblNAC
        '
        Me.LEDtblNAC.BackColor = System.Drawing.Color.Yellow
        Me.LEDtblNAC.Controls.Add(Me.Label17)
        Me.LEDtblNAC.Location = New System.Drawing.Point(11, 19)
        Me.LEDtblNAC.Name = "LEDtblNAC"
        Me.LEDtblNAC.Size = New System.Drawing.Size(78, 18)
        Me.LEDtblNAC.TabIndex = 7
        '
        'Label17
        '
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(0, 0)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(78, 18)
        Me.Label17.TabIndex = 4
        Me.Label17.Text = "NAC"
        Me.Label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnCtlAgentAbort
        '
        Me.btnCtlAgentAbort.Location = New System.Drawing.Point(529, 119)
        Me.btnCtlAgentAbort.Name = "btnCtlAgentAbort"
        Me.btnCtlAgentAbort.Size = New System.Drawing.Size(78, 23)
        Me.btnCtlAgentAbort.TabIndex = 15
        Me.btnCtlAgentAbort.Text = "ABORT"
        Me.btnCtlAgentAbort.UseVisualStyleBackColor = True
        '
        'btnCtlHush
        '
        Me.btnCtlHush.Location = New System.Drawing.Point(445, 119)
        Me.btnCtlHush.Name = "btnCtlHush"
        Me.btnCtlHush.Size = New System.Drawing.Size(78, 23)
        Me.btnCtlHush.TabIndex = 14
        Me.btnCtlHush.Text = "HUSH"
        Me.btnCtlHush.UseVisualStyleBackColor = True
        '
        'btnCtlHazAck
        '
        Me.btnCtlHazAck.Location = New System.Drawing.Point(361, 119)
        Me.btnCtlHazAck.Name = "btnCtlHazAck"
        Me.btnCtlHazAck.Size = New System.Drawing.Size(78, 23)
        Me.btnCtlHazAck.TabIndex = 13
        Me.btnCtlHazAck.Text = "ACK"
        Me.btnCtlHazAck.UseVisualStyleBackColor = True
        '
        'btnCtlSil
        '
        Me.btnCtlSil.Location = New System.Drawing.Point(277, 119)
        Me.btnCtlSil.Name = "btnCtlSil"
        Me.btnCtlSil.Size = New System.Drawing.Size(78, 23)
        Me.btnCtlSil.TabIndex = 12
        Me.btnCtlSil.Text = "SILENCE"
        Me.btnCtlSil.UseVisualStyleBackColor = True
        '
        'btnCtlTblAck
        '
        Me.btnCtlTblAck.Location = New System.Drawing.Point(193, 119)
        Me.btnCtlTblAck.Name = "btnCtlTblAck"
        Me.btnCtlTblAck.Size = New System.Drawing.Size(78, 23)
        Me.btnCtlTblAck.TabIndex = 11
        Me.btnCtlTblAck.Text = "ACK"
        Me.btnCtlTblAck.UseVisualStyleBackColor = True
        '
        'btnCtlReset
        '
        Me.btnCtlReset.Location = New System.Drawing.Point(109, 119)
        Me.btnCtlReset.Name = "btnCtlReset"
        Me.btnCtlReset.Size = New System.Drawing.Size(78, 23)
        Me.btnCtlReset.TabIndex = 10
        Me.btnCtlReset.Text = "RESET"
        Me.btnCtlReset.UseVisualStyleBackColor = True
        '
        'LEDabort
        '
        Me.LEDabort.BackColor = System.Drawing.Color.Red
        Me.LEDabort.Controls.Add(Me.lblAbort)
        Me.LEDabort.ForeColor = System.Drawing.Color.White
        Me.LEDabort.Location = New System.Drawing.Point(529, 148)
        Me.LEDabort.Name = "LEDabort"
        Me.LEDabort.Size = New System.Drawing.Size(78, 18)
        Me.LEDabort.TabIndex = 9
        '
        'lblAbort
        '
        Me.lblAbort.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAbort.Location = New System.Drawing.Point(0, 0)
        Me.lblAbort.Name = "lblAbort"
        Me.lblAbort.Size = New System.Drawing.Size(78, 18)
        Me.lblAbort.TabIndex = 4
        Me.lblAbort.Text = "ABORT"
        Me.lblAbort.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LEDagent
        '
        Me.LEDagent.BackColor = System.Drawing.Color.Red
        Me.LEDagent.Controls.Add(Me.lblAgent)
        Me.LEDagent.ForeColor = System.Drawing.Color.White
        Me.LEDagent.Location = New System.Drawing.Point(529, 95)
        Me.LEDagent.Name = "LEDagent"
        Me.LEDagent.Size = New System.Drawing.Size(78, 18)
        Me.LEDagent.TabIndex = 8
        '
        'lblAgent
        '
        Me.lblAgent.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAgent.Location = New System.Drawing.Point(0, 0)
        Me.lblAgent.Name = "lblAgent"
        Me.lblAgent.Size = New System.Drawing.Size(78, 18)
        Me.lblAgent.TabIndex = 4
        Me.lblAgent.Text = "AGENT"
        Me.lblAgent.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LEDtblAck
        '
        Me.LEDtblAck.BackColor = System.Drawing.Color.Yellow
        Me.LEDtblAck.Controls.Add(Me.lblTblAck)
        Me.LEDtblAck.Location = New System.Drawing.Point(193, 148)
        Me.LEDtblAck.Name = "LEDtblAck"
        Me.LEDtblAck.Size = New System.Drawing.Size(78, 18)
        Me.LEDtblAck.TabIndex = 9
        '
        'lblTblAck
        '
        Me.lblTblAck.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTblAck.Location = New System.Drawing.Point(0, 0)
        Me.lblTblAck.Name = "lblTblAck"
        Me.lblTblAck.Size = New System.Drawing.Size(78, 18)
        Me.lblTblAck.TabIndex = 4
        Me.lblTblAck.Text = "ACKED"
        Me.lblTblAck.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LEDhush
        '
        Me.LEDhush.BackColor = System.Drawing.Color.Yellow
        Me.LEDhush.Controls.Add(Me.lblHush)
        Me.LEDhush.Location = New System.Drawing.Point(445, 95)
        Me.LEDhush.Name = "LEDhush"
        Me.LEDhush.Size = New System.Drawing.Size(78, 18)
        Me.LEDhush.TabIndex = 7
        '
        'lblHush
        '
        Me.lblHush.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHush.Location = New System.Drawing.Point(0, 0)
        Me.lblHush.Name = "lblHush"
        Me.lblHush.Size = New System.Drawing.Size(78, 18)
        Me.lblHush.TabIndex = 4
        Me.lblHush.Text = "HUSH"
        Me.lblHush.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LEDhazAck
        '
        Me.LEDhazAck.BackColor = System.Drawing.Color.Yellow
        Me.LEDhazAck.Controls.Add(Me.lblHazAck)
        Me.LEDhazAck.Location = New System.Drawing.Point(361, 148)
        Me.LEDhazAck.Name = "LEDhazAck"
        Me.LEDhazAck.Size = New System.Drawing.Size(78, 18)
        Me.LEDhazAck.TabIndex = 8
        '
        'lblHazAck
        '
        Me.lblHazAck.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHazAck.Location = New System.Drawing.Point(0, 0)
        Me.lblHazAck.Name = "lblHazAck"
        Me.lblHazAck.Size = New System.Drawing.Size(78, 18)
        Me.lblHazAck.TabIndex = 4
        Me.lblHazAck.Text = "ACKED"
        Me.lblHazAck.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LEDfireSil
        '
        Me.LEDfireSil.BackColor = System.Drawing.Color.Yellow
        Me.LEDfireSil.Controls.Add(Me.lblSil)
        Me.LEDfireSil.Location = New System.Drawing.Point(277, 148)
        Me.LEDfireSil.Name = "LEDfireSil"
        Me.LEDfireSil.Size = New System.Drawing.Size(78, 18)
        Me.LEDfireSil.TabIndex = 7
        '
        'lblSil
        '
        Me.lblSil.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSil.Location = New System.Drawing.Point(0, 0)
        Me.lblSil.Name = "lblSil"
        Me.lblSil.Size = New System.Drawing.Size(78, 18)
        Me.lblSil.TabIndex = 4
        Me.lblSil.Text = "SILENCED"
        Me.lblSil.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LEDhazard
        '
        Me.LEDhazard.BackColor = System.Drawing.Color.Blue
        Me.LEDhazard.Controls.Add(Me.lblHaz)
        Me.LEDhazard.Location = New System.Drawing.Point(361, 95)
        Me.LEDhazard.Name = "LEDhazard"
        Me.LEDhazard.Size = New System.Drawing.Size(78, 18)
        Me.LEDhazard.TabIndex = 8
        '
        'lblHaz
        '
        Me.lblHaz.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHaz.ForeColor = System.Drawing.Color.White
        Me.lblHaz.Location = New System.Drawing.Point(0, 0)
        Me.lblHaz.Name = "lblHaz"
        Me.lblHaz.Size = New System.Drawing.Size(78, 18)
        Me.lblHaz.TabIndex = 4
        Me.lblHaz.Text = "HAZARD"
        Me.lblHaz.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LEDfire
        '
        Me.LEDfire.BackColor = System.Drawing.Color.Red
        Me.LEDfire.Controls.Add(Me.lblAlm)
        Me.LEDfire.Location = New System.Drawing.Point(277, 95)
        Me.LEDfire.Name = "LEDfire"
        Me.LEDfire.Size = New System.Drawing.Size(78, 18)
        Me.LEDfire.TabIndex = 7
        '
        'lblAlm
        '
        Me.lblAlm.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAlm.ForeColor = System.Drawing.Color.White
        Me.lblAlm.Location = New System.Drawing.Point(0, 0)
        Me.lblAlm.Name = "lblAlm"
        Me.lblAlm.Size = New System.Drawing.Size(78, 18)
        Me.lblAlm.TabIndex = 4
        Me.lblAlm.Text = "FIRE"
        Me.lblAlm.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LEDtrouble
        '
        Me.LEDtrouble.BackColor = System.Drawing.Color.Yellow
        Me.LEDtrouble.Controls.Add(Me.lblTbl)
        Me.LEDtrouble.Location = New System.Drawing.Point(193, 95)
        Me.LEDtrouble.Name = "LEDtrouble"
        Me.LEDtrouble.Size = New System.Drawing.Size(78, 18)
        Me.LEDtrouble.TabIndex = 6
        '
        'lblTbl
        '
        Me.lblTbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTbl.Location = New System.Drawing.Point(0, 0)
        Me.lblTbl.Name = "lblTbl"
        Me.lblTbl.Size = New System.Drawing.Size(78, 18)
        Me.lblTbl.TabIndex = 4
        Me.lblTbl.Text = "TROUBLE"
        Me.lblTbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LEDpower
        '
        Me.LEDpower.BackColor = System.Drawing.Color.Lime
        Me.LEDpower.Controls.Add(Me.Label6)
        Me.LEDpower.Location = New System.Drawing.Point(109, 95)
        Me.LEDpower.Name = "LEDpower"
        Me.LEDpower.Size = New System.Drawing.Size(78, 18)
        Me.LEDpower.TabIndex = 5
        '
        'Label6
        '
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(0, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(78, 18)
        Me.Label6.TabIndex = 4
        Me.Label6.Text = "POWER"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnHelp
        '
        Me.btnHelp.Location = New System.Drawing.Point(13, 66)
        Me.btnHelp.Name = "btnHelp"
        Me.btnHelp.Size = New System.Drawing.Size(75, 23)
        Me.btnHelp.TabIndex = 3
        Me.btnHelp.Text = "Help"
        Me.btnHelp.UseVisualStyleBackColor = True
        '
        'btnCommTest
        '
        Me.btnCommTest.Location = New System.Drawing.Point(13, 37)
        Me.btnCommTest.Name = "btnCommTest"
        Me.btnCommTest.Size = New System.Drawing.Size(75, 23)
        Me.btnCommTest.TabIndex = 2
        Me.btnCommTest.Text = "Comm Test"
        Me.btnCommTest.UseVisualStyleBackColor = True
        '
        'display
        '
        Me.display.BackColor = System.Drawing.Color.Black
        Me.display.Controls.Add(Me.LCD)
        Me.display.Location = New System.Drawing.Point(94, 8)
        Me.display.Name = "display"
        Me.display.Size = New System.Drawing.Size(530, 81)
        Me.display.TabIndex = 1
        '
        'LCD
        '
        Me.LCD.BackColor = System.Drawing.Color.Black
        Me.LCD.Font = New System.Drawing.Font("Lucida Console", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LCD.ForeColor = System.Drawing.Color.Lime
        Me.LCD.Location = New System.Drawing.Point(7, 6)
        Me.LCD.Name = "LCD"
        Me.LCD.Size = New System.Drawing.Size(516, 69)
        Me.LCD.TabIndex = 0
        Me.LCD.Text = "Panel not connected."
        '
        'btnLockCP
        '
        Me.btnLockCP.Location = New System.Drawing.Point(13, 8)
        Me.btnLockCP.Name = "btnLockCP"
        Me.btnLockCP.Size = New System.Drawing.Size(75, 23)
        Me.btnLockCP.TabIndex = 0
        Me.btnLockCP.Text = "Lock"
        Me.btnLockCP.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(633, 198)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 7
        Me.Button1.Text = "Unlock"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'lblIndName
        '
        Me.lblIndName.AutoSize = True
        Me.lblIndName.Location = New System.Drawing.Point(91, 26)
        Me.lblIndName.Name = "lblIndName"
        Me.lblIndName.Size = New System.Drawing.Size(75, 13)
        Me.lblIndName.TabIndex = 5
        Me.lblIndName.Text = "System Name:"
        '
        'lblIndModel
        '
        Me.lblIndModel.Location = New System.Drawing.Point(91, 41)
        Me.lblIndModel.Name = "lblIndModel"
        Me.lblIndModel.Size = New System.Drawing.Size(124, 52)
        Me.lblIndModel.TabIndex = 4
        Me.lblIndModel.Text = "System Model:"
        '
        'lblIndStat
        '
        Me.lblIndStat.AutoSize = True
        Me.lblIndStat.Location = New System.Drawing.Point(91, 11)
        Me.lblIndStat.Name = "lblIndStat"
        Me.lblIndStat.Size = New System.Drawing.Size(77, 13)
        Me.lblIndStat.TabIndex = 3
        Me.lblIndStat.Text = "System Status:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(9, 26)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(75, 13)
        Me.Label5.TabIndex = 2
        Me.Label5.Text = "System Name:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(9, 41)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(76, 13)
        Me.Label4.TabIndex = 1
        Me.Label4.Text = "System Model:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(9, 11)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(77, 13)
        Me.Label3.TabIndex = 0
        Me.Label3.Text = "System Status:"
        '
        'txtUnlockBox
        '
        Me.txtUnlockBox.Location = New System.Drawing.Point(479, 172)
        Me.txtUnlockBox.Name = "txtUnlockBox"
        Me.txtUnlockBox.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtUnlockBox.Size = New System.Drawing.Size(229, 20)
        Me.txtUnlockBox.TabIndex = 11
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.System_Commander_X.My.Resources.Resources.fire
        Me.PictureBox1.Location = New System.Drawing.Point(12, 12)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(48, 48)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'serial
        '
        Me.serial.ReadBufferSize = 8192
        Me.serial.WriteBufferSize = 4096
        '
        'MainWin
        '
        Me.AcceptButton = Me.Button1
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(880, 479)
        Me.ControlBox = False
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.btnMainQuit)
        Me.Controls.Add(Me.btnMainChangePort)
        Me.Controls.Add(Me.btnMainAbout)
        Me.Controls.Add(Me.btnMainConfigureSystem)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.PictureBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "MainWin"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Fire Alarm Control Interface (Master)"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.controlPanel.ResumeLayout(False)
        Me.controlPanel.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.LEDz10ALM.ResumeLayout(False)
        Me.LEDz10TBL.ResumeLayout(False)
        Me.LEDz9ALM.ResumeLayout(False)
        Me.LEDz9TBL.ResumeLayout(False)
        Me.LEDz8ALM.ResumeLayout(False)
        Me.LEDz7ALM.ResumeLayout(False)
        Me.LEDz8TBL.ResumeLayout(False)
        Me.LEDz7TBL.ResumeLayout(False)
        Me.LEDz6ALM.ResumeLayout(False)
        Me.LEDz6TBL.ResumeLayout(False)
        Me.LEDz5ALM.ResumeLayout(False)
        Me.LEDz5TBL.ResumeLayout(False)
        Me.LEDz4ALM.ResumeLayout(False)
        Me.LEDz4TBL.ResumeLayout(False)
        Me.LEDz3ALM.ResumeLayout(False)
        Me.LEDz2ALM.ResumeLayout(False)
        Me.LEDz3TBL.ResumeLayout(False)
        Me.LEDz2TBL.ResumeLayout(False)
        Me.LEDz1ALM.ResumeLayout(False)
        Me.LEDz1TBL.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.LEDtblExtender.ResumeLayout(False)
        Me.LEDtblTemp.ResumeLayout(False)
        Me.LEDtblPower.ResumeLayout(False)
        Me.LEDtblComm.ResumeLayout(False)
        Me.LEDtblIDC.ResumeLayout(False)
        Me.LEDtblNAC.ResumeLayout(False)
        Me.LEDabort.ResumeLayout(False)
        Me.LEDagent.ResumeLayout(False)
        Me.LEDtblAck.ResumeLayout(False)
        Me.LEDhush.ResumeLayout(False)
        Me.LEDhazAck.ResumeLayout(False)
        Me.LEDfireSil.ResumeLayout(False)
        Me.LEDhazard.ResumeLayout(False)
        Me.LEDfire.ResumeLayout(False)
        Me.LEDtrouble.ResumeLayout(False)
        Me.LEDpower.ResumeLayout(False)
        Me.display.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents btnMainConfigureSystem As Button
    Friend WithEvents btnMainAbout As Button
    Friend WithEvents btnMainChangePort As Button
    Friend WithEvents btnMainQuit As Button
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents lblIndName As Label
    Friend WithEvents lblIndModel As Label
    Friend WithEvents lblIndStat As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents controlPanel As Panel
    Friend WithEvents lblIndSoftwareVer As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents txtUnlockBox As TextBox
    Friend WithEvents lblIndNoConfig As Label
    Friend WithEvents lblIndNoPassword As Label
    Friend WithEvents btnLockCP As Button
    Friend WithEvents display As Panel
    Friend WithEvents LCD As Label
    Friend WithEvents btnHelp As Button
    Friend WithEvents btnCommTest As Button
    Friend WithEvents Label6 As Label
    Friend WithEvents LEDpower As Panel
    Friend WithEvents LEDtrouble As Panel
    Friend WithEvents lblTbl As Label
    Friend WithEvents LEDfire As Panel
    Friend WithEvents lblAlm As Label
    Friend WithEvents LEDhazard As Panel
    Friend WithEvents lblHaz As Label
    Friend WithEvents LEDfireSil As Panel
    Friend WithEvents lblSil As Label
    Friend WithEvents LEDhazAck As Panel
    Friend WithEvents lblHazAck As Label
    Friend WithEvents LEDhush As Panel
    Friend WithEvents lblHush As Label
    Friend WithEvents LEDtblAck As Panel
    Friend WithEvents lblTblAck As Label
    Friend WithEvents LEDagent As Panel
    Friend WithEvents lblAgent As Label
    Friend WithEvents LEDabort As Panel
    Friend WithEvents lblAbort As Label
    Friend WithEvents btnCtlReset As Button
    Friend WithEvents btnCtlHazAck As Button
    Friend WithEvents btnCtlSil As Button
    Friend WithEvents btnCtlTblAck As Button
    Friend WithEvents btnCtlHush As Button
    Friend WithEvents btnCtlAgentAbort As Button
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents LEDtblNAC As Panel
    Friend WithEvents Label17 As Label
    Friend WithEvents LEDtblIDC As Panel
    Friend WithEvents Label18 As Label
    Friend WithEvents LEDtblComm As Panel
    Friend WithEvents Label19 As Label
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents LEDz1ALM As Panel
    Friend WithEvents fa1 As Label
    Friend WithEvents LEDz1TBL As Panel
    Friend WithEvents ft1 As Label
    Friend WithEvents LEDtblTemp As Panel
    Friend WithEvents Label23 As Label
    Friend WithEvents LEDtblPower As Panel
    Friend WithEvents Label20 As Label
    Friend WithEvents LEDtblExtender As Panel
    Friend WithEvents Label24 As Label
    Friend WithEvents Label25 As Label
    Friend WithEvents Label38 As Label
    Friend WithEvents Label39 As Label
    Friend WithEvents LEDz10ALM As Panel
    Friend WithEvents fa10 As Label
    Friend WithEvents Label41 As Label
    Friend WithEvents LEDz10TBL As Panel
    Friend WithEvents ft10 As Label
    Friend WithEvents LEDz9ALM As Panel
    Friend WithEvents fa9 As Label
    Friend WithEvents Label44 As Label
    Friend WithEvents LEDz9TBL As Panel
    Friend WithEvents ft9 As Label
    Friend WithEvents LEDz8ALM As Panel
    Friend WithEvents fa8 As Label
    Friend WithEvents LEDz7ALM As Panel
    Friend WithEvents fa7 As Label
    Friend WithEvents LEDz8TBL As Panel
    Friend WithEvents ft8 As Label
    Friend WithEvents LEDz7TBL As Panel
    Friend WithEvents ft7 As Label
    Friend WithEvents Label50 As Label
    Friend WithEvents LEDz6ALM As Panel
    Friend WithEvents fa6 As Label
    Friend WithEvents LEDz6TBL As Panel
    Friend WithEvents ft6 As Label
    Friend WithEvents Label35 As Label
    Friend WithEvents Label32 As Label
    Friend WithEvents LEDz5ALM As Panel
    Friend WithEvents fa5 As Label
    Friend WithEvents Label29 As Label
    Friend WithEvents LEDz5TBL As Panel
    Friend WithEvents ft5 As Label
    Friend WithEvents LEDz4ALM As Panel
    Friend WithEvents fa4 As Label
    Friend WithEvents Label26 As Label
    Friend WithEvents LEDz4TBL As Panel
    Friend WithEvents ft4 As Label
    Friend WithEvents LEDz3ALM As Panel
    Friend WithEvents fa3 As Label
    Friend WithEvents LEDz2ALM As Panel
    Friend WithEvents fa2 As Label
    Friend WithEvents LEDz3TBL As Panel
    Friend WithEvents ft3 As Label
    Friend WithEvents LEDz2TBL As Panel
    Friend WithEvents ft2 As Label
    Friend WithEvents btnZoneMap As Button
    Friend WithEvents btnExtenderZones As Button
    Friend WithEvents btnDiag As Button
    Friend WithEvents btnAgentStat As Button
    Friend WithEvents btnAdminContact As Button
    Friend WithEvents lblOF1 As Label
    Public WithEvents serial As IO.Ports.SerialPort
End Class
