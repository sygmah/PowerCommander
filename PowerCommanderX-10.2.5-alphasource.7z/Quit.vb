﻿Imports System.Windows.Forms

Public Class Quit

    Public Class GlobalVariables
        Public Shared secs As Integer = 0
    End Class

    Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click
        If MainWin.serial.IsOpen = True Then
            MainWin.serial.Close()
        End If

        My.Settings.PortIsSelected = False
        Application.Exit()
    End Sub

    Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Close()
    End Sub

    Private Sub Quit_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        SelfCancelTimer.Start()
    End Sub

    Private Sub SelfCancelTimer_Tick(sender As Object, e As EventArgs) Handles SelfCancelTimer.Tick
        GlobalVariables.secs = GlobalVariables.secs + 1
        timerBar.PerformStep()
        If GlobalVariables.secs >= 55 Then
            GlobalVariables.secs = 0
            SelfCancelTimer.Stop()
            Me.Close()
        End If
    End Sub
End Class
