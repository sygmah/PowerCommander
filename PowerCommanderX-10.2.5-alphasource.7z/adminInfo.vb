﻿Public Class adminInfo
    Private Sub AdminInfo_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        txtFirstName.Text = My.Settings.adminFirstName
        txtLastName.Text = My.Settings.adminLastName
        txtEmail.Text = My.Settings.adminEmail
        txtPhone1.Text = My.Settings.adminPhone1
        txtPhone2.Text = My.Settings.adminPhone2
        txtDiscord.Text = My.Settings.adminDiscord
        txtNotes.Text = My.Settings.adminNotes
    End Sub
End Class