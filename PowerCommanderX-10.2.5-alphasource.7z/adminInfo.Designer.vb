﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class adminInfo
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(adminInfo))
        Me.txtNotes = New System.Windows.Forms.TextBox()
        Me.Label161 = New System.Windows.Forms.Label()
        Me.txtDiscord = New System.Windows.Forms.TextBox()
        Me.Label159 = New System.Windows.Forms.Label()
        Me.txtPhone2 = New System.Windows.Forms.TextBox()
        Me.Label160 = New System.Windows.Forms.Label()
        Me.txtPhone1 = New System.Windows.Forms.TextBox()
        Me.Label158 = New System.Windows.Forms.Label()
        Me.txtEmail = New System.Windows.Forms.TextBox()
        Me.Label157 = New System.Windows.Forms.Label()
        Me.txtLastName = New System.Windows.Forms.TextBox()
        Me.Label156 = New System.Windows.Forms.Label()
        Me.txtFirstName = New System.Windows.Forms.TextBox()
        Me.Label155 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'txtNotes
        '
        Me.txtNotes.Location = New System.Drawing.Point(139, 168)
        Me.txtNotes.Multiline = True
        Me.txtNotes.Name = "txtNotes"
        Me.txtNotes.ReadOnly = True
        Me.txtNotes.Size = New System.Drawing.Size(263, 123)
        Me.txtNotes.TabIndex = 28
        '
        'Label161
        '
        Me.Label161.AutoSize = True
        Me.Label161.Location = New System.Drawing.Point(76, 171)
        Me.Label161.Name = "Label161"
        Me.Label161.Size = New System.Drawing.Size(35, 13)
        Me.Label161.TabIndex = 27
        Me.Label161.Text = "Notes"
        '
        'txtDiscord
        '
        Me.txtDiscord.Location = New System.Drawing.Point(139, 142)
        Me.txtDiscord.Name = "txtDiscord"
        Me.txtDiscord.ReadOnly = True
        Me.txtDiscord.Size = New System.Drawing.Size(263, 20)
        Me.txtDiscord.TabIndex = 26
        '
        'Label159
        '
        Me.Label159.AutoSize = True
        Me.Label159.Location = New System.Drawing.Point(76, 145)
        Me.Label159.Name = "Label159"
        Me.Label159.Size = New System.Drawing.Size(43, 13)
        Me.Label159.TabIndex = 25
        Me.Label159.Text = "Discord"
        '
        'txtPhone2
        '
        Me.txtPhone2.Location = New System.Drawing.Point(139, 116)
        Me.txtPhone2.Name = "txtPhone2"
        Me.txtPhone2.ReadOnly = True
        Me.txtPhone2.Size = New System.Drawing.Size(263, 20)
        Me.txtPhone2.TabIndex = 24
        '
        'Label160
        '
        Me.Label160.AutoSize = True
        Me.Label160.Location = New System.Drawing.Point(76, 119)
        Me.Label160.Name = "Label160"
        Me.Label160.Size = New System.Drawing.Size(47, 13)
        Me.Label160.TabIndex = 23
        Me.Label160.Text = "Phone 2"
        '
        'txtPhone1
        '
        Me.txtPhone1.Location = New System.Drawing.Point(139, 90)
        Me.txtPhone1.Name = "txtPhone1"
        Me.txtPhone1.ReadOnly = True
        Me.txtPhone1.Size = New System.Drawing.Size(263, 20)
        Me.txtPhone1.TabIndex = 22
        '
        'Label158
        '
        Me.Label158.AutoSize = True
        Me.Label158.Location = New System.Drawing.Point(76, 93)
        Me.Label158.Name = "Label158"
        Me.Label158.Size = New System.Drawing.Size(47, 13)
        Me.Label158.TabIndex = 21
        Me.Label158.Text = "Phone 1"
        '
        'txtEmail
        '
        Me.txtEmail.Location = New System.Drawing.Point(139, 64)
        Me.txtEmail.Name = "txtEmail"
        Me.txtEmail.ReadOnly = True
        Me.txtEmail.Size = New System.Drawing.Size(263, 20)
        Me.txtEmail.TabIndex = 20
        '
        'Label157
        '
        Me.Label157.AutoSize = True
        Me.Label157.Location = New System.Drawing.Point(76, 67)
        Me.Label157.Name = "Label157"
        Me.Label157.Size = New System.Drawing.Size(32, 13)
        Me.Label157.TabIndex = 19
        Me.Label157.Text = "Email"
        '
        'txtLastName
        '
        Me.txtLastName.Location = New System.Drawing.Point(139, 38)
        Me.txtLastName.Name = "txtLastName"
        Me.txtLastName.ReadOnly = True
        Me.txtLastName.Size = New System.Drawing.Size(263, 20)
        Me.txtLastName.TabIndex = 18
        '
        'Label156
        '
        Me.Label156.AutoSize = True
        Me.Label156.Location = New System.Drawing.Point(76, 41)
        Me.Label156.Name = "Label156"
        Me.Label156.Size = New System.Drawing.Size(58, 13)
        Me.Label156.TabIndex = 17
        Me.Label156.Text = "Last Name"
        '
        'txtFirstName
        '
        Me.txtFirstName.Location = New System.Drawing.Point(139, 12)
        Me.txtFirstName.Name = "txtFirstName"
        Me.txtFirstName.ReadOnly = True
        Me.txtFirstName.Size = New System.Drawing.Size(263, 20)
        Me.txtFirstName.TabIndex = 16
        '
        'Label155
        '
        Me.Label155.AutoSize = True
        Me.Label155.Location = New System.Drawing.Point(76, 15)
        Me.Label155.Name = "Label155"
        Me.Label155.Size = New System.Drawing.Size(57, 13)
        Me.Label155.TabIndex = 15
        Me.Label155.Text = "First Name"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.System_Commander_X.My.Resources.Resources.badge_account_outline
        Me.PictureBox1.Location = New System.Drawing.Point(12, 12)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(48, 48)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox1.TabIndex = 29
        Me.PictureBox1.TabStop = False
        '
        'adminInfo
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(416, 303)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.txtNotes)
        Me.Controls.Add(Me.Label161)
        Me.Controls.Add(Me.txtDiscord)
        Me.Controls.Add(Me.Label159)
        Me.Controls.Add(Me.txtPhone2)
        Me.Controls.Add(Me.Label160)
        Me.Controls.Add(Me.txtPhone1)
        Me.Controls.Add(Me.Label158)
        Me.Controls.Add(Me.txtEmail)
        Me.Controls.Add(Me.Label157)
        Me.Controls.Add(Me.txtLastName)
        Me.Controls.Add(Me.Label156)
        Me.Controls.Add(Me.txtFirstName)
        Me.Controls.Add(Me.Label155)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "adminInfo"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "PowerCommander Administrator"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtNotes As TextBox
    Friend WithEvents Label161 As Label
    Friend WithEvents txtDiscord As TextBox
    Friend WithEvents Label159 As Label
    Friend WithEvents txtPhone2 As TextBox
    Friend WithEvents Label160 As Label
    Friend WithEvents txtPhone1 As TextBox
    Friend WithEvents Label158 As Label
    Friend WithEvents txtEmail As TextBox
    Friend WithEvents Label157 As Label
    Friend WithEvents txtLastName As TextBox
    Friend WithEvents Label156 As Label
    Friend WithEvents txtFirstName As TextBox
    Friend WithEvents Label155 As Label
    Friend WithEvents PictureBox1 As PictureBox
End Class
